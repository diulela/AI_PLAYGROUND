# 数据展示类需求设计案例

> **适用场景**：查询为主、实时刷新、分页/排序/筛选

---


## 案例一：数据展示类（REQ-028 代币列表展示）

### 需求特征
- 以查询为主
- 需要实时刷新
- 涉及分页/排序/筛选

### 领域建模

#### Token（代币）— 实体

**职责**：
- 表示用户持有的某种代币
- 计算法币价值
- 提供排序权重

**属性**：
- contractAddress: string（唯一标识）
- symbol: string（显示符号，如 "USDT"）
- balance: TokenAmount（持有数量）
- price: Price（当前价格）
- isVerified: boolean（官方认证标识）

**业务规则**：
1. balance 使用字符串避免精度丢失
2. 零余额代币默认隐藏（可配置显示）
3. 认证代币优先显示

#### TokenAmount（代币数量）— 值对象

**属性**：
- value: string（原始值，如 "1000000"）
- decimals: int32（精度，如 6）
- display: string（格式化显示，如 "1.000000"）

**业务规则**：
- value 必须 ≥0
- 格式化时保留完整精度

#### Price（价格）— 值对象

**属性**：
- usd: decimal（美元价格）
- change24h: decimal（24h涨跌幅）

**业务规则**：
- 价格更新频率：30s（缓存TTL）

### 架构决策

#### 决策1：缓存策略

**问题**：代币列表需要调用 TronGrid API，性能如何优化？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| 无缓存 | 数据实时 | 每次请求都慢，API 限流 |
| Redis 缓存 30s | 性能好，减少 API 调用 | 数据有延迟 |
| 客户端缓存 | 减轻服务器压力 | 多设备数据不一致 |

**决策**：Redis 缓存 30s
- 代币余额变化频率低（除非正在交易）
- 30s 延迟用户可接受
- 显著减少 TronGrid API 调用（防止限流）

**实现策略**：
- Cache Key: `tokens:{network}:{address}`
- TTL: 30s
- 手动刷新时清除缓存

#### 决策2：排序在前端还是后端？

**问题**：代币列表支持按余额/名称排序，排序逻辑放哪里？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| 后端排序 | 前端简单 | 增加后端计算、缓存复杂度 |
| 前端排序 | 灵活、即时响应 | 数据量大时性能差 |

**决策**：后端排序（Biz 层）
- 代币数量通常 < 100，排序开销小
- 后端统一排序规则，前端无需重复实现
- 支持分页时必须后端排序

### API 契约

```protobuf
service TokenService {
  rpc ListTokens(ListTokensRequest) returns (ListTokensResponse);
}

message ListTokensRequest {
  string wallet_address = 1;
  string network = 2;
  int32 page = 3;
  int32 page_size = 4;
  string sort_by = 5;           // "balance" | "name" | "value"
  bool show_zero_balance = 6;
}

message ListTokensResponse {
  repeated Token tokens = 1;
  int32 total = 2;
  int32 page = 3;
  int32 page_size = 4;
}

message Token {
  string contract_address = 1;
  string symbol = 2;
  string balance = 3;           // 字符串避免精度丢失
  string balance_usd = 4;
  int32 decimals = 5;
  bool is_verified = 6;
  double price_change_24h = 7;
}
```

### 后端设计

#### Data 层

```go
type TokenRepo interface {
    // ListTokens 从 TronGrid 获取代币列表
    ListTokens(ctx, address, network) ([]*Token, error)
}

实现要点：
- 调用 TronGrid API: /v1/accounts/{address}/tokens
- Redis 缓存（Key: tokens:{network}:{address}, TTL: 30s）
- 缓存命中：直接返回
- 缓存未命中：调用 API → 写入缓存 → 返回
```

#### Biz 层

```go
type TokenUsecase struct {
    repo TokenRepo
}

业务流程（ListTokens）：
1. 从 repo 获取全量代币（含缓存）
2. 筛选零余额代币（根据 show_zero_balance）
3. 排序（按 sort_by 字段）：
   - balance: 按余额数量降序
   - value: 按 USD 价值降序
   - name: 按符号字母升序
4. 分页（page, page_size）
5. 返回 (tokens, total)
```

#### Service 层

```
职责：
- 参数校验：address 格式、page ≥1、page_size ∈ [10,100]
- 调用 Biz 层
- DTO 转换：biz.Token → pb.Token
- 错误码映射：INVALID_ARGUMENT / INTERNAL
```

### 前端设计

#### 组件架构

```
TokenListPage
  ├─ TokenToolbar（搜索+排序+筛选）
  │   ├─ SearchInput
  │   ├─ SortDropdown
  │   └─ FilterSwitch（显示零余额）
  ├─ TokenList（虚拟滚动）
  │   └─ TokenRow（代币行）
  │       ├─ TokenIcon
  │       ├─ TokenInfo（名称+余额）
  │       └─ TokenValue（USD价值+涨跌）
  └─ PullToRefresh（下拉刷新）
```

#### 状态管理

```tsx
// useTokens Hook
interface UseTokensReturn {
  tokens: Token[];
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  sortBy: (field: string) => void;
  toggleZeroBalance: () => void;
}

实现策略：
- useEffect 初始加载
- 自动刷新：setInterval(30s)
- 手动刷新：下拉刷新
- 排序/筛选：调用 API（后端排序）
```

#### 交互流程

```mermaid
sequenceDiagram
    用户->>页面: 进入页面
    页面->>Hook: useTokens(address)
    Hook->>API: GET /tokens?address=xxx
    API->>后端: 查询缓存
    后端->>后端: 缓存命中
    后端-->>API: 返回代币列表
    API-->>Hook: tokens
    Hook-->>页面: 渲染列表
    
    用户->>页面: 30s后（自动刷新）
    页面->>Hook: refresh()
    Hook->>API: GET /tokens
    Note over API,后端: 缓存过期，调用TronGrid
```

---

