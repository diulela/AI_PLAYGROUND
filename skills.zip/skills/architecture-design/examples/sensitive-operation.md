# 敏感操作类需求设计案例

> **适用场景**：敏感数据、安全验证、防截屏保护

---


## 案例三：敏感操作类（REQ-015 助记词展示）

### 需求特征
- 涉及敏感数据
- 需要安全验证
- 防截屏保护

### 领域建模

#### Mnemonic（助记词）— 值对象

**职责**：
- 钱包的根密钥
- 派生所有账户私钥
- 必须安全存储和传输

**属性**：
- words: string[]（12/24个单词）
- entropy: bytes（熵值）

**业务规则**：
1. 生成后永不修改（不可变）
2. 存储时必须加密
3. 传输时使用临时密钥二次加密
4. 展示时限时可见（30s自动隐藏）
5. 禁止截屏

#### EncryptedMnemonic（加密助记词）— 值对象

**职责**：
- 安全传输助记词
- 临时密钥管理

**属性**：
- ciphertext: string（密文）
- encryptionKey: string（临时密钥）
- expiresAt: timestamp（过期时间）

**业务规则**：
1. 密钥有效期 30s
2. 密钥一次性使用（用后立即失效）
3. 密钥存储在 Redis（TTL 30s）

### 架构决策

#### 决策1：助记词传输加密方案

**问题**：助记词明文传输不安全，如何加密？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| HTTPS 直接传输 | 简单 | HTTPS 降级攻击风险 |
| 服务端永久密钥加密 | 简单 | 密钥泄露风险高 |
| 临时密钥 + Redis | 安全、密钥短期有效 | 需要 Redis |

**决策**：临时密钥 + Redis
- 后端生成随机密钥（32 字节）
- 用临时密钥加密助记词
- 密钥存入 Redis（TTL 30s）
- 前端解密后立即清除内存

**安全增强**：
- 密钥只能使用一次（用后删除 Redis key）
- 审计日志记录访问行为

#### 决策2：防截屏方案

**问题**：用户截屏助记词可能泄露，如何防止？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| 纯提示警告 | 简单 | 用户可能忽略 |
| 检测截屏并警告 | 有感知 | iOS/Android 需要原生能力 |
| 禁用截屏（原生） | 强制防护 | 需要 React Native bridge |

**决策**：v1.0 警告 + 检测，v2.0 禁用截屏
- v1.0 Web 版：显示警告 + 倒计时
- v1.0 App 版：通过 WebView 通信禁用截屏
- 离开页面时恢复截屏能力

### API 契约

```protobuf
service AccountService {
  rpc GetMnemonic(GetMnemonicRequest) returns (GetMnemonicResponse);
}

message GetMnemonicRequest {
  string wallet_id = 1;
  string password = 2;            // 密码验证
}

message GetMnemonicResponse {
  string encrypted_mnemonic = 1;  // 临时密钥加密后的密文
  string encryption_key = 2;      // 临时密钥（30s有效）
  int64 expires_at = 3;           // 过期时间戳
}
```

### 后端设计

#### Data 层

```go
type MnemonicRepo interface {
    // GetMnemonic 从加密存储读取助记词
    GetMnemonic(ctx, walletID) (mnemonic string, error)
}

实现要点：
- 助记词存储：加密后存数据库（使用主密钥加密）
- 读取时解密
```

#### Biz 层

```go
type MnemonicUsecase struct {
    repo MnemonicRepo
    passwordUC PasswordUsecase
    cache *redis.Client
}

业务流程（GetMnemonic）：
1. 验证密码：
   if !passwordUC.VerifyPassword(walletID, password):
     return UNAUTHENTICATED error

2. 读取助记词：
   mnemonic := repo.GetMnemonic(walletID)

3. 生成临时密钥：
   encryptionKey := generateRandomKey(32)
   expiresAt := now + 30s

4. 加密助记词：
   encrypted := AES-256-GCM(mnemonic, encryptionKey)

5. 密钥存入Redis：
   cache.Set("mnemonic_key:{walletID}", encryptionKey, 30s)

6. 记录审计日志：
   log.Info("助记词已被访问", walletID, IP, timestamp)

7. 返回 (encrypted, encryptionKey, expiresAt)
```

### 前端设计

#### 组件架构

```
MnemonicRevealPage
  ├─ SecurityBanner（安全警告）
  ├─ CountdownTimer（30s倒计时）
  ├─ MnemonicGrid（12宫格）
  │   └─ MnemonicWord × 12
  ├─ CopyButton（一键复制）
  └─ ConfirmButton（已安全备份）
```

#### 安全策略

**防截屏**：
```
useEffect():
  onMount:
    if (ReactNativeWebView):
      postMessage({ type: "DISABLE_SCREENSHOT" })
  
  onUnmount:
    if (ReactNativeWebView):
      postMessage({ type: "ENABLE_SCREENSHOT" })
```

**倒计时自动隐藏**：
```
useState: countdown = 30

useEffect():
  setInterval(1000ms):
    countdown--
    if countdown == 0:
      setMnemonic("")  // 清空内存
      setVisible(false)
```

**内存清理**：
```
useEffect():
  onUnmount:
    // 清空 DOM 节点文本（防止调试工具查看）
    document.querySelectorAll(".mnemonic-word").forEach(el => {
      el.textContent = "***"
    })
```

---

