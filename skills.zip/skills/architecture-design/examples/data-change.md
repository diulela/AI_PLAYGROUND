# 数据变更类需求设计案例

> **适用场景**：写操作、事务保证、幂等性

---


## 案例二：数据变更类（REQ-057 交易签名与广播）

### 需求特征
- 涉及写操作
- 需要事务保证
- 需要幂等性

### 领域建模

#### Transaction（交易）— 实体

**职责**：
- 表示一笔转账交易
- 管理交易生命周期（创建→签名→广播→确认）
- 保证幂等性

**属性**：
- id: string（链上交易哈希）
- idempotencyKey: string（客户端生成的幂等性标识）
- from: Address
- to: Address
- amount: TokenAmount
- status: TransactionStatus

**业务规则**：
1. idempotencyKey 唯一（防止重复提交）
2. 余额必须充足（amount + fee ≤ balance）
3. 地址格式必须合法
4. 状态转换：PENDING → CONFIRMED / FAILED

#### TransactionStatus（交易状态）— 值对象

**状态机**：
```
PENDING（待确认）
   ↓ 3-60s
CONFIRMED（已确认）
   或
FAILED（失败）
```

**业务规则**：
- 状态不可逆（CONFIRMED/FAILED 为终态）
- PENDING 状态需要轮询

### 架构决策

#### 决策1：幂等性设计

**问题**：用户重复点击"转账"按钮，如何防止重复扣款？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| 前端按钮禁用 | 简单 | 刷新页面失效、多设备无效 |
| 后端锁（分布式锁） | 可靠 | 需要 Redis、死锁风险 |
| 幂等性Key（数据库唯一索引） | 简单可靠、数据库保证 | 需要客户端生成UUID |

**决策**：幂等性 Key（推荐）
- 客户端生成 UUID 作为 idempotency_key
- 数据库 transactions 表添加唯一索引
- 重复请求返回原交易结果

**实现要点**：
```
1. 查询 idempotency_key 是否已存在
2. 存在：返回原结果（幂等）
3. 不存在：创建新交易记录
4. 并发冲突：唯一索引报错 → 重新查询返回
```

#### 决策2：交易状态轮询 vs WebSocket

**问题**：交易广播后需要等待链上确认（3-60s），如何通知用户？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| 前端轮询 | 简单、无需后端支持 | 浪费请求、延迟高 |
| WebSocket 推送 | 实时、节省请求 | 复杂、需要维护连接 |
| 后台任务+推送 | 可靠、解耦 | 需要消息队列 |

**决策**：v1.0 前端轮询，v2.0 WebSocket 推送
- v1.0 简化实现（每 3s 轮询）
- v2.0 增加 WebSocket 支持（实时推送）

### API 契约

```protobuf
service TransactionService {
  rpc SignAndBroadcast(SignAndBroadcastRequest) returns (SignAndBroadcastResponse);
  rpc GetTransactionStatus(GetTransactionStatusRequest) returns (GetTransactionStatusResponse);
}

message SignAndBroadcastRequest {
  string from_address = 1;
  string to_address = 2;
  string amount = 3;              // 字符串避免精度丢失
  string token_address = 4;       // 空表示TRX，非空表示TRC20
  string memo = 5;
  string idempotency_key = 6;     // 客户端生成UUID
}

message SignAndBroadcastResponse {
  string transaction_id = 1;
  TransactionStatus status = 2;
  int64 estimated_fee = 3;
}

enum TransactionStatus {
  PENDING = 0;
  CONFIRMED = 1;
  FAILED = 2;
}
```

### 后端设计

#### Data 层

```go
type TransactionRepo interface {
    Create(ctx, tx *Transaction) error
    GetByIdempotencyKey(ctx, key string) (*Transaction, error)
    UpdateStatus(ctx, txID string, status TransactionStatus) error
}

实现要点：
- transactions 表添加唯一索引：idempotency_key
- Create 时检查唯一约束冲突
- 并发场景：冲突时重新查询返回原记录
```

#### Biz 层

```go
type TransactionUsecase struct {
    repo TransactionRepo
    walletSDK TronWalletSDK
}

业务流程（SignAndBroadcast）：
1. 幂等性检查：
   existing := repo.GetByIdempotencyKey(key)
   if existing != nil: return existing

2. 业务校验：
   - 余额检查：balance ≥ amount + fee
   - 地址格式校验
   - 金额范围检查（>0）

3. 创建交易记录（状态=PENDING）：
   tx := Transaction{IdempotencyKey: key, Status: PENDING, ...}
   repo.Create(tx)

4. 签名交易：
   signedTx := walletSDK.SignTransaction(tx)
   if err: 更新状态为FAILED, return err

5. 广播到链上：
   txID := walletSDK.BroadcastTransaction(signedTx)
   if err: 更新状态为FAILED, return err

6. 更新交易ID：
   tx.ID = txID
   repo.UpdateStatus(txID, PENDING)

7. 异步监听确认（后台任务）：
   go watchTransactionStatus(txID)

8. 返回 tx
```

#### Service 层

```
职责：
- 参数校验：地址格式、金额非负、idempotency_key非空
- 错误码映射：
  - "insufficient balance" → FAILED_PRECONDITION
  - "node unreachable" → UNAVAILABLE
  - 其他 → INTERNAL
```

### 前端设计

#### 组件架构

```
TransferPage
  ├─ AddressInput（收款地址）
  ├─ TokenSelector（选择代币）
  ├─ AmountInput（金额输入）
  │   └─ MaxButton（一键填入最大值）
  ├─ MemoInput（备注）
  ├─ FeeDisplay（手续费）
  └─ SubmitButton（确认转账）

TransferResultPage
  ├─ StatusIcon（成功/失败图标）
  ├─ TransactionInfo（金额、地址、时间）
  ├─ StatusPolling（状态轮询组件）
  └─ ViewDetailsButton（查看详情）
```

#### 状态管理策略

**乐观 UI 更新**：
```
handleTransfer():
  1. 生成 idempotencyKey = uuid()
  2. 创建乐观交易对象：
     optimisticTx = { id: "temp", status: PENDING, ... }
  3. 显示"处理中"UI
  4. 调用 API: signAndBroadcast({ idempotency_key, ... })
  5. 成功：更新实际 txID，跳转结果页
  6. 失败：移除乐观对象，显示错误Toast
```

**轮询策略**：
```tsx
useTransactionStatus(transactionId):
  1. if status == CONFIRMED or FAILED: 停止轮询
  2. setInterval(3000ms):
     - 调用 getTransactionStatus(txID)
     - 更新 status
  3. 组件卸载时清除 interval
```

#### 交互流程

```mermaid
sequenceDiagram
    用户->>页面: 输入金额、点击转账
    页面->>页面: 生成 idempotencyKey
    页面->>页面: 乐观更新（显示处理中）
    页面->>API: POST /transactions/sign-and-broadcast
    API->>后端: 幂等性检查
    后端->>后端: 不存在，创建记录
    后端->>链: 签名+广播交易
    链-->>后端: 返回 txID
    后端-->>API: response{txID, status=PENDING}
    API-->>页面: 返回成功
    页面->>结果页: navigate + 轮询状态
    
    loop 每3秒轮询
        结果页->>API: GET /transactions/{txID}/status
        API->>后端: 查询链上状态
        后端-->>API: status
        API-->>结果页: 更新状态
    end
```

---

