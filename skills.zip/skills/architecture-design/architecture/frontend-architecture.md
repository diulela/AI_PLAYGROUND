# 前端分层架构（React 5层体系）

> 架构师视角：分层职责、判断规则、设计原则

---

## 一、分层架构总览

### 分层依赖关系

```mermaid
graph TB
    User[用户交互]
    
    subgraph 前端分层
        Page[Page 层<br/>页面入口]
        Component[Component 层<br/>可复用UI]
        Hook[Hook 层<br/>逻辑封装]
        Store[Store 层<br/>全局状态]
        Service[Service 层<br/>API调用]
    end
    
    Backend[后端API]
    LocalStorage[(LocalStorage)]
    
    User -->|操作| Page
    Page --> Component
    Page --> Hook
    Page --> Store
    
    Component --> Hook
    Hook --> Store
    Hook --> Service
    
    Store --> Service
    Store --> LocalStorage
    
    Service --> Backend
    
    style Page fill:#e1f5ff
    style Component fill:#fff4e1
    style Hook fill:#f0ffe1
    style Store fill:#ffe1f5
    style Service fill:#f5f5f5
```

### 各层核心职责

| 层 | 核心问题 | 职责 | 依赖 |
|----|---------|------|------|
| **Page** | 如何组织页面？ | 路由入口、布局编排、组合组件 | → Component, Hook, Store |
| **Component** | 如何封装UI？ | 可复用UI、Props接口、事件处理 | → Hook（可选） |
| **Hook** | 如何复用逻辑？ | 业务逻辑、副作用管理、状态封装 | → Store, Service |
| **Store** | 如何管理全局状态？ | 跨页面状态、持久化、订阅通知 | → Service, LocalStorage |
| **Service** | 如何调用API？ | HTTP封装、错误处理、类型转换 | → Backend |

---

## 二、分层判断规则

### 判断决策树

```mermaid
flowchart TD
    Start{设计一个功能}
    
    IsRoute{是页面路由<br/>入口？}
    IsUI{是可复用的<br/>UI组件？}
    IsLogic{是业务逻辑<br/>或副作用？}
    IsGlobal{是跨页面<br/>共享状态？}
    IsAPI{是后端<br/>API调用？}
    
    Start --> IsRoute
    IsRoute -->|是| Page[Page 层]
    IsRoute -->|否| IsUI
    
    IsUI -->|是| Component[Component 层]
    IsUI -->|否| IsLogic
    
    IsLogic -->|是| Hook[Hook 层]
    IsLogic -->|否| IsGlobal
    
    IsGlobal -->|是| Store[Store 层]
    IsGlobal -->|否| IsAPI
    
    IsAPI -->|是| Service[Service 层]
    IsAPI -->|否| Reconsider[❓重新分析]
    
    style Page fill:#e1f5ff
    style Component fill:#fff4e1
    style Hook fill:#f0ffe1
    style Store fill:#ffe1f5
    style Service fill:#f5f5f5
    style Reconsider fill:#ffcccc
```

### 快速判断表

| 问题 | 是 → 哪一层 | 关键词 |
|-----|-----------|-------|
| 路由页面入口？ | **Page** | 路由 |
| 可复用的按钮/卡片？ | **Component** | UI组件 |
| 表单校验逻辑？ | **Hook** | 业务逻辑 |
| 数据加载和缓存？ | **Hook** | 副作用 |
| 跨页面共享的用户信息？ | **Store** | 全局状态 |
| 需要持久化的设置？ | **Store + persist** | 持久化 |
| 调用后端接口？ | **Service** | API调用 |
| 单个组件内的临时状态？ | useState | 局部状态 |

---

## 三、状态管理决策框架

### 状态分类决策树

```mermaid
flowchart TD
    Start{需要状态}
    
    Q1{跨页面<br/>共享？}
    Q2{需要<br/>持久化？}
    Q3{父子组件<br/>通信？}
    
    Start --> Q1
    Q1 -->|是| Q2
    Q1 -->|否| Q3
    
    Q2 -->|是| StorePersist[Store + persist]
    Q2 -->|否| StoreMemory[Store]
    
    Q3 -->|是| ParentState[父组件 State]
    Q3 -->|否| LocalState[useState]
    
    style StorePersist fill:#ffe1f5
    style StoreMemory fill:#ffe1f5
    style ParentState fill:#fff4e1
    style LocalState fill:#f0ffe1
```

### 状态管理对比

| 状态类型 | 方案 | 适用场景 | 示例 |
|---------|------|---------|------|
| **全局+持久化** | Store + persist | 用户设置、网络选择 | `network`, `theme` |
| **全局+临时** | Store | 加载状态、错误信息 | `isLoading`, `error` |
| **父子通信** | Props + Callback | 列表项选中状态 | `selectedId`, `onSelect` |
| **局部临时** | useState | 展开/收起、输入框 | `open`, `inputValue` |

### 持久化选择性

| 数据类型 | 是否持久化 | 存储位置 | 示例 |
|---------|-----------|---------|------|
| 用户设置 | ✅ 是 | Store + persist | 语言、主题、网络 |
| 业务数据（非敏感） | ✅ 是 | Store + persist | 当前账户地址 |
| 敏感数据 | ❌ 否 | Store（内存） | 密码、私钥 |
| 临时UI状态 | ❌ 否 | useState | 展开/收起 |

---

## 四、设计原则

### 原则1：单一职责

**What**：一个组件只做一件事

**Why**：易于理解、测试、复用

**判断标准**：
- 组件名是否描述单一功能？
- 能否用一句话说清职责？
- Props 是否超过 8 个？（超过则考虑拆分）

### 原则2：状态提升

**What**：状态放在最小公共父组件

**Why**：避免状态冗余、保持一致性

**决策表**：

| 状态作用域 | 放在哪里 | 示例 |
|-----------|---------|------|
| 单个组件内 | useState | 展开/收起 |
| 兄弟组件间 | 父组件 State | 选中的 Tab |
| 跨页面 | Store | 用户信息 |
| 需持久化 | Store + persist | 网络选择 |

### 原则3：副作用隔离

**What**：副作用（API调用、订阅）放在 Hook 或 useEffect

**Why**：组件保持纯函数、易测试

**判断标准**：
- API 调用？→ 封装到 Hook
- 定时器/监听器？→ useEffect + cleanup
- 组件只负责渲染和触发事件

### 原则4：最小化全局状态

**What**：只有必须跨页面的状态才放 Store

**Why**：Store 污染导致难维护、性能问题

**判断标准**：
- ✅ 多个页面需要？→ Store
- ❌ 单页面内使用？→ Hook state
- ❌ 父子通信？→ Props

### 原则5：依赖方向单向

**What**：依赖方向 Page → Component → Hook → Store → Service，禁止反向

**Why**：避免循环依赖

**禁止模式**：
- ❌ Service 依赖 Store
- ❌ Hook 依赖 Component
- ❌ Component 直接调用 Service

---

## 五、典型设计场景

### 场景1：数据展示页（列表+详情）

**架构**：
```
后端 API
  ↓
Service 层：apiClient.listTokens()
  ↓
Hook 层：useTokens() - 加载逻辑
  ↓
Page 层：TokenListPage - 编排
  ↓
Component 层：TokenList/TokenItem - UI
```

**关键决策**：

| 决策点 | 方案 | 理由 |
|-------|------|------|
| 列表数据放哪里？ | Hook state | 页面内使用 |
| 选中状态放哪里？ | Page state | 父子通信 |
| 详情数据放哪里？ | 另一个 Hook | 按需加载 |

### 场景2：表单提交（创建/编辑）

**架构**：
```
后端 API
  ↓
Service 层：apiClient.createAccount()
  ↓
Hook 层：useCreateAccount() - 提交逻辑
  ↓ 成功后
Store 层：useWalletStore.addAccount()
  ↓
Page 层：CreateAccountPage - 表单+导航
```

**关键决策**：

| 决策点 | 方案 | 理由 |
|-------|------|------|
| 表单状态放哪里？ | useState | 临时输入 |
| 提交逻辑放哪里？ | Hook | 可复用 |
| 成功后更新列表？ | Store.addAccount | 跨页面共享 |

### 场景3：实时状态（轮询）

**架构**：
```
后端 API（轮询）
  ↓
Service 层：apiClient.getTransaction()
  ↓
Hook 层：useTransactionStatus() - 轮询逻辑
  ↓
Page 层：TransactionDetailPage - 状态显示
```

**关键决策**：

| 决策点 | 方案 | 理由 |
|-------|------|------|
| 通信方式？ | 轮询 vs WebSocket | 轮询简单，WebSocket 实时 |
| 状态放哪里？ | Hook state | 页面内使用 |
| 何时停止轮询？ | 状态终态 | 避免无效请求 |

---

## 六、反模式对比

| 反模式 | 问题 | 正确做法 | 原因 |
|-------|------|---------|------|
| 所有状态都放 Store | Store污染 | 只有跨页面状态才放Store | Store应保持精简 |
| Props 层层传递 | 繁琐、易错 | 状态提升或Store | 减少传递层级 |
| 副作用分散在组件里 | 难测试 | 封装到Hook | 逻辑集中 |
| 组件过大（>300行） | 难维护 | 拆分为小组件 | 单一职责 |
| 滥用 useEffect | 性能问题 | 只处理副作用 | useEffect是逃生舱 |
| Hook 依赖 Component | 循环依赖 | Hook独立 | 依赖单向 |
| Component 直接调用 API | 职责不清 | 通过Hook或Store | 分层清晰 |

---

## 七、分层职责边界

### 完整职责表

| 逻辑类型 | 应该放在 | 示例 |
|---------|---------|------|
| 路由定义 | Page | `<Route path="/accounts" />` |
| 页面布局 | Page | Container + Grid |
| 按钮/卡片UI | Component | `<Button>`, `<Card>` |
| Props 接口 | Component | `interface Props {...}` |
| 事件处理（委托） | Component | `onClick={props.onSelect}` |
| 数据加载 | **Hook** | useEffect + setState |
| 表单校验 | **Hook** | useForm |
| 用户信息 | **Store** | currentAccount |
| 网络设置 | **Store + persist** | network、language |
| 临时输入 | useState | 输入框内容 |
| HTTP 请求 | **Service** | fetch + error handling |
| 类型转换 | **Service** | API → UI 模型 |

### Page vs Component vs Hook 决策表

```mermaid
flowchart LR
    Question{这个功能...}
    
    Q1{是路由<br/>页面？}
    Q2{是UI<br/>渲染？}
    Q3{是逻辑<br/>或副作用？}
    
    Question --> Q1
    Q1 -->|是| Page[Page 层]
    Q1 -->|否| Q2
    
    Q2 -->|是| Component[Component 层]
    Q2 -->|否| Q3
    
    Q3 -->|是| Hook[Hook 层]
    Q3 -->|否| Unknown[❓重新分析]
    
    style Page fill:#e1f5ff
    style Component fill:#fff4e1
    style Hook fill:#f0ffe1
    style Unknown fill:#ffcccc
```

---

## 八、常见架构决策

### 决策1：用户信息放哪里？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| Props 传递 | 无全局依赖 | 繁琐、难维护 |
| Context | React 原生 | 性能问题 |
| Zustand Store | 性能好、易用 | 引入库（1.2KB） |

**决策**：Zustand Store（引入轻量库，换取开发体验和性能）

### 决策2：网络切换状态放哪里？

**判断依据**：
1. 跨页面？✅ 所有页面都需要
2. 持久化？✅ 刷新后保持选择

**决策**：Store + persist

### 决策3：列表筛选条件放哪里？

**方案对比**：

| 方案 | 优点 | 缺点 |
|-----|------|------|
| URL 参数 | 可分享、可刷新 | 代码复杂 |
| Store | 简单 | 不可分享 |
| useState | 最简单 | 刷新丢失 |

**决策依据**：
- 需要分享链接？→ URL 参数
- 只在本页面用？→ useState

### 决策4：轮询还是 WebSocket？

**方案对比**：

| 方案 | 优点 | 缺点 | 适用场景 |
|-----|------|------|---------|
| 轮询 | 简单、无状态 | 延迟、浪费请求 | 低频更新（>5s） |
| WebSocket | 实时、高效 | 复杂、需保持连接 | 高频更新（<1s） |

**决策依据**：更新频率 <1s → WebSocket，>5s → 轮询

**演进路线**：v1.0 轮询（简单快速上线）→ v2.0 WebSocket（优化实时性）

---

*架构师关注：分层职责、状态管理、设计原则，而非实现细节*
