# 后端分层架构（5层架构体系）

> 架构师视角：分层职责、判断规则、设计原则

---

## 一、分层架构总览

### 分层依赖关系

```mermaid
graph TB
    Client[客户端请求]
    
    subgraph 业务分层
        Service[Service 层<br/>协议适配]
        Biz[Biz 层<br/>业务规则]
        Data[Data 层<br/>数据仓储]
        Infra[Infra 层<br/>基础设施]
    end
    
    Pkg[pkg 层<br/>纯工具函数]
    
    DB[(数据库)]
    Cache[(Redis)]
    External[外部系统]
    
    Client -->|HTTP/gRPC| Service
    Service --> Biz
    Biz --> Data
    Data --> Infra
    Infra --> External
    
    Service -.可调用.-> Pkg
    Biz -.可调用.-> Pkg
    Data -.可调用.-> Pkg
    Infra -.可调用.-> Pkg
    
    Data --> DB
    Data --> Cache
    
    style Service fill:#e1f5ff
    style Biz fill:#fff4e1
    style Data fill:#f0ffe1
    style Infra fill:#ffe1f5
    style Pkg fill:#f5f5f5,stroke-dasharray: 5 5
```

### 各层核心职责

| 层 | 核心问题 | 职责 | 依赖 |
|----|---------|------|------|
| **Service** | 如何暴露服务？ | 协议转换、参数校验、错误码映射 | → Biz, pkg |
| **Biz** | 业务逻辑是什么？ | 业务规则、流程编排、事务管理、定义 Repository 接口 | → Data, pkg |
| **Data** | 如何持久化领域对象？ | CRUD 实现、缓存、分页、事务执行 | → Infra, pkg, DB, Redis |
| **Infra** | 如何封装技术基础设施？ | 外部集成、有状态客户端、配置管理 | → pkg, 外部系统 |
| **pkg** | 如何提供纯工具函数？ | 无状态工具、无业务逻辑、无外部依赖 | 无（被所有层使用） |

---

## 二、分层判断规则

### 判断决策树

```mermaid
flowchart TD
    Start{设计一个功能}
    
    IsProtocol{是 HTTP/gRPC<br/>协议转换？}
    IsBizRule{是业务规则<br/>或流程编排？}
    IsCRUD{管理领域对象<br/>生命周期？}
    IsStateful{需要配置/初始化<br/>或有状态？}
    IsPureFunc{纯函数工具<br/>无外部依赖？}
    
    Start --> IsProtocol
    IsProtocol -->|是| Service[Service 层]
    IsProtocol -->|否| IsBizRule
    
    IsBizRule -->|是| Biz[Biz 层]
    IsBizRule -->|否| IsCRUD
    
    IsCRUD -->|是| Data[Data 层]
    IsCRUD -->|否| IsStateful
    
    IsStateful -->|是| CheckInfra{技术性+<br/>复用性+<br/>解耦性}
    IsStateful -->|否| IsPureFunc
    
    CheckInfra -->|全满足| Infra[Infra 层]
    CheckInfra -->|不全满足| Reconsider[❓重新分析]
    
    IsPureFunc -->|是| Pkg[pkg 层]
    IsPureFunc -->|否| Reconsider
    
    style Service fill:#e1f5ff
    style Biz fill:#fff4e1
    style Data fill:#f0ffe1
    style Infra fill:#ffe1f5
    style Pkg fill:#f5f5f5
    style Reconsider fill:#ffcccc
```

### 快速判断表

| 问题 | 是 → 哪一层 | 关键词 |
|-----|-----------|-------|
| 解析 HTTP/gRPC 参数？ | **Service** | 协议转换 |
| 校验邮箱格式？ | Service（调用 pkg 工具） | 格式校验 |
| 检查余额充足？ | **Biz** | 业务规则 |
| 编排多个操作？ | **Biz** | 流程编排 |
| 管理事务？ | **Biz**（定义）+ Data（执行） | 事务 |
| 查询数据库？ | **Data** | CRUD |
| 缓存领域对象？ | **Data** | 缓存 |
| 调用外部 API？ | **Infra** | 外部集成 |
| 初始化 HTTP Client？ | **Infra** | 有状态客户端 |
| 限流器（有状态）？ | **Infra** | 并发控制 |
| 哈希函数？ | **pkg** | 纯函数 |
| 字符串工具？ | **pkg** | 纯函数 |
| UUID 生成？ | **pkg** | 纯函数 |

---

## 三、Infra 层 vs pkg 层

### 关键区别

| 维度 | pkg 层 | Infra 层 |
|-----|--------|---------|
| **本质** | 纯工具函数库 | 基础设施封装 |
| **状态** | 无状态（纯函数） | 有状态（需初始化） |
| **依赖** | 无外部依赖 | 依赖外部系统/配置/pkg |
| **初始化** | 不需要 | 需要配置和初始化 |
| **调用方式** | 直接调用函数 | 通过实例调用方法 |
| **作用域** | 跨层（任意层可用） | 主要被 Data 层使用 |
| **示例** | `pkg.HashPassword(pwd)` | `infraClient.GetBalance(ctx, addr)` |

### 典型内容对比

| pkg 层 | Infra 层 |
|--------|---------|
| crypto.HashPassword() | trongrid.Client（需配置 baseURL） |
| utils.FormatTime() | cache.RedisClient（需连接池） |
| validator.IsAddress() | ratelimit.Limiter（需 Redis） |
| encoder.ToBase64() | mq.Producer（需消息队列连接） |
| idgen.UUID() | storage.S3Client（需 credentials） |
| constants.ErrorCodes | config.Manager（需热更新） |

### pkg 层详细定义

**定位**：项目内可复用的纯工具函数，无状态、无依赖、无业务逻辑

**判断标准**：
1. ✅ 纯函数（相同输入必然相同输出）
2. ✅ 无外部依赖（不依赖数据库、Redis、外部 API）
3. ✅ 无业务逻辑（通用计算、格式转换）
4. ✅ 可被任意层调用

**典型内容**：

| 类别 | 内容 | 函数签名示例 |
|-----|------|------------|
| 加密工具 | 哈希、加密、签名 | `HashPassword(pwd) hash`, `AESEncrypt(data, key) cipher` |
| 字符串工具 | 格式化、转换 | `ToSnakeCase(str) string`, `Truncate(str, len) string` |
| 时间工具 | 格式化、计算 | `FormatTime(t) string`, `AddDays(t, days) time` |
| 校验器 | 格式验证 | `IsEmail(str) bool`, `IsAddress(addr) bool` |
| 编解码 | Base64/Hex 等 | `ToBase64(bytes) string`, `FromHex(str) bytes` |
| ID 生成 | UUID/雪花 ID | `NewUUID() string`, `NewSnowflakeID() int64` |
| 数学计算 | 精度计算 | `DecimalAdd(a, b) decimal`, `Percentage(a, b) float` |
| 常量定义 | 错误码、枚举 | `const ErrorCodeXxx = 1001` |

### Infra 层详细定义

**定位**：可复用的技术基础设施，有状态、需初始化、与业务无关

**判断标准**（3条同时满足）：
1. ✅ 技术性：提供技术能力，非业务能力
2. ✅ 复用性：可被多个模块/业务层复用
3. ✅ 解耦性：与具体业务领域无关

**典型内容**：

| 类别 | 内容 | 接口签名示例 |
|-----|------|------------|
| 外部系统集成 | HTTP/gRPC 客户端 | `Client.GetBalance(ctx, addr) (*Balance, error)` |
| 缓存抽象 | Redis/Memcached | `Cache.Get(ctx, key) (val, error)` |
| 消息队列 | Kafka/RabbitMQ | `Producer.Send(ctx, msg) error` |
| 限流器 | 令牌桶/漏桶 | `Limiter.Allow(ctx, key, limit) (bool, error)` |
| 熔断器 | 服务保护 | `Breaker.Call(ctx, fn) error` |
| 对象存储 | S3/OSS | `Storage.Upload(ctx, key, data) error` |
| 配置管理 | 热更新/多环境 | `Config.Get(key) interface{}` |

---

## 四、分层设计原则

### 原则1：依赖倒置

**What**：上层定义接口，下层实现接口

**Why**：上层不依赖具体实现，可测试、可替换

**How**：
- Biz 层定义 `XxxRepo` 接口（`internal/biz/xxx.go`）
- Data 层实现 `xxxRepo` 结构体（`internal/data/xxx.go`）
- 通过 Wire 依赖注入

### 原则2：单向依赖

**What**：依赖方向 Service → Biz → Data → Infra，禁止反向

**Why**：避免循环依赖，层次清晰

**How**：
- 下层不能 import 上层包
- 通过接口和依赖注入解耦

### 原则3：技术与业务分离

**What**：业务逻辑在 Biz 层，技术实现在 Data + Infra + pkg

**Why**：技术栈变更不影响业务逻辑

**How**：
- Biz 层只调用 Repository 接口，不关心 MySQL 还是 MongoDB
- Data 层可替换实现（MySQL → PostgreSQL）

### 原则4：pkg 层跨层复用

**What**：pkg 提供纯工具函数，任意层可直接调用

**Why**：避免重复代码，统一工具使用

**How**：
- pkg 无状态、无依赖、纯函数
- 所有层都可以 `import "xxx/pkg/crypto"`

### 原则5：最小知识原则

**What**：每层只知道直接依赖的下一层

**Why**：降低复杂度，易于维护

**How**：
- Service 不知道 Data 层如何实现
- Biz 不知道 Infra 的存在

---

## 五、反模式对比

| 反模式 | 问题 | 正确做法 | 原因 |
|-------|------|---------|------|
| Service 层包含业务规则 | 违反单一职责 | 业务规则移到 Biz 层 | Service 只负责协议适配 |
| Biz 层直接调用数据库 | 违反依赖倒置 | 定义 Repo 接口，Data 层实现 | Biz 不关心持久化技术 |
| Data 层直接调用外部 API | Data 职责膨胀 | 通过 Infra 层客户端 | Data 只管业务数据仓储 |
| Infra 层包含业务逻辑 | 基础设施被污染 | 业务逻辑在 Biz 层 | Infra 提供技术能力 |
| 有状态工具放 pkg | pkg 层被污染 | 有状态的放 Infra 层 | pkg 只放纯函数 |
| 所有工具都放 Infra | Infra 过于庞杂 | 纯函数放 pkg，有状态放 Infra | 职责分离 |

---

## 六、分层职责边界

### 完整职责表

| 逻辑类型 | 应该放在 | 示例 |
|---------|---------|------|
| HTTP 参数解析 | Service | query string → struct |
| 格式校验（邮箱/地址） | Service（调用 pkg） | `pkg.IsEmail()` |
| 业务规则校验 | **Biz** | 余额充足、权限检查 |
| 流程编排 | **Biz** | 多步骤业务流程 |
| 事务定义 | **Biz** | 调用 `repo.Transaction()` |
| 事务执行 | **Data** | `db.Begin()` / `Commit()` |
| 数据库查询 | **Data** | GORM 查询 |
| 领域对象缓存 | **Data** | Redis 缓存 |
| 外部 API 调用 | **Infra** | HTTP Client 封装 |
| 有状态工具（限流器） | **Infra** | Redis + 滑动窗口 |
| 纯工具函数（UUID） | **pkg** | `pkg.NewUUID()` |
| 哈希计算 | **pkg** | `pkg.HashPassword()` |
| DTO 转换（PB ↔ DO） | Service | Protobuf ↔ 领域对象 |
| DTO 转换（DB ↔ DO） | Data | 数据库模型 ↔ 领域对象 |
| DTO 转换（外部 API） | Infra | 外部响应 → 内部类型 |
| 错误码转换 | Service | error → gRPC codes |

### Data vs Infra vs pkg 决策表

```mermaid
flowchart LR
    Question{这个功能...}
    
    Q1{管理领域对象<br/>生命周期？}
    Q2{需要配置<br/>或初始化？}
    Q3{纯函数？}
    
    Question --> Q1
    Q1 -->|是<br/>CRUD| Data[Data 层]
    Q1 -->|否| Q2
    
    Q2 -->|是<br/>有状态| Infra[Infra 层]
    Q2 -->|否| Q3
    
    Q3 -->|是<br/>无状态| Pkg[pkg 层]
    Q3 -->|否| Unknown[❓需重新分析]
    
    style Data fill:#f0ffe1
    style Infra fill:#ffe1f5
    style Pkg fill:#f5f5f5
    style Unknown fill:#ffcccc
```

---

## 七、典型设计场景

### 场景1：需要调用外部 API

**判断**：
- 调用 TronGrid API 获取余额
- 需要 HTTP Client（有状态）
- 需要配置管理（baseURL）

**结论**：Infra 层

**架构**：
```
Biz 层：定义 AccountRepo.GetBalance()
  ↓
Data 层：实现 accountRepo.GetBalance()
  ↓ 调用
Infra 层：trongridClient.GetBalance()
  ↓ 使用
pkg 层：crypto.Hash()（如需签名）
```

### 场景2：密码加密验证

**判断**：
- Hash 函数（纯函数）
- 无状态、无外部依赖
- 可被任意层复用

**结论**：pkg 层

**使用**：
```
Service 层：调用 pkg.HashPassword(pwd)（校验）
Biz 层：调用 pkg.HashPassword(pwd)（业务逻辑中需要）
Data 层：调用 pkg.VerifyPassword(pwd, hash)（查询时验证）
```

### 场景3：限流器

**判断**：
- 需要 Redis（有状态）
- 需要配置（限流规则）
- 需要初始化

**结论**：Infra 层

**使用**：
```
Service 层：通过中间件使用
  ↓
Infra 层：limiter.Allow(ctx, key, limit)
  ↓ 依赖
Redis + pkg.Time()（时间戳计算）
```

---

*架构师关注：职责划分、依赖关系、设计原则，而非实现细节*
