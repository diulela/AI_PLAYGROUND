# 前端设计模板（架构师视角）

## 组件接口模板

### Page 组件

```tsx
// src/pages/XxxPage.tsx

interface Props {
  // 通常从路由获取参数，无 Props
}

状态管理：
- data: Xxx[] - 页面数据
- loading: boolean - 加载状态
- error: string | null - 错误信息

关键逻辑：
- useEffect: 初始化加载数据
- handleAction: 处理用户操作
- 成功：跳转或刷新
- 失败：显示错误Toast
```

### 可复用组件

```tsx
// src/components/XxxItem.tsx

interface Props {
  data: Xxx;
  isSelected?: boolean;
  isLoading?: boolean;
  onClick?: (id: string) => void;
}

职责：
- 渲染单个数据项
- 处理点击事件
- 显示选中/加载状态

交互：
- 点击时调用 onClick(data.id)
- 加载时禁用交互
```

### 自定义 Hook

```tsx
// src/hooks/useXxx.ts

interface UseXxxReturn {
  data: Xxx | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
}

export function useXxx(id: string): UseXxxReturn

实现策略：
- useEffect 监听 id 变化自动加载
- 提供 refresh 方法手动刷新
- 错误不抛出，通过 error 返回
```

---

## 状态管理模板（Zustand）

### Store 接口定义

```tsx
// src/stores/xxx.ts

interface XxxState {
  // 状态字段
  items: Xxx[];
  selectedId: string | null;
  
  // 同步方法（立即更新状态）
  setItems: (items: Xxx[]) => void;
  selectItem: (id: string) => void;
  
  // 异步方法（调用API）
  fetchItems: () => Promise<void>;
  createItem: (data: CreateXxxRequest) => Promise<Xxx>;
}

持久化策略：
- 哪些字段需要持久化？（localStorage）
- 敏感数据不持久化
```

### 乐观更新模式

```tsx
interface State {
  optimisticMethod: async (params) => Promise<void>
}

实现策略：
1. 保存当前状态：previous := get().field
2. 乐观更新：set({ field: newValue })
3. 调用后端 API
4. 成功：保持新状态
5. 失败：回退状态 set({ field: previous })
```

---

## API 调用模板

### Service 接口

```tsx
// src/services/api-client.ts

// 类型定义
export interface Xxx {
  id: string;
  field: string;
}

export interface ListXxxRequest {
  page?: number;
  page_size?: number;
}

export interface ListXxxResponse {
  items: Xxx[];
  total: number;
}

// API 方法（RESTful）
export const xxxApi = {
  list: (req?: ListXxxRequest): Promise<ListXxxResponse> => 
    apiClient.get("/xxx", { params: req }),
    
  get: (id: string): Promise<Xxx> => 
    apiClient.get(`/xxx/${id}`),
    
  create: (data: Partial<Xxx>): Promise<Xxx> => 
    apiClient.post("/xxx", data),
    
  update: (id: string, data: Partial<Xxx>): Promise<Xxx> => 
    apiClient.put(`/xxx/${id}`, data),
    
  delete: (id: string): Promise<void> => 
    apiClient.delete(`/xxx/${id}`),
};
```

---

## 常用设计模式（策略描述）

### 表单管理（react-hook-form）

```tsx
表单组件设计：
1. 使用 react-hook-form 管理表单状态
2. yup schema 定义校验规则
3. register 绑定字段
4. handleSubmit 处理提交
5. errors 显示错误信息

参考：react-hook-form 文档
```

### 无限滚动

```tsx
列表组件设计：
1. 使用 react-infinite-scroll-component
2. 状态：items[], page, hasMore
3. fetchMore 方法：
   - page++
   - 调用 API 获取下一页
   - append 到 items
   - 更新 hasMore
4. 加载完成显示"没有更多"
```

### 虚拟滚动（长列表优化）

```tsx
长列表优化策略：
1. 使用 react-window 或 react-virtualized
2. 只渲染可见区域的项（如50个）
3. 配置：
   - height: 容器高度
   - itemSize: 单项高度（固定）
   - itemCount: 总数量
4. 性能：支持10000+项流畅滚动
```

### 错误边界

```tsx
组件设计：
- 使用 React.Component（Error Boundary）
- getDerivedStateFromError 捕获错误
- componentDidCatch 记录日志
- 显示 fallback UI
- 包裹可能出错的组件
```

---

## 组件设计原则

### 单一职责

**❌ 反模式**：一个组件做太多事
```
UserProfile 组件：
- 显示用户信息
- 编辑用户信息
- 上传头像
- 修改密码
- 管理权限
```

**✅ 正确**：拆分为多个组件
```
UserProfile（容器）
  ├─ UserAvatar（头像）
  ├─ UserInfo（信息展示）
  ├─ UserEditForm（编辑表单）
  └─ PasswordChangeForm（修改密码）
```

### Props 接口设计

```tsx
interface ComponentProps {
  // 必需数据
  data: Xxx;
  
  // 可选配置
  variant?: "default" | "compact";
  showActions?: boolean;
  
  // 事件回调
  onSelect?: (id: string) => void;
  onDelete?: (id: string) => Promise<void>;
}

设计原则：
- 必需 Props 不带 ?
- 布尔值提供默认值
- 回调使用 on 前缀
- 避免传递整个 Store
```

---

## 实用代码片段

### 防抖输入

```tsx
实现策略：
- 使用 lodash.debounce 或 use-debounce
- 延迟 300ms
- 输入停止后触发搜索
```

### 复制到剪贴板

```tsx
实现策略：
1. 尝试 navigator.clipboard.writeText（现代浏览器）
2. 失败降级：创建 textarea → 选中 → execCommand("copy")
3. 成功显示 Toast 提示
```

### 图片懒加载

```tsx
实现策略：
- 使用 IntersectionObserver API
- 元素进入视口时加载图片
- 加载前显示占位符
- 加载完成显示实际图片（淡入动画）
```
