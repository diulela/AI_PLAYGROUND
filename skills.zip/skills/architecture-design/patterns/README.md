# 设计模板集（代码级）

本目录包含代码级设计模板和实现规范（How 层面）。

## ⚠️ 前置阅读

在使用本目录模板前，**强烈建议先阅读架构思维**：

| 先读 | 再读 | 目的 |
|-----|------|------|
| [architecture/backend-layers.md](../architecture/backend-layers.md) | patterns/backend-patterns.md | 理解分层原则后再套用模板 |
| [architecture/design-thinking.md](../architecture/design-thinking.md) | patterns/api-patterns.md | 理解 DDD 后再设计 API |

**认知顺序**：架构思维（Why & What）→ 代码模板（How）→ 完整案例（Example）

---

## 文件说明

| 文件 | 内容 | 何时使用 | 行数 |
|-----|------|---------|------|
| **api-patterns.md** | protobuf模板、HTTP路由、错误码规范 | 阶段四：API设计 | ~113 行 |
| **backend-patterns.md** | 接口签名、实现要点、设计模式（缓存/事务/幂等） | 阶段四：后端设计 | ~370 行 |
| **frontend-patterns.md** | React组件模板、状态管理、API调用 | 阶段五：前端设计 | ~288 行 |
| **quality-checklist.md** | 39项质量检查清单 | 阶段六：输出文档 | ~55 行 |
| **troubleshooting.md** | 常见问题速查、设计模式对比 | 遇到问题时 | ~50 行 |

---

## 使用方式

AI在设计过程中会根据当前阶段自动加载相应文件，无需手动操作。

**典型流程**：
```
设计 REQ-007 密码设置
  ↓
阶段二：领域建模 → 读 architecture/design-thinking.md（DDD方法）
  ↓
阶段三：架构设计 → 读 architecture/backend-layers.md（5层架构）
  ↓
阶段四：API设计 → 读 patterns/api-patterns.md（protobuf模板）
  ↓
阶段四：后端设计 → 读 patterns/backend-patterns.md（接口签名）
  ↓
阶段五：前端设计 → 读 patterns/frontend-patterns.md（组件模板）
  ↓
阶段六：质量检查 → 读 patterns/quality-checklist.md（检查清单）
```

---

## 与其他目录的关系

```
architecture/（架构思维：Why & What）
    ↓ 指导
patterns/（代码模板：How）
    ↓ 应用
examples/（完整案例：Example）
```

**Token 优化策略**：
- 通过按需加载机制，AI 只在需要时才读取对应文件
- 架构思维和代码模板分离，避免重复加载冗余内容
- 相比单文件加载全部内容，节省约 50-70% token

---

*模板是手段，架构思维是核心*
