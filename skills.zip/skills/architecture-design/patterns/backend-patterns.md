# 后端设计模板（代码接口与设计模式）

> 代码级模板：接口签名、实现要点、设计模式

**前置阅读**：架构思维和分层原则请先阅读 [architecture/backend-layers.md](../architecture/backend-layers.md)

---

## 一、接口设计规范

### Service 层接口

```go
type XxxService struct {
    pb.UnimplementedXxxServiceServer
    uc *biz.XxxUsecase
}
```

**职责**：
- 参数校验：必填、格式、范围（可调用 pkg 校验器）
- 调用 Biz 层：`uc.Method(...)`
- 错误码映射：业务错误 → gRPC codes
- DTO 转换：`pb.Request` ↔ 领域对象

### Biz 层接口

```go
type XxxUsecase struct {
    repo XxxRepo  // Repository 接口（在 Biz 层定义）
}

// Repository 接口定义（依赖倒置）
type XxxRepo interface {
    Create(ctx, x *Xxx) error
    Get(ctx, id) (*Xxx, error)
}
```

**职责**：
- 定义 Repository 接口
- 业务规则校验（余额、权限、状态）
- 流程编排（多步骤操作）
- 事务管理（调用 Data 层的 Transaction）

**业务流程模板**（伪代码）：
```
业务流程（Method）：
1. 参数业务校验：
   - 调用 pkg.Validator() 格式校验
   - 业务规则检查（余额、权限）
2. 流程编排：
   step1 := repo.GetXxx()
   if condition: step2 := repo.UpdateXxx()
3. 返回领域对象
```

### Data 层接口

```go
type xxxRepo struct {
    db       *gorm.DB
    cache    *redis.Client
    infraClient *infra.XxxClient  // 可选：依赖 Infra 层
}

// 实现 Biz 层定义的 Repository 接口
func (r *xxxRepo) Get(ctx, id) (*biz.Xxx, error)
```

**职责**：
- 实现 Repository 接口
- 数据库 CRUD（GORM）
- 缓存管理（Redis）
- 调用 Infra 层客户端获取外部数据
- DTO 转换：数据库模型 ↔ 领域对象

**实现要点**：
- 缓存策略：Cache-Aside、Write-Through
- 分页：`LIMIT/OFFSET` 或游标分页
- 事务：提供 `Transaction(fn)` 方法
- 错误处理：返回 Kratos 错误（`errors.NotFound`）

### Infra 层接口

```go
type XxxClient struct {
    httpClient *http.Client  // 有状态
    config     Config
    log        *log.Helper
}

func NewXxxClient(conf, logger) *XxxClient  // 需初始化

func (c *XxxClient) Method(ctx, params) (*Response, error)
```

**职责**：
- 封装外部系统调用（HTTP/gRPC/SDK）
- 管理连接池和配置
- 超时和重试控制
- 错误标准化
- 类型定义（外部 API 响应类型，非领域对象）

**实现要点**：
- 超时：`context.WithTimeout` 或 `http.Client.Timeout`
- 重试：指数退避（1s, 2s, 4s）
- 多环境：根据配置选择 baseURL（mainnet/testnet）
- 错误映射：外部错误码 → 标准化错误

### pkg 层接口

```go
// pkg/crypto/password.go
func HashPassword(password string) (hash string, err error)
func VerifyPassword(password, hash string) bool

// pkg/validator/address.go  
func IsValidTronAddress(address string) bool

// pkg/idgen/uuid.go
func NewUUID() string
```

**职责**：
- 提供纯函数工具
- 无状态、无副作用
- 无外部依赖（不调用数据库、Redis、外部 API）
- 无业务逻辑

**典型内容**：
- 加密工具（Hash、AES、RSA 纯函数）
- 字符串工具（格式化、转换）
- 时间工具（格式化、计算）
- 校验器（格式验证）
- 编解码器（Base64、Hex）
- ID 生成器（UUID、Snowflake）
- 常量定义（错误码、枚举）

---

## 二、常用设计模式

### 缓存模式

**策略描述**：
```
1. 读取时：先查缓存 → 未命中查数据库 → 写入缓存
2. 更新时：更新数据库 → 删除缓存（Cache-Aside）
3. TTL 设置：根据数据变化频率（高频=30s，低频=5min）
4. 降级：缓存故障时直接查数据库
```

**Key 设计**：
- 格式：`{resource}:{id}`（如 `token:0x123`）
- 层级：`{module}:{resource}:{id}`（如 `wallet:account:123`）

**实现要点**：
```go
// Data 层实现
func (r *xxxRepo) Get(ctx, id) (*Xxx, error) {
  // 1. 先查缓存
  cacheKey := fmt.Sprintf("xxx:%s", id)
  if cached := r.cache.Get(ctx, cacheKey); cached != nil {
    return cached, nil
  }
  
  // 2. 查数据库
  result := r.db.Find(...)
  
  // 3. 写入缓存
  r.cache.Set(ctx, cacheKey, result, 5*time.Minute)
  
  return result, nil
}
```

### 事务模式

**策略描述**：
```
Biz 层：定义事务边界
  业务流程：
    1. 调用 repo.Transaction(ctx, func(txCtx) {
         2. repo.CreateA(txCtx, a)
         3. repo.CreateB(txCtx, b)
       })
    4. 任一步失败自动回滚

Data 层：执行事务
  Transaction(ctx, fn):
    1. db.Begin()
    2. 执行 fn
    3. 成功 Commit，失败 Rollback
```

**实现要点**：
```go
// Biz 层调用
func (uc *XxxUsecase) CreateWithDeps(ctx, params) error {
  return uc.repo.Transaction(ctx, func(txCtx) error {
    if err := uc.repo.CreateA(txCtx, a); err != nil {
      return err
    }
    if err := uc.repo.CreateB(txCtx, b); err != nil {
      return err // 自动回滚
    }
    return nil
  })
}

// Data 层实现
func (r *xxxRepo) Transaction(ctx, fn func(txCtx) error) error {
  tx := r.db.Begin()
  defer func() {
    if r := recover(); r != nil {
      tx.Rollback()
    }
  }()
  
  txCtx := context.WithValue(ctx, "tx", tx)
  if err := fn(txCtx); err != nil {
    tx.Rollback()
    return err
  }
  
  return tx.Commit().Error
}
```

### 幂等性模式

**策略描述**：
```
1. 请求包含 idempotency_key（客户端生成 UUID）
2. Data 层表添加唯一索引：uk_idempotency_key
3. 业务流程：
   - 查询 key 是否存在
   - 存在：返回原结果（幂等）
   - 不存在：创建新记录
   - 并发冲突：唯一索引报错 → 重新查询
```

**适用场景**：写操作（创建、支付、转账）

**实现要点**：
```go
// Biz 层
func (uc *XxxUsecase) Create(ctx, params, idempotencyKey) (*Result, error) {
  // 1. 检查幂等性
  if existing := uc.repo.GetByIdempotencyKey(ctx, idempotencyKey); existing != nil {
    return existing, nil  // 返回原结果
  }
  
  // 2. 创建新记录
  result := &Xxx{IdempotencyKey: idempotencyKey, ...}
  if err := uc.repo.Create(ctx, result); err != nil {
    // 3. 并发冲突检测
    if errors.Is(err, ErrDuplicateKey) {
      return uc.repo.GetByIdempotencyKey(ctx, idempotencyKey)
    }
    return nil, err
  }
  
  return result, nil
}
```

---

## 三、业务规则表达方式

### 方式1：列表描述

```markdown
业务规则：
1. 密码长度 ≥8
2. 包含大小写字母
3. 包含数字
4. 强度评分：满足条件数 ≤1=弱，2-3=中，≥4=强
```

### 方式2：伪代码

```
calculatePasswordStrength(password):
  score = 0
  if length ≥ 8: score++
  if hasUpperAndLower: score++
  if hasNumber: score++
  
  return score ≤ 1 → WEAK, 2-3 → MEDIUM, ≥4 → STRONG
```

### 方式3：状态机

```mermaid
stateDiagram-v2
    [*] --> PENDING: 创建
    PENDING --> CONFIRMED: 成功
    PENDING --> FAILED: 失败
    CONFIRMED --> [*]
    FAILED --> [*]
```

---

## 四、典型设计场景

### 场景1：需要调用外部 API

**判断**：
- 调用 TronGrid API 获取余额
- 需要 HTTP Client（有状态）
- 需要配置管理（baseURL）

**结论**：Infra 层

**架构**：
```
Biz 层：定义 AccountRepo.GetBalance()
  ↓
Data 层：实现 accountRepo.GetBalance()
  ↓ 调用
Infra 层：trongridClient.GetBalance()
  ↓ 使用
pkg 层：crypto.Hash()（如需签名）
```

**代码模板**：
```go
// Biz 层定义接口
type AccountRepo interface {
  GetBalance(ctx, address, network) (*Balance, error)
}

// Data 层实现
type accountRepo struct {
  trongridClient *infra.TronGridClient
}

func (r *accountRepo) GetBalance(ctx, address, network) (*Balance, error) {
  // 调用 Infra 层获取原始数据
  rawBalance, err := r.trongridClient.GetBalance(ctx, address, network)
  if err != nil {
    return nil, err
  }
  
  // 转换为领域对象
  return &Balance{
    Address: address,
    Amount:  rawBalance.Balance,
    Unit:    "TRX",
  }, nil
}

// Infra 层实现
type TronGridClient struct {
  httpClient *http.Client
  config     Config
}

func (c *TronGridClient) GetBalance(ctx, address, network) (*RawBalance, error) {
  url := c.config.GetBaseURL(network) + "/wallet/getaccount"
  // HTTP 调用逻辑...
  return response, nil
}
```

### 场景2：密码加密验证

**判断**：
- Hash 函数（纯函数）
- 无状态、无外部依赖
- 可被任意层复用

**结论**：pkg 层

**使用**：
```
Service 层：调用 pkg.HashPassword(pwd)（校验）
Biz 层：调用 pkg.HashPassword(pwd)（业务逻辑中需要）
Data 层：调用 pkg.VerifyPassword(pwd, hash)（查询时验证）
```

**代码模板**：
```go
// pkg/crypto/password.go
func HashPassword(password string) (string, error) {
  bytes, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
  return string(bytes), err
}

func VerifyPassword(password, hash string) bool {
  err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
  return err == nil
}

// Service 层使用
func (s *UserService) Login(ctx, req) (*Response, error) {
  // 参数校验
  if !pkg.ValidatePassword(req.Password) {
    return nil, errors.BadRequest("INVALID_PASSWORD", "密码格式错误")
  }
  
  // 调用 Biz 层
  user, err := s.uc.Authenticate(ctx, req.Username, req.Password)
  ...
}

// Biz 层使用
func (uc *UserUsecase) Authenticate(ctx, username, password) (*User, error) {
  user, err := uc.repo.GetByUsername(ctx, username)
  if err != nil {
    return nil, err
  }
  
  // 使用 pkg 验证密码
  if !pkg.VerifyPassword(password, user.PasswordHash) {
    return nil, errors.Unauthorized("INVALID_CREDENTIALS", "用户名或密码错误")
  }
  
  return user, nil
}
```

### 场景3：限流器

**判断**：
- 需要 Redis（有状态）
- 需要配置（限流规则）
- 需要初始化

**结论**：Infra 层

**使用**：
```
Service 层：通过中间件使用
  ↓
Infra 层：limiter.Allow(ctx, key, limit)
  ↓ 依赖
Redis + pkg.Time()（时间戳计算）
```

**代码模板**：
```go
// Infra 层实现
type RateLimiter struct {
  redis  *redis.Client
  config LimiterConfig
}

func NewRateLimiter(redis *redis.Client, config LimiterConfig) *RateLimiter {
  return &RateLimiter{redis: redis, config: config}
}

func (l *RateLimiter) Allow(ctx, key string, limit int) (bool, error) {
  now := pkg.Now().Unix()  // 使用 pkg 时间工具
  windowKey := fmt.Sprintf("ratelimit:%s:%d", key, now/60)
  
  count, err := l.redis.Incr(ctx, windowKey).Result()
  if err != nil {
    return false, err
  }
  
  if count == 1 {
    l.redis.Expire(ctx, windowKey, 60*time.Second)
  }
  
  return count <= int64(limit), nil
}

// Service 层中间件使用
func RateLimitMiddleware(limiter *infra.RateLimiter) middleware.Middleware {
  return func(handler middleware.Handler) middleware.Handler {
    return func(ctx, req) (interface{}, error) {
      key := getClientIP(ctx)
      allowed, err := limiter.Allow(ctx, key, 100)  // 100 req/min
      if err != nil {
        return nil, err
      }
      if !allowed {
        return nil, errors.TooManyRequests("RATE_LIMIT_EXCEEDED", "请求过于频繁")
      }
      return handler(ctx, req)
    }
  }
}
```

---

*代码模板应用原则：先理解架构思维（architecture/），再套用模板（patterns/）*
