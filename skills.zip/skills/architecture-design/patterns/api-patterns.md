# API 设计模板（protobuf）

## 常用请求模式

```protobuf
// 1. 创建资源
message CreateXxxRequest {
  string field = 1;              // 业务字段
  string idempotency_key = 99;   // 幂等性key（写操作推荐）
}

// 2. 查询单个资源
message GetXxxRequest {
  string id = 1;
}

// 3. 查询列表
message ListXxxRequest {
  int32 page = 1;                // 页码（从1开始）
  int32 page_size = 2;           // 每页数量（默认20，最大100）
  string filter = 3;             // 筛选条件
  string sort_by = 4;            // 排序字段
  string sort_order = 5;         // "asc" | "desc"
}

// 4. 更新资源
message UpdateXxxRequest {
  string id = 1;
  Xxx data = 2;                  // 嵌套消息
}

// 5. 删除资源
message DeleteXxxRequest {
  string id = 1;
}
```

## 常用响应模式

```protobuf
// 1. 单对象响应
message XxxResponse {
  bool success = 1;
  string message = 2;
  Xxx data = 3;
}

// 2. 列表响应（带分页）
message ListXxxResponse {
  repeated Xxx items = 1;
  int32 total = 2;
  int32 page = 3;
  int32 page_size = 4;
  bool has_more = 5;
}

// 3. 批量操作响应
message BatchXxxResponse {
  int32 success_count = 1;
  int32 failure_count = 2;
  repeated Error errors = 3;
}
```

## HTTP 路由规范（RESTful）

| 操作 | HTTP 方法 | 路径模式 | protobuf 注解 |
|-----|----------|---------|--------------|
| 查询列表 | GET | `/wallet/v1/tokens` | `get: "/wallet/v1/tokens"` |
| 查询单个 | GET | `/wallet/v1/tokens/{id}` | `get: "/wallet/v1/tokens/{id}"` |
| 创建 | POST | `/wallet/v1/tokens` | `post: "/wallet/v1/tokens" body: "*"` |
| 更新 | PUT | `/wallet/v1/tokens/{id}` | `put: "/wallet/v1/tokens/{id}" body: "*"` |
| 部分更新 | PATCH | `/wallet/v1/tokens/{id}` | `patch: "/wallet/v1/tokens/{id}" body: "*"` |
| 删除 | DELETE | `/wallet/v1/tokens/{id}` | `delete: "/wallet/v1/tokens/{id}"` |

## 错误码规范（gRPC）

| gRPC Code | HTTP 状态 | 使用场景 | 前端处理建议 |
|-----------|---------|---------|------------|
| INVALID_ARGUMENT | 400 | 参数校验失败 | 显示具体错误提示 |
| UNAUTHENTICATED | 401 | 未认证/Token过期 | 跳转登录页 |
| PERMISSION_DENIED | 403 | 无权限 | 提示权限不足 |
| NOT_FOUND | 404 | 资源不存在 | 提示资源不存在或已删除 |
| ALREADY_EXISTS | 409 | 资源冲突 | 提示已存在，询问是否覆盖 |
| FAILED_PRECONDITION | 412 | 前置条件不满足 | 提示需要先完成XX操作 |
| RESOURCE_EXHAUSTED | 429 | 限流 | 提示稍后重试 |
| UNAVAILABLE | 503 | 服务不可用 | 提示服务繁忙，自动重试 |
| INTERNAL | 500 | 服务器错误 | 通用错误提示，记录错误 |

## 字段类型选择

| 业务数据 | protobuf 类型 | 原因 |
|---------|--------------|------|
| 金额 | string | 避免浮点数精度丢失 |
| 时间戳 | int64 | Unix 时间戳（秒/毫秒） |
| 布尔标志 | bool | 明确 true/false |
| 枚举 | enum | 类型安全、避免字符串拼写错误 |
| ID | string | 通用性强（支持 UUID/哈希） |
| 百分比 | double | 需要小数（如涨跌幅） |
| 计数 | int32/int64 | 根据数值范围选择 |

## API 设计检查清单

设计完成后检查：

- [ ] 使用 RESTful 风格路径
- [ ] Request/Response 消息命名清晰
- [ ] 必填字段有注释说明
- [ ] 写操作包含 idempotency_key
- [ ] 列表接口支持分页（page/page_size）
- [ ] 定义至少 3 种错误码
- [ ] HTTP 路由映射正确（google.api.http）
- [ ] 字段类型选择合理（避免精度丢失）
