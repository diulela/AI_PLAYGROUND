# REQ-XXX 需求名称 — 技术设计方案（骨架）

> 需求链接：[REQ-XXX](...)  
> 版本：v1.0  
> 说明：骨架示例，展示十章结构

---

## 一、需求与技术映射

**用户故事**：[从需求清单复制]

**核心验收标准**：
- [ ] 验收1
- [ ] 验收2

**技术映射**：

| 需求元素 | 领域对象 | API | 前端组件 |
|---------|---------|-----|---------|
| XX行为 | XX对象 | XxxAPI | XxxPage |

---

## 二、领域建模（DDD）⭐

**ObjectName — 实体/值对象**

职责：[负责什么？]  
属性：field1: Type, field2: Type  
业务规则：约束/不变量/状态转换

**对象关系**：

```mermaid
classDiagram
    class A {
        +field: Type
    }
    A "1" *-- "many" B
```

---

## 三、架构设计⭐

**整体架构**：

```mermaid
graph LR
    前端 --> 后端 --> 外部系统
```

**决策1：[标题]**

问题：[什么问题？]  
方案对比：A优缺点 vs B优缺点  
决策：选X，权衡：[为什么？]

**分层职责**：
- 后端：Service（参数校验）→ Biz（业务规则）→ Data（数据访问）
- 前端：Page（状态）→ Component（UI）→ Store（全局）

---

## 四、API 契约

```protobuf
service XxxService {
  rpc Method(Request) returns (Response);
}
```

**错误码**：INVALID_ARGUMENT / NOT_FOUND / INTERNAL

---

## 五、后端设计

**Data层**：
```go
type XxxRepo interface { Method(ctx, params) (result, error) }
实现要点：数据来源、缓存策略、错误处理
```

**Biz层**：
```
业务流程：
1. 校验 → 2. 规则判断 → 3. 调用Data → 4. 返回
```

**Service层**：参数校验 → 调用Biz → 错误码映射 → DTO转换

---

## 六、前端设计

**组件架构**：
```
XxxPage
  ├─ Toolbar
  └─ List
      └─ Item × N
```

**Props接口**：
```tsx
interface XxxProps { data: Xxx; onClick?: (id) => void; }
```

**状态策略**：乐观更新/失败回退

**交互流程**：

```mermaid
sequenceDiagram
    用户->>页面: 操作
    页面->>API: 请求
    API-->>页面: 响应
```

---

## 七、实现约束

**性能**：API < 500ms, 页面加载 < 1s  
**安全**：HTTPS、加密、限流  
**测试**：单元测试（Biz层）、组件测试

---

## 八、技术债务与演进

**v1.0限制**：[XX限制 | XX影响 | P级别]

**v2.0演进**：增强功能、优化性能

---

## 九、风险与缓解

| 风险 | 概率 | 缓解 |
|-----|------|------|
| XX风险 | 中 | XX措施 |

---

## 十、实施路径

**开发顺序**：Phase1后端 → Phase2前端 → Phase3联调

**里程碑**：
- [ ] 后端完成（Day X）
- [ ] 前端完成（Day X）

---

*v1.0 | 预计X天*
