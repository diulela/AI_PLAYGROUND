# 需求到代码设计技能

将产品需求清单（REQ-XXX）转换为架构师视角的技术设计方案。

---

## 💡 一句话说明

**输入**需求清单 → **执行**六阶段设计流程 → **输出**架构师视角的技术设计方案（领域建模+架构决策+接口契约）

---

## 🎯 快速开始

### 使用方法

```bash
# 设计单个需求
你: 设计 REQ-043 网络节点切换
AI: [执行六阶段流程] → 产出 prd/code-design/REQ-043_技术设计方案.md

# 设计整个模块
你: 设计模块八：网络管理
AI: [批量设计] → 产出多份技术设计方案 + 模块汇总
```

### 第一次使用？

1. **阅读核心流程**：[SKILL.md](SKILL.md) - 了解六阶段设计流程
2. **查看设计案例**：[examples.md](examples.md) - 三类需求案例索引
3. **查看文档骨架**：[example-document.md](example-document.md) - 文档结构示例

---

## 📐 设计流程概览

```
阶段一(5min)：需求理解 → 技术映射
阶段二(10min)：领域建模（DDD）⭐
阶段三(15min)：架构设计（决策分析）⭐
阶段四(10min)：API契约 + 后端设计
阶段五(10min)：前端设计
阶段六(5min)：输出文档
```

详细步骤见 [SKILL.md](SKILL.md)

---

## 📄 输出产物

### 技术设计文档

**路径**：`prd/code-design/REQ-XXX-需求名称_技术设计方案.md`

**十章结构**：需求映射 | 领域建模⭐ | 架构设计⭐ | API契约 | 后端设计 | 前端设计 | 实现约束 | 技术债务 | 风险 | 实施路径

**特点**：
- ✅ 架构师视角（Why + What，非How）
- ✅ 接口优先（protobuf/Repository/Props完整定义）
- ✅ 决策显式（ADR风格记录方案对比和权衡）
- ✅ 业务规则显式（伪代码/流程图，非代码实现）
- ❌ 不包含详细代码实现（参考 patterns/ 模板）

**文档长度**：300-500行（vs 原1000+行，节省50-70% token）

---

## 🗂️ 文件结构

```
requirement-to-code-design/
├── SKILL.md                 ← 核心流程（AI执行）
├── architecture/            ← 架构思维（Why & What）
│   ├── README.md            ← 架构思维导航
│   ├── design-thinking.md   ← 领域建模+架构决策（DDD+ADR）
│   ├── backend-layers.md    ← 后端分层架构（5层体系）
│   └── frontend-architecture.md ← 前端分层架构（React组件设计）
├── patterns/                ← 代码模板（How）
│   ├── README.md            ← 模板导航
│   ├── api-patterns.md      ← API设计模板
│   ├── backend-patterns.md  ← 后端接口模板
│   ├── frontend-patterns.md ← 前端组件模板
│   ├── quality-checklist.md ← 质量检查清单
│   └── troubleshooting.md   ← 常见问题速查
├── examples/                ← 完整案例（Example）
│   ├── data-display.md      ← 数据展示类案例
│   ├── data-change.md       ← 数据变更类案例
│   └── sensitive-operation.md ← 敏感操作类案例
├── examples.md              ← 案例索引（导航）
├── example-document.md      ← 文档骨架（结构参考）
└── README.md                ← 本文档（概述）
```

**认知层次**：
```
architecture/（架构思维）→ patterns/（代码模板）→ examples/（完整案例）
     ↓ Why & What             ↓ How                    ↓ Example
```

---

## 🎓 适用角色

| 角色 | 如何使用 |
|-----|---------|
| **架构师** | 评审技术方案、记录架构决策（ADR）、识别技术风险 |
| **Tech Lead** | 指导团队遵循架构规范、Review 设计质量、规划技术演进 |
| **开发人员** | 阅读设计文档理解业务逻辑、参考接口契约并行开发、根据实现要点编码 |
| **产品经理** | 理解技术实现边界和约束、评估需求成本、了解技术债务计划 |

---

## 🔗 与其他技能协作

```
[竞品分析技能] → 产出需求清单
     ↓
[本技能：需求到代码设计] → 产出技术设计方案
     ↓
[编码实施] → 参考设计文档 + patterns/ 模板 → 产出代码
     ↓
[需求追踪] → 更新实现状态
```

---

## 📚 设计过程中按需查阅

| 需要什么 | 查阅哪里 | 类型 |
|---------|---------|------|
| 流程步骤 | [SKILL.md](SKILL.md) | 流程 |
| 领域建模（DDD） | [architecture/design-thinking.md](architecture/design-thinking.md) | 架构思维 |
| 架构决策（ADR） | [architecture/design-thinking.md](architecture/design-thinking.md) | 架构思维 |
| 后端分层架构（5层） | [architecture/backend-layers.md](architecture/backend-layers.md) | 架构思维 |
| 前端分层架构（React） | [architecture/frontend-architecture.md](architecture/frontend-architecture.md) | 架构思维 |
| API 设计模板 | [patterns/api-patterns.md](patterns/api-patterns.md) | 代码模板 |
| 后端接口模板 | [patterns/backend-patterns.md](patterns/backend-patterns.md) | 代码模板 |
| 前端组件模板 | [patterns/frontend-patterns.md](patterns/frontend-patterns.md) | 代码模板 |
| 质量检查清单 | [patterns/quality-checklist.md](patterns/quality-checklist.md) | 代码模板 |
| 数据展示类案例 | [examples/data-display.md](examples/data-display.md) | 完整案例 |
| 数据变更类案例 | [examples/data-change.md](examples/data-change.md) | 完整案例 |
| 敏感操作类案例 | [examples/sensitive-operation.md](examples/sensitive-operation.md) | 完整案例 |
| 常见问题 | [patterns/troubleshooting.md](patterns/troubleshooting.md) | 问题排查 |

---

## 🎓 自我学习能力

技能可从每次设计中持续学习，形成项目专属知识库。

**流程**：设计完成 → AI分析 → 发现新模式 → 用户确认 → 写入（🔶实验性） → 使用3次 → 转正式

**学习内容**：架构决策、领域建模、API模式、反模式、最佳实践

**质量保证**：自动校验 + 用户审查 + 试用期 + 来源追踪

详见 [LEARNING.md](LEARNING.md)

---

## ⚡ Token 效率

| 对比项 | 旧版 | 新版（架构师视角） | 节省 |
|-------|------|-----------------|------|
| 单个设计文档 | 1000+行 | 300-500行 | 50-70% |
| 技能主文档 | - | 307行 | - |
| 模板文件总计 | - | 830行 | - |

**按需加载策略**：AI根据设计阶段只读取需要的 pattern 文件，不会一次加载所有内容。

---

## 🏆 最佳实践

1. **先建模再设计** - 先识别领域对象和职责，再映射到技术实现
2. **决策要有理有据** - 记录问题+方案对比+权衡，未来重构有依据
3. **接口定义要完整** - protobuf/Repository/Props 完整定义，前后端据此并行开发
4. **业务规则要显式** - 用伪代码/列表/状态机描述，不埋在代码里
5. **技术债务要规划** - 明确v1.0限制和v2.0/v3.0演进方向

详见 [SKILL.md](SKILL.md#设计原则)

---

## 📖 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v2.0 | 2026-02-26 | 重构为架构师视角：增加领域建模、架构决策；移除完整代码实现 |
| v1.0 | 2026-02-26 | 初版 |

---

*维护者：Cursor AI Team*
