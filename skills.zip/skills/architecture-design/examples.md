# 技术设计完整案例

架构师视角的典型需求设计示例。按需求类型分类，按需查阅。

---

## 📚 案例索引

### 按需求类型查阅

| 需求类型 | 典型特征 | 设计重点 | 查看案例 |
|---------|---------|---------|---------|
| **数据展示类** | 查询为主、实时刷新、分页排序 | 缓存策略、查询性能 | [data-display.md](examples/data-display.md) |
| **数据变更类** | 写操作、事务、幂等性 | 事务一致性、幂等设计 | [data-change.md](examples/data-change.md) |
| **敏感操作类** | 敏感数据、安全验证、防护 | 加密传输、权限验证 | [sensitive-operation.md](examples/sensitive-operation.md) |

### 设计指南

| 主题 | 内容 | 文件 |
|-----|------|------|
| **领域建模** | 如何识别对象、定义职责、提炼规则 | [design-thinking.md](architecture/design-thinking.md#一领域建模ddd) |
| **架构决策** | ADR模板、决策记录、常见场景 | [design-thinking.md](architecture/design-thinking.md#二架构决策adr) |
| **后端分层架构** | 5层职责、判断规则、设计原则 | [backend-layers.md](architecture/backend-layers.md) |

---

## 🎯 使用建议

### 场景1：设计数据展示类需求
```
需求：用户查看代币列表
查阅：examples/data-display.md
学习：领域建模（Token/TokenAmount）、缓存决策、排序策略
```

### 场景2：设计数据变更类需求
```
需求：用户发起转账交易
查阅：examples/data-change.md
学习：领域建模（Transaction/状态机）、幂等性设计、乐观更新
```

### 场景3：设计敏感操作类需求
```
需求：查看助记词
查阅：examples/sensitive-operation.md
学习：加密传输策略、临时密钥设计、防截屏方案
```

### 场景4：学习如何做领域建模
```
查阅：architecture/design-thinking.md
学习：从用户故事提取名词 → 识别对象类型 → 定义职责和规则 → 画关系图
```

---

## 📖 案例概览

### 案例一：数据展示类（REQ-028 代币列表展示）

**核心内容**：
- 领域建模：Token（实体）、TokenAmount（值对象）、Price（值对象）
- 架构决策：Redis缓存30s vs 无缓存、后端排序 vs 前端排序
- API契约：ListTokens（支持分页、排序、筛选）
- 后端设计：缓存策略、排序逻辑
- 前端设计：虚拟滚动、自动刷新

👉 [查看完整案例](examples/data-display.md)

---

### 案例二：数据变更类（REQ-057 交易签名与广播）

**核心内容**：
- 领域建模：Transaction（实体）、TransactionStatus（值对象）、状态机
- 架构决策：幂等性Key vs 分布式锁、轮询 vs WebSocket
- API契约：SignAndBroadcast（支持幂等性）
- 后端设计：幂等性检查、事务状态管理
- 前端设计：乐观更新、状态轮询

👉 [查看完整案例](examples/data-change.md)

---

### 案例三：敏感操作类（REQ-015 助记词展示）

**核心内容**：
- 领域建模：Mnemonic（值对象）、EncryptedMnemonic（值对象）
- 架构决策：临时密钥 vs 永久密钥、防截屏方案
- API契约：GetMnemonic（密码验证、临时加密）
- 后端设计：临时密钥生成、Redis TTL、审计日志
- 前端设计：倒计时自动隐藏、内存清理

👉 [查看完整案例](examples/sensitive-operation.md)

---

## 🛠️ 设计指南

### 领域建模方法

从用户故事中提取名词 → 判断对象类型（实体/值对象/聚合根）→ 定义职责和业务规则 → 画关系图

👉 [查看详细指南](architecture/design-thinking.md#一领域建模ddd)

### 架构决策模板

记录决策过程：问题 → 方案对比 → 决策 → 权衡 → 演进路线

👉 [查看详细指南](architecture/design-thinking.md#二架构决策adr)

### 后端分层架构

5 层架构体系、分层判断规则、设计原则、反模式对比

👉 [查看详细指南](architecture/backend-layers.md)

---

*提示：这些案例展示架构师视角的设计思路，实际编码时参考 patterns/ 目录的模板*
