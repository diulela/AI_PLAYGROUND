---
name: architecture-design
description: 架构师视角的架构设计工作流：将需求转换为领域建模、架构决策、语义契约的设计方案（不产出代码实现）。支持DDD建模、ADR决策分析、API语义契约、后端分层架构、前端组件架构。输出纯架构文档（图表+文字描述，无代码）。当用户要求"架构设计 REQ-XXX"、"设计 REQ-XXX"时使用此技能。使用中文输出。
---

# 架构设计工作流（架构师视角）

---

⚠️⚠️⚠️ **AI 执行约束（必读 - 贯穿全流程）** ⚠️⚠️⚠️

**你的角色**：架构师（不是开发者！）

**严格禁止输出**：
- ❌ 任何可执行的代码（Go、TypeScript、Python等）
- ❌ protobuf 定义（`.proto` 文件内容）
- ❌ 接口签名（`interface`、`type`、函数签名等）
- ❌ SQL 语句、配置文件、JSON Schema

**输出行数限制**：
- 单需求文档 ≤ 600 行 | 模块文档 ≤ 1000 行 | 超过立即停止！

**只能输出**：
- ✅ 架构图（Mermaid：架构图、流程图、类图、序列图）
- ✅ 文字描述（语义契约、职责说明、业务规则）
- ✅ 表格对比（方案对比、权衡分析）
- ✅ 伪代码/流程描述（bullet points，描述业务步骤）

---

## 核心理念

**架构设计 ≠ 代码实现**

架构师职责：定义 What（做什么）、Why（为什么）、How（怎么做，宏观层面）

**架构师关注**：
- **领域建模（DDD）** — 对象职责、业务规则、对象关系（不涉及具体字段类型）
- **架构决策（Why + 权衡）** — 为什么选这个方案？牺牲了什么？成本是多少？
- **语义契约** — API/Repository/Component 的语义职责（不写接口签名）
- **分层归属（5层架构）** — 明确每个功能属于哪一层，每层的职责边界
- **演进规划（v1.0 → v2.0 → v3.0）** — 当前限制、未来增强、技术债务显式管理
- **非功能性需求** — 性能指标、安全要求、可维护性、可测试性
- **边界意识** — MVP vs 完整版、做什么/不做什么、投入产出比
- **风险识别** — 技术风险、业务风险、缓解措施、应急预案

**开发者职责**（由 `code-implementation` 技能处理）：
- protobuf 定义（字段、类型、验证规则）
- 接口签名（Go interface、TypeScript Props）
- 代码实现（业务逻辑、数据访问、UI组件）

## 使用场景判断

| 用户输入 | 执行流程 | 输出文档 |
|---------|---------|---------|
| "架构设计 REQ-XXX"<br>"设计 REQ-XXX" | 完整六阶段架构设计 | `prd/architecture/REQ-XXX_架构设计方案.md` |
| "架构设计模块X" | 批量设计多个需求 | 多份架构文档 + 模块汇总 |
| "设计XXX的领域模型" | 聚焦领域建模（阶段二） | DDD 建模片段 |
| "设计XXX的架构" | 聚焦架构设计（阶段三） | 架构决策片段 |
| "设计XXX的API语义" | 聚焦API语义（阶段四） | API语义契约片段 |

**不使用此技能的场景**：
- "实现 REQ-XXX"：使用 `code-implementation` 技能（产出代码）
- "protobuf定义"：使用 `code-implementation` 技能
- "接口签名"：使用 `code-implementation` 技能

## 设计流程（六阶段）

### 阶段一：需求理解与技术映射（5分钟）

**目标**：将用户需求转换为技术要素

**步骤**：
1. 读取 `prd/requirements/README.md`（总表）和 `modules/0N-模块名.md`（详情）
2. 提取：用户故事、验收标准、依赖、设计规格
3. 识别需求类型，确定设计重点
4. 映射技术要素

**需求类型 → 设计重点**：
- **数据展示** → 领域查询模型、缓存策略
- **数据变更** → 领域命令模型、事务一致性、幂等性
- **用户交互** → 前端状态管理、用户反馈
- **敏感操作** → 安全验证、加密、审计

**技术要素映射表**：

| 需求元素 | 技术要素 | 输出内容 |
|---------|---------|---------|
| 用户故事的"行为" | 领域对象 + API | 聚合根、实体、值对象 |
| 验收标准的"数据" | 领域对象属性 | 对象职责、业务规则 |
| 验收标准的"交互" | 前端组件结构 | 组件树、Props 接口 |
| 验收标准的"校验" | 业务规则 | 伪代码、流程图 |

### 阶段二：领域建模（10分钟）

**目标**：识别领域对象、定义职责和业务规则（DDD）

**建模步骤**：
1. **识别领域对象**：从用户故事和验收标准中提取名词（实体/值对象/聚合）
2. **定义对象职责**：每个对象负责什么业务能力？
3. **提炼业务规则**：对象的约束、不变量、状态转换规则
4. **确定对象关系**：聚合、关联、依赖（画 UML 类图或 Mermaid）

**领域对象分类**：
- **实体**（Entity）：有唯一标识、生命周期、可变
- **值对象**（Value Object）：无标识、不可变、可替换
- **聚合根**（Aggregate Root）：管理一组相关对象的入口

**示例**（网络切换）：
- Network（聚合根）：管理节点、切换验证
- Node（值对象）：节点信息、健康检查
- Latency（值对象）：延迟测量

**建模参考**：见 [architecture/design-thinking.md](architecture/design-thinking.md#一领域建模ddd)

### 阶段三：架构设计（15分钟）

**目标**：设计整体架构并记录关键决策

#### 3.1 整体架构设计（系统级）

1. **画架构图**（Mermaid）：前端/后端/外部系统的交互和数据流
   - **前端只画Page级别**（如 `WalletHomePage`、`NetworkSwitchPage`）
   - **不展开Component**（如 `NetworkItem`、`NavBar` 等留到阶段五）
2. **明确技术选型**：为什么选这个框架/库/工具？并使用mcp context7了解相关文档.
3. **标注关键路径**：性能瓶颈、安全边界

**示例**（系统级架构图）：
```mermaid
graph TB
    A[WalletHomePage] -->|切换网络| B[NetworkSwitchPage]
    B -->|API调用| C[NodeService]
    C -->|健康检查| D[外部API]
```
**注意**：此阶段不展开 `NetworkSwitchPage` 内部的组件树（留到阶段五）


#### 3.2 架构决策分析（ADR）

**每个重要决策都要记录**：

```markdown
## 决策N：[决策标题]

**问题**：[要解决什么问题？]

**方案对比**：
| 方案 | 优点 | 缺点 | 成本 |
...

**决策**：选择方案X
**权衡**：[为什么选这个？牺牲了什么？]
**演进**：v1.0 简化，v2.0 增强
```

**常见决策点**：
- 数据存储：硬编码/配置/数据库
- 更新策略：乐观更新/悲观验证
- 通信方式：轮询/WebSocket
- 缓存策略：无/内存/Redis

#### 3.3 分层架构设计

**后端**（Kratos 5 层架构）：
- Service层：做什么、不做什么
- Biz层：做什么、不做什么
- Data层：做什么、不做什么
- Infra层：做什么、不做什么
- pkg层：做什么、不做什么（跨层复用）

**详细说明**：见 [architecture/backend-layers.md](architecture/backend-layers.md)

**前端**（React 5 层架构）：
- Page → Component → Hook → Store → Service

**详细说明**：见 [architecture/frontend-architecture.md](architecture/frontend-architecture.md)

**Data/Infra/pkg 快速判断**：
- 管理业务领域对象生命周期？ → **Data 层**
- 有状态 + 技术能力 + 可复用？ → **Infra 层**
- 纯函数 + 无外部依赖？ → **pkg 层**

**决策案例**：见 [architecture/design-thinking.md](architecture/design-thinking.md#二架构决策adr)

### 阶段四：API语义契约与后端架构（10分钟）

**目标**：定义API的语义职责、后端分层职责（不写代码）

#### 4.1 API语义契约

**定义API的"做什么"，不定义"怎么实现"**：

**SwitchNetwork API 示例**：
```
功能语义：切换当前激活的区块链网络
输入语义：目标网络标识（主网/测试网）
输出语义：切换后的网络信息
前置条件：目标网络健康可用
后置效果：
  - 全局网络状态更新
  - 余额数据重新加载
  - UI显示新网络状态
依赖分析：
  - 前置API：ListNodes（获取可用节点）
  - 后置触发：GetBalance（重新查询余额）
错误场景：
  - 目标网络不存在 → 返回网络不存在错误
  - 目标网络不健康 → 返回网络不可用错误
  - 切换中断 → 回退到原网络
```

**⚠️ 注意**：不写 protobuf 定义（字段、类型），由 `code-implementation` 技能处理

#### 4.2 后端分层架构

**定义每层的职责边界（用文字，不写代码）**：

**Service层（表现层）**：
- 职责：协议适配、参数校验、错误码映射
- 边界：只处理传输层逻辑，不包含业务规则
- 示例：校验 networkId 格式、将业务错误映射为 gRPC codes

**Biz层（业务逻辑层）**：
- 职责：业务规则编排、状态转换、权限控制
- 边界：不直接访问数据库/外部系统
- 示例：验证网络切换合法性、管理切换状态机

**Data层（数据访问层）**：
- 职责：领域对象的持久化和查询、数据源抽象
- 边界：不包含业务规则，只负责数据的CRUD
- 示例：从配置文件/数据库读取节点列表，转换为 Network 对象

**Infra层（基础设施层）**：
- 职责：提供技术能力（外部集成、加密、缓存等）
- 边界：与业务领域无关，可跨模块复用
- 示例：TronGrid API客户端、健康检查工具、密码加密

**pkg层（工具层）**：
- 职责：纯函数、无状态工具
- 边界：无外部依赖，可跨层调用
- 示例：地址校验、UUID生成、哈希计算

**依赖关系图**：
```mermaid
graph TB
    Service[Service层<br/>协议适配] --> Biz[Biz层<br/>业务规则]
    Biz --> Data[Data层<br/>数据访问]
    Data --> Infra[Infra层<br/>技术能力]
    
    Service -.跨层.-> pkg[pkg层<br/>工具函数]
    Biz -.跨层.-> pkg
    Data -.跨层.-> pkg
    Infra -.跨层.-> pkg
```

**关键设计决策**（在此记录分层理由）：
- 为什么某个功能放在Biz层而不是Data层？
- 为什么需要Infra层而不是直接在Data层调用？
- 哪些逻辑可以下沉到pkg层？

**⚠️ 阶段四约束检查**：
- [ ] 只写了语义描述（文字 + 图表），没有代码
- [ ] 没有 protobuf 定义、接口签名
- [ ] 分层职责描述清晰（每层做什么、不做什么）

---

### 阶段五：前端架构设计（10分钟）

**目标**：定义组件职责、交互流程、状态管理策略（不写代码）

**⚠️ 重要区分**：
- **阶段三** = 系统级架构（Page级别，如 `NetworkSwitchPage`）
- **阶段五** = 组件级架构（Component级别，如 `NetworkItem`、`NavBar`）

#### 5.1 组件职责设计（Component级别）

**展开Page内部的组件树 + 定义每个组件的职责**：

```
NetworkSwitchPage (阶段三已画)
  ├─ NavBar（导航栏）
  │   职责：显示标题"切换网络"、返回按钮
  │   输入：标题文本、返回路径
  │   输出：用户点击返回事件
  │
  ├─ NetworkSection（网络分组容器）
  │   职责：组织同类型网络、显示分组标题
  │   输入：分组类型（主网/测试网）、网络列表
  │   输出：无
  │
  │   ├─ SectionHeader（分组标题）
  │   │   职责：显示"主网"或"测试网络"标题
  │   │
  │   └─ NetworkList（网络列表）
  │       └─ NetworkItem（单个网络项）
  │           职责：显示网络图标、名称、选中状态
  │           输入：网络数据、是否选中、加载状态
  │           输出：用户点击事件（携带网络ID）
  │
  └─ TestnetConfirmDialog（测试网确认弹窗）
      职责：主网切换到测试网时的二次确认
      输入：是否显示、目标网络名称
      输出：确认/取消事件
```

**⚠️ 注意**：不写 Props 接口定义（字段、类型），由 `code-implementation` 技能处理

#### 5.2 交互流程设计

**绘制 Mermaid 序列图**（用户操作 → UI响应 → 状态更新 → API调用）：

```mermaid
sequenceDiagram
    participant User as 用户
    participant Item as NetworkItem
    participant Dialog as TestnetConfirmDialog
    participant Hook as useNetworkSwitch
    participant Store as WalletStore
    participant API as NodeService API
    
    User->>Item: 点击网络项
    
    alt 主网→测试网
        Item->>Dialog: 显示确认弹窗
        User->>Dialog: 点击确认
        Dialog->>Hook: 触发切换
    else 其他切换
        Item->>Hook: 直接触发切换
    end
    
    Hook->>Store: 乐观更新UI（立即显示新网络）
    Hook->>API: 调用 SwitchNetwork
    
    alt API成功
        API-->>Hook: 返回成功
        Hook->>Store: 保持新网络状态
    else API失败
        API-->>Hook: 返回错误
        Hook->>Store: 回退到原网络
        Hook->>User: 显示错误Toast
    end
```

#### 5.3 状态管理策略

**Store 扩展语义**（描述职责，不写接口）：

**WalletStore 网络切换部分**：
- 职责：管理全局网络状态（当前网络、上一次网络）
- 更新策略：乐观更新（先更新UI，失败后回退）
- 依赖数据：
  - currentNetwork：当前激活的网络
  - previousNetwork：用于失败回退
  - isLoading：防止重复点击

**切换流程**：
1. 保存当前网络到 previousNetwork
2. 立即更新 currentNetwork 为目标网络（乐观更新）
3. 设置 isLoading = true
4. 调用 API
5. 成功：保持新状态
6. 失败：恢复 previousNetwork，显示错误

**Hook 设计**（描述职责，不写代码）：

**useNetworkSwitch**：
- 职责：封装网络切换逻辑、处理测试网确认流程
- 输入：无（从Store读取状态）
- 输出：
  - 切换函数（接收网络ID）
  - 加载状态（isLoading）
  - 错误状态（error）
- 关键逻辑：
  - 主网→测试网：显示确认弹窗
  - 其他切换：直接执行
  - 失败处理：回退 + Toast提示

**组件通信模式**：
```mermaid
graph TB
    Page[NetworkSwitchPage] --> Store[WalletStore]
    Item[NetworkItem] --> Hook[useNetworkSwitch]
    Hook --> Store
    Hook --> API[API Service]
    Store -.订阅.-> Page
    Store -.订阅.-> Item
```

**⚠️ 阶段五约束检查**：
- [ ] 只写了组件职责描述（文字），没有 Props 接口
- [ ] 只写了状态管理策略（文字 + 流程图），没有 interface 定义
- [ ] 交互流程用 Mermaid 图表达，清晰易懂

---

### 阶段六：输出架构设计文档（5分钟）+ ⚠️ 输出前自检

**目标**：产出架构师视角的设计方案文档（纯架构，无代码）

**⚠️ 输出前必检（最后防线 - 写入文档前必须检查）**：
- [ ] 搜索文档内是否有代码（`function`、`const`、`func`、`type`、`interface`）
- [ ] 搜索文档内是否有 protobuf 定义（`message`、`service`、`rpc`）
- [ ] 搜索文档内是否有 SQL、JSON Schema、配置文件等
- [ ] 文档总行数 ≤ 600 行（单需求）/ ≤ 1000 行（模块）
- [ ] 只有架构图、文字描述、表格对比、伪代码（bullet points）
- **如未通过，立即删减后再输出！**

**文档结构**（八章）：
```
一、需求与技术映射
   - 需求概述
   - 技术要素识别（用户故事 → 领域对象/API/组件）

二、领域建模（DDD）⭐
   - 领域对象识别（聚合根、实体、值对象）
   - 对象职责与业务规则
   - 对象关系图（Mermaid类图）

三、架构设计⭐
   - 整体架构图（前后端交互、数据流）
   - 架构决策分析（ADR：方案对比、权衡、演进）
   - 分层职责定义（每层做什么、不做什么）

四、API语义契约
   - API功能语义（做什么，不是怎么做）
   - 输入/输出语义
   - 前置条件、后置效果
   - 依赖分析、错误场景

五、后端架构设计
   - 分层职责分配（Service/Biz/Data/Infra/pkg）
   - 业务流程描述（伪代码 bullet points）
   - 关键设计决策（为什么这样分层）

六、前端架构设计
   - 组件职责树（Component级别）
   - 交互流程图（Mermaid序列图）
   - 状态管理策略（文字描述）

七、非功能性设计
   - 性能指标（响应时间、吞吐量）
   - 安全要求（鉴权、加密、审计）
   - 可维护性（日志、监控、测试）

八、演进与风险⭐
   - 技术债务（v1.0限制）
   - 演进规划（v2.0/v3.0增强方向）
   - 风险识别（技术风险、业务风险、缓解措施）
   - 实施路径（开发顺序、里程碑）
```

**关键章节说明**：
- **章二（领域建模）**：定义业务对象的职责和关系，不涉及数据库字段
- **章三（架构设计）**：系统级架构 + ADR决策，是核心章节
- **章四（API语义）**：API的"做什么"，不写protobuf定义
- **章五（后端架构）**：分层职责，不写接口签名
- **章六（前端架构）**：组件职责，不写Props接口
- **章八（演进与风险）**：架构师必须考虑的长期视角

**输出路径**：`prd/architecture/REQ-XXX-需求名称_架构设计方案.md`

**目标行数**：
- 单个需求：200-400 行（精简化）
- 模块设计（多个需求）：400-800 行
- **超过 1000 行**：立即停止，过于详细！

**文档骨架参考**：[example-document.md](example-document.md)

---

## 按需查阅资源

**架构思维文档**（本技能使用）：
- 领域建模方法（DDD） → [architecture/design-thinking.md](architecture/design-thinking.md)
- 架构决策记录（ADR） → [architecture/design-thinking.md](architecture/design-thinking.md#二架构决策adr)
- 后端分层架构（5层职责+判断规则） → [architecture/backend-layers.md](architecture/backend-layers.md)
- 前端分层架构（组件设计+状态管理） → [architecture/frontend-architecture.md](architecture/frontend-architecture.md)

**代码实现模板**（由 `code-implementation` 技能使用）：
- ⚠️ 以下文档用于代码实现阶段，架构设计阶段**不使用**：
  - API设计模板 → [patterns/api-patterns.md](patterns/api-patterns.md)
  - 后端接口模板 → [patterns/backend-patterns.md](patterns/backend-patterns.md)
  - 前端设计模板 → [patterns/frontend-patterns.md](patterns/frontend-patterns.md)
  - 质量检查清单 → [patterns/quality-checklist.md](patterns/quality-checklist.md)
  - 技术问题速查 → [patterns/troubleshooting.md](patterns/troubleshooting.md)

**完整案例参考**（架构设计视角）：
- 架构文档骨架 → [example-document.md](example-document.md)
- 数据展示类架构 → [examples/data-display.md](examples/data-display.md)
- 数据变更类架构 → [examples/data-change.md](examples/data-change.md)
- 敏感操作类架构 → [examples/sensitive-operation.md](examples/sensitive-operation.md)

---

## 设计原则（架构师视角）

1. **领域驱动设计（DDD）** — 先建模业务领域（对象、职责、规则），再考虑技术实现
2. **架构决策显式化（ADR）** — 记录"为什么"，不只是"是什么"，包含方案对比、权衡、成本
3. **语义契约优先** — 定义API/Repository/Component的语义职责，不定义接口签名
4. **业务规则显式化** — 用伪代码/列表/流程图描述规则，不写实现代码
5. **分层职责明确** — 严格遵循分层架构，明确每层做什么、不做什么
6. **依赖关系清晰** — 定义层间依赖方向（Service → Biz → Data → Infra），不画依赖注入代码
7. **基础设施分离** — 区分技术能力（Infra）和业务数据（Data），明确边界
8. **渐进式架构** — v1.0简化方案，v2.0/v3.0演进路线清晰，技术债务显式管理
9. **非功能性需求** — 明确性能指标、安全要求、可维护性、可测试性
10. **风险与边界意识** — 识别技术风险、业务风险，明确MVP边界
11. **三方文档正确性** — 使用 mcp context7 来保障查阅的三方文档的正确性

---

## ⚠️ 输出前强制自检清单

**在写入文档前，必须检查以下项**（任一项违反则修正）：

### 自检 1：无代码检查
- [ ] 搜索文档：没有 `function`、`const`、`func`、`type`、`interface` 等代码关键字
- [ ] 搜索文档：没有 `message`、`service`、`rpc` 等 protobuf 关键字
- [ ] 搜索文档：没有 SQL、JSON Schema、配置文件内容
- [ ] 只有：Mermaid图、文字描述、表格对比、伪代码（bullet points）

### 自检 2：行数检查
- [ ] 单个需求文档 ≤ 600 行（精简化）
- [ ] 模块文档 ≤ 1000 行
- [ ] 超过则删减冗余内容

### 自检 3：架构完整性检查
- [ ] 包含领域建模（DDD对象 + 关系图）
- [ ] 包含架构决策（ADR：方案对比 + 权衡）
- [ ] 包含演进规划（v1.0限制 → v2.0/v3.0方向）
- [ ] 包含风险识别（技术风险 + 缓解措施）

**如果任一项未通过，立即修正后再输出！**

---

## 关键输出物

### 技术设计文档内容

**必须包含**：
- ✅ 领域建模（DDD对象+职责+业务规则+关系图）
- ✅ 架构决策分析（问题+方案对比+权衡）
- ✅ API契约（protobuf完整定义）
- ✅ 后端接口签名 + 业务流程伪代码
- ✅ 前端组件架构 + Props接口 + 状态策略
- ✅ 实现约束（性能/安全/测试）

**不应包含**：
- ❌ 完整的Go函数实现
- ❌ 完整的React组件代码
- ❌ 详细的SQL语句
- ❌ 数据库表字段（应该是领域对象属性）

### 实现时如何使用设计文档？

开发人员在编码时：
1. 阅读领域建模 → 理解业务逻辑
2. 查看接口签名 + 伪代码 → 理解要实现什么
3. 参考 patterns/ 模板 → 获取代码模板
4. 根据实现要点 → 编写具体代码
5. 对照质量检查清单 → 自检

---

## 项目内参考资源

- 需求清单：`prd/requirements/`
- 设计规范：`prd/design/00-全局设计规范.md`
- Proto定义：`proto/wallet/v1/*.proto`
- 后端代码：`backend/internal/`（实际代码示例）
- 前端代码：`frontend/src/`（实际代码示例）

---

## 🎓 自我学习功能

本技能具有自我学习能力，可从实际设计中持续积累新模式和最佳实践。

**学习触发**：
- 完成设计后，AI 自动分析是否有可学习内容
- 发现高价值模式时提示用户
- 用户确认后写入对应的 patterns/ 或 examples/ 或 architecture 文件

**学习内容**：
- 新的架构决策模式
- 新的领域建模案例  
- 新的 API 设计模式
- 反模式和常见错误
- 提炼的最佳实践

**详细说明**：见 [LEARNING.md](LEARNING.md)
