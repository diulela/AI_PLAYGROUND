# 代码实现技能（Code Implementation）

## 概述

本技能从开发者视角出发，将架构设计方案转换为可运行的代码实现。

**角色定位**：开发者（Developer）  
**输入**：架构设计方案文档  
**输出**：可运行代码（protobuf、Go、TypeScript、测试）

---

## 与架构设计技能的关系

| 技能 | 角色 | 输入 | 输出 |
|-----|------|------|------|
| `architecture-design` | 架构师 | PRD需求文档 | 架构设计方案（纯架构，无代码） |
| `code-implementation` | 开发者 | 架构设计方案 | 可运行代码 |

**工作流**：
```
需求文档 → architecture-design → 架构方案 → code-implementation → 代码实现
```

---

## 快速开始

### 场景1：实现一个完整需求

```bash
# 1. 先设计架构
用户：架构设计 REQ-046（转账功能）

# 2. 再实现代码
用户：实现 REQ-046
```

### 场景2：只实现特定部分

```bash
# 只实现 protobuf 定义
用户：编写 REQ-046 的 protobuf

# 只实现后端接口
用户：实现 REQ-046 的后端代码

# 只实现前端组件
用户：实现 REQ-046 的前端组件
```

---

## 技能状态

✅ **当前状态：已完善并模块化，可投入使用**

### 已完成功能

- ✅ **阶段一：架构方案分析** — 提取领域对象、API语义、分层职责、组件职责
- ✅ **阶段二：API定义** — protobuf 生成指导（message/service/enum/validation）
- ✅ **阶段三：后端实现** — Go 分层代码生成指导（pkg/Infra/Data/Biz/Service）
- ✅ **阶段四：前端实现** — TypeScript 代码生成指导（Service/Store/Hook/Component/Page）
- ✅ **阶段五：测试生成** — 单元测试指导（后端Biz层、前端Hook层）
- ✅ **错误处理** — 统一错误处理模式（后端gRPC映射、前端拦截器）
- ✅ **质量检查** — 代码提交前检查清单（规范、Lint、测试覆盖率）
- ✅ **协作流程** — 与 `architecture-design` 的3种协作模式
- ✅ **模块化拆分** — 主流程精简至345行，详细指南按需加载（**2026-02-28新增**）

### Token优化效果（2026-02-28）

| 场景 | 优化前 | 优化后 | 节省 |
|-----|-------|--------|------|
| 完整实现（5阶段） | 1112行 | 345 + 150×5 = 1095行 | -1.5% |
| 部分实现（如protobuf） | 1112行 | 345 + 180 = 525行 | **-53%** |
| 只读主流程 | 1112行 | 345行 | **-69%** |

### 未来增强方向

- [ ] **增量实现** — 自动识别v1.0和v2.0差异，只修改变更部分
- [ ] **代码重构** — 基于架构方案优化现有代码
- [ ] **代码审查** — 检查代码是否符合架构方案
- [ ] **多框架支持** — NestJS后端、Vue/Angular前端

---

## 目录结构

```
code-implementation/
├── SKILL.md                        # 主流程（345行）⭐
├── README.md                       # 本文件（概述）
├── guides/                         # 实现指南（按需加载）
│   ├── README.md                   # 指南导航
│   ├── 01-architecture-reading.md  # 阶段一：架构方案阅读（~80行）
│   ├── 02-protobuf-impl.md        # 阶段二：protobuf实现（~180行）
│   ├── 03-backend-impl.md         # 阶段三：后端实现（~250行）
│   ├── 04-frontend-impl.md        # 阶段四：前端实现（~200行）
│   ├── 05-testing.md              # 阶段五：测试实现（~150行）
│   ├── error-handling.md          # 错误处理模式（~120行）
│   └── quality-checklist.md       # 质量检查清单（~100行）
└── examples/                       # 代码示例（未来）
```

**设计原则**：
- ✅ **主流程精简**：SKILL.md 只包含框架和流程，详细内容在 guides/
- ✅ **按需加载**：AI 只读当前阶段需要的指南，节省 token
- ✅ **易于维护**：每个阶段独立文件，修改不影响其他部分
- ✅ **易于扩展**：新增功能只需添加新指南文件

---

## 设计理念

### 为什么要拆分技能？

**问题**：原 `requirement-to-code-design` 技能混合了两种角色：
- 架构师：负责架构设计、决策分析
- 开发者：负责代码实现、接口定义

这导致：
1. 角色职责不清
2. 不符合现实工作流（架构师不写代码）
3. 文档过长（800-1500行）

**解决方案**：拆分为两个独立技能
- `architecture-design`：纯架构设计（无代码）
- `code-implementation`：纯代码实现（读取架构方案）

### 优势

✅ **角色清晰**：架构师专注设计，开发者专注实现  
✅ **符合现实**：与实际工作流一致  
✅ **可组合**：可单独使用，也可串联使用  
✅ **文档精简**：架构方案更聚焦（600-1000行）

---

## 参考资源

### 本技能指南（guides/）

**按阶段查阅**：
- 阶段一：[架构方案阅读与分析](guides/01-architecture-reading.md)
- 阶段二：[protobuf 实现指南](guides/02-protobuf-impl.md)
- 阶段三：[后端实现指南](guides/03-backend-impl.md)
- 阶段四：[前端实现指南](guides/04-frontend-impl.md)
- 阶段五：[测试实现指南](guides/05-testing.md)

**通用参考**：
- [错误处理模式](guides/error-handling.md)
- [质量检查清单](guides/quality-checklist.md)
- [指南导航](guides/README.md)

### architecture-design 资源

**代码模板**（从 `architecture-design` 继承）：
- API设计模板：`../architecture-design/patterns/api-patterns.md`
- 后端接口模板：`../architecture-design/patterns/backend-patterns.md`
- 前端设计模板：`../architecture-design/patterns/frontend-patterns.md`
- 质量检查清单：`../architecture-design/patterns/quality-checklist.md`

**架构思维文档**（理解设计意图）：
- 领域建模：`../architecture-design/architecture/design-thinking.md`
- 后端分层架构：`../architecture-design/architecture/backend-layers.md`
- 前端分层架构：`../architecture-design/architecture/frontend-architecture.md`

---

## 快速参考

### 实现步骤速查

```bash
# 1. 确认架构方案存在
ls prd/architecture/REQ-XXX_架构设计方案.md

# 2. 开始实现
用户：实现 REQ-XXX

# AI执行：
# → 阶段一：读取架构方案，提取关键信息
# → 阶段二：生成 protobuf（api/v1/xxx.proto）
# → 阶段三：生成后端代码（internal/service|biz|data|infra/xxx.go）
# → 阶段四：生成前端代码（src/pages|components|hooks|stores/xxx.tsx）
# → 阶段五：生成测试代码（*_test.go, *.test.ts）
```

### 代码路径映射

| 架构层 | 后端路径 | 前端路径 |
|-------|---------|---------|
| API | `api/wallet/v1/xxx.proto` | - |
| Service | `internal/service/xxx.go` | `src/services/xxxService.ts` |
| Biz/Hook | `internal/biz/xxx.go` | `src/hooks/useXxx.ts` |
| Data/Store | `internal/data/xxx.go` | `src/stores/xxxStore.ts` |
| Infra | `internal/infra/xxx/client.go` | - |
| pkg | `pkg/xxx/util.go` | - |
| Component | - | `src/components/xxx/XxxItem.tsx` |
| Page | - | `src/pages/XxxPage.tsx` |

### 错误排查速查

| 问题 | 可能原因 | 解决方案 |
|-----|---------|---------|
| "架构方案不存在" | 未先运行架构设计 | 先运行 `architecture-design` 技能 |
| "分层职责不清" | 架构方案描述不明确 | 补充架构方案的"分层职责"章节 |
| "不知道怎么实现XXX" | 架构方案缺少该部分 | 补充架构方案的对应章节 |
| "测试失败" | 代码实现与架构方案不一致 | 对照架构方案检查代码 |

### 常见问题

**Q: 架构方案中的"伪代码"要照抄吗？**  
A: 不用。架构方案的伪代码只是描述业务流程，实际代码要根据Go/TypeScript语法实现。

**Q: 是否必须实现所有层？**  
A: 否。根据架构方案判断，如果没有提到Infra层，就不用实现。

**Q: 前端组件太多怎么办？**  
A: 先实现Page和核心Component，其他组件可以后续迭代。

**Q: 测试覆盖率达不到80%怎么办？**  
A: 优先覆盖Biz层和Hook层的核心业务逻辑，其他层可以适当放宽。

---

## 贡献指南

本技能已完善核心功能，欢迎贡献增强功能：

1. **增量实现** — 如何自动识别v1.0和v2.0差异
2. **代码重构** — 如何基于架构方案优化现有代码
3. **代码审查** — 如何检查代码是否符合架构方案
4. **多框架支持** — NestJS、Vue、Angular的实现模板

---

*本技能由 `architecture-design` 技能拆分而来（2026-02-28）*
