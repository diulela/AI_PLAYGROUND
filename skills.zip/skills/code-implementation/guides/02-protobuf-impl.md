# 阶段二：protobuf 实现指南

> 根据架构方案编写 API 定义

---

## 目标

根据架构方案的"API语义契约"和"领域建模"，编写 protobuf 定义。

---

## 领域对象映射规则

| 领域对象类型 | protobuf 映射 | 示例 | 说明 |
|------------|--------------|------|------|
| 聚合根 | message | `Network` → `message NetworkInfo` | 通常作为 RPC 返回值 |
| 实体 | message（带ID） | `Account` → `message AccountInfo` | 必须有唯一标识字段 |
| 值对象 | message（无ID）| `Node` → `message NodeInfo` | 无唯一标识，可重复 |
| 枚举 | enum | `NetworkType` → `enum NetworkType` | 有限的固定值集合 |

---

## protobuf 文件结构

**文件路径**：`api/wallet/v1/xxx.proto`

**标准模板**：

```protobuf
syntax = "proto3";

package wallet.v1;

option go_package = "wallet/api/wallet/v1;v1";

import "google/api/annotations.proto";
import "validate/validate.proto";

// ========== Enums ==========

enum NetworkType {
  NETWORK_TYPE_UNSPECIFIED = 0;
  NETWORK_TYPE_MAINNET = 1;
  NETWORK_TYPE_TESTNET = 2;
}

// ========== Messages ==========

message NetworkInfo {
  string id = 1;
  string name = 2;
  NetworkType type = 3;
  repeated NodeInfo nodes = 4;
}

message NodeInfo {
  string name = 1;
  string url = 2;
  int32 latency_ms = 3;
  bool is_healthy = 4;
}

// ========== Request/Response ==========

message SwitchNetworkRequest {
  string network_id = 1 [(validate.rules).string = {min_len: 1}];
}

message SwitchNetworkResponse {
  NetworkInfo network = 1;
}

// ========== Service ==========

service NodeService {
  rpc SwitchNetwork(SwitchNetworkRequest) returns (SwitchNetworkResponse) {
    option (google.api.http) = {
      post: "/v1/network/switch"
      body: "*"
    };
  }
}
```

---

## 详细步骤

### 步骤1：定义 enum（枚举类型）

**从架构方案提取**：领域建模中的枚举

```protobuf
enum NetworkType {
  NETWORK_TYPE_UNSPECIFIED = 0;  // 默认值（必须）
  NETWORK_TYPE_MAINNET = 1;
  NETWORK_TYPE_TESTNET = 2;
}
```

**规范**：
- ✅ 枚举名大写 + 下划线
- ✅ 第一个值必须是 `UNSPECIFIED = 0`
- ✅ 枚举值前缀与枚举名一致

### 步骤2：定义 message（领域对象）

**从架构方案提取**：领域建模中的对象和属性

```protobuf
message NetworkInfo {
  string id = 1;           // 聚合根ID（必须）
  string name = 2;         // 显示名称
  NetworkType type = 3;    // 枚举类型
  repeated NodeInfo nodes = 4;  // 关联的值对象列表
  string icon = 5;         // 可选字段
}

message NodeInfo {
  string name = 1;
  string url = 2;
  int32 latency_ms = 3;    // int32: 小整数（-2^31 ~ 2^31-1）
  bool is_healthy = 4;
  int64 last_checked = 5;  // int64: 时间戳
}
```

**字段类型选择**：

| Go类型 | protobuf类型 | 示例 |
|-------|-------------|------|
| string | string | name, id, url |
| int32 | int32 | latency_ms, count |
| int64 | int64 | timestamp, balance |
| bool | bool | is_healthy, is_active |
| float64 | double | amount |
| []T | repeated T | nodes, accounts |
| *T | T（默认nil） | optional_field |

### 步骤3：定义 Request/Response

**从架构方案提取**：API语义契约中的输入/输出

```protobuf
message SwitchNetworkRequest {
  string network_id = 1 [(validate.rules).string = {min_len: 1}];
}

message SwitchNetworkResponse {
  NetworkInfo network = 1;
  string message = 2;  // 可选：提示信息
}
```

### 步骤4：添加验证规则

**使用 protoc-gen-validate**：

```protobuf
import "validate/validate.proto";

message SwitchNetworkRequest {
  // 必填且长度>0
  string network_id = 1 [(validate.rules).string = {min_len: 1}];
}

message CreateAccountRequest {
  // 必填且符合邮箱格式
  string email = 1 [(validate.rules).string.email = true];
  
  // 密码长度6-20
  string password = 2 [(validate.rules).string = {min_len: 6, max_len: 20}];
  
  // 可选字段
  string nickname = 3;
}
```

**常用验证规则**：

| 规则 | 示例 | 说明 |
|-----|------|------|
| `min_len` | `{min_len: 1}` | 最小长度 |
| `max_len` | `{max_len: 100}` | 最大长度 |
| `pattern` | `{pattern: "^[a-z]+$"}` | 正则匹配 |
| `email` | `{email: true}` | 邮箱格式 |
| `gt` | `{gt: 0}` | 大于 |
| `gte` | `{gte: 0}` | 大于等于 |

### 步骤5：定义 Service 和 RPC

**从架构方案提取**：API语义契约中的功能

```protobuf
service NodeService {
  // 列表查询（GET）
  rpc ListNodes(ListNodesRequest) returns (ListNodesResponse) {
    option (google.api.http) = {
      get: "/v1/nodes"
    };
  }
  
  // 单个查询（GET）
  rpc GetNode(GetNodeRequest) returns (GetNodeResponse) {
    option (google.api.http) = {
      get: "/v1/nodes/{id}"
    };
  }
  
  // 创建（POST）
  rpc CreateNode(CreateNodeRequest) returns (CreateNodeResponse) {
    option (google.api.http) = {
      post: "/v1/nodes"
      body: "*"
    };
  }
  
  // 更新（PUT）
  rpc UpdateNode(UpdateNodeRequest) returns (UpdateNodeResponse) {
    option (google.api.http) = {
      put: "/v1/nodes/{id}"
      body: "*"
    };
  }
  
  // 删除（DELETE）
  rpc DeleteNode(DeleteNodeRequest) returns (DeleteNodeResponse) {
    option (google.api.http) = {
      delete: "/v1/nodes/{id}"
    };
  }
}
```

**RESTful 命名规范**：

| 操作 | RPC名称 | HTTP方法 | URL | Body |
|-----|--------|---------|-----|------|
| 列表 | List | GET | `/v1/resources` | - |
| 查询 | Get | GET | `/v1/resources/{id}` | - |
| 创建 | Create | POST | `/v1/resources` | `*` |
| 更新 | Update | PUT | `/v1/resources/{id}` | `*` |
| 删除 | Delete | DELETE | `/v1/resources/{id}` | - |
| 自定义 | 动词 | POST | `/v1/resources/action` | `*` |

---

## 输出检查清单

完成 protobuf 编写后，检查：

- [ ] **import 正确**：google/api/annotations.proto, validate/validate.proto
- [ ] **package 正确**：`package wallet.v1;`
- [ ] **go_package 正确**：`option go_package = "wallet/api/wallet/v1;v1";`
- [ ] **enum 规范**：第一个值是 `UNSPECIFIED = 0`
- [ ] **message 字段有序号**：从 1 开始递增
- [ ] **字段类型正确**：string, int32, int64, bool, enum, repeated
- [ ] **验证规则添加**：必填字段有 `[(validate.rules).xxx]`
- [ ] **RPC 命名符合 RESTful**：List/Get/Create/Update/Delete
- [ ] **HTTP 注解完整**：method + url + body
- [ ] **注释清晰**：每个 message、rpc 有功能说明

---

## 参考资源

- API设计模板：`../../architecture-design/patterns/api-patterns.md`
- protobuf 语法：https://protobuf.dev/
- protoc-gen-validate：https://github.com/bufbuild/protoc-gen-validate

---

*完成 protobuf 定义后，进入阶段三：后端实现*
