# 阶段四：前端实现指南

> 按照分层架构实现 React 前端代码

---

## 目标

按照 React 5层架构（Service/Store/Hook/Component/Page），实现前端各层代码。

---

## 实现顺序（从底向上）

```
1. Service层（API调用）
2. Store层（全局状态，如果需要）
3. Hook层（业务逻辑）
4. Component层（可复用UI）
5. Page层（页面入口）
```

---

## Service 层实现

### 职责

封装 API 调用，类型转换（API模型 → UI模型）。

### 实现规范

**文件路径**：`src/services/xxxService.ts`

**步骤**：

#### 1. 定义 API 接口

```typescript
// 根据架构方案的"API语义契约"
export interface NetworkService {
  listNodes(): Promise<Network[]>;
  switchNetwork(networkId: string): Promise<Network>;
}
```

#### 2. 实现 API 调用

```typescript
import { apiClient } from './apiClient';
import type { NetworkInfo } from '@/types/api';  // 从protobuf生成
import type { Network } from '@/types/models';   // UI模型

class NetworkServiceImpl implements NetworkService {
  async switchNetwork(networkId: string): Promise<Network> {
    const response = await apiClient.post<NetworkInfo>('/v1/network/switch', {
      network_id: networkId,
    });
    
    // 类型转换（protobuf → UI模型）
    return this.toUIModel(response.data);
  }

  async listNodes(): Promise<Network[]> {
    const response = await apiClient.get<{networks: NetworkInfo[]}>('/v1/nodes');
    return response.data.networks.map(n => this.toUIModel(n));
  }

  // 类型转换
  private toUIModel(proto: NetworkInfo): Network {
    return {
      id: proto.id,
      name: proto.name,
      type: proto.type,
      icon: proto.icon || '/default-icon.png',
    };
  }
}

export const networkService = new NetworkServiceImpl();
```

**关键点**：
- ✅ 封装 HTTP 调用
- ✅ 统一错误处理（在 apiClient拦截器中）
- ✅ 类型转换（API模型 → UI模型）

---

## Store 层实现（Zustand）

### 判断是否需要

**从架构方案判断**：
- ✅ 状态需要跨页面共享
- ✅ 状态需要持久化
- ❌ 只在单个页面使用 → 用 Hook state

### 实现规范

**文件路径**：`src/stores/xxxStore.ts`

**步骤**：

#### 1. 定义 Store 接口

```typescript
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface WalletState {
  // 状态
  currentNetwork: Network | null;
  previousNetwork: Network | null;
  isLoading: boolean;
  error: Error | null;
  
  // 方法
  switchNetwork: (networkId: string) => Promise<void>;
  reset: () => void;
}
```

#### 2. 实现 Store（含持久化）

```typescript
export const useWalletStore = create<WalletState>()(
  persist(
    (set, get) => ({
      // 初始状态
      currentNetwork: null,
      previousNetwork: null,
      isLoading: false,
      error: null,

      // 切换网络（根据架构方案的"状态管理策略"）
      switchNetwork: async (networkId: string) => {
        const { currentNetwork } = get();
        
        // 1. 保存当前网络（用于失败回退）
        set({ previousNetwork: currentNetwork, isLoading: true, error: null });

        // 2. 乐观更新（立即更新UI）
        const targetNetwork = { id: networkId, name: '切换中...', type: 'mainnet' };
        set({ currentNetwork: targetNetwork });

        try {
          // 3. 调用API
          const result = await networkService.switchNetwork(networkId);
          set({ currentNetwork: result, isLoading: false });
        } catch (error) {
          // 4. 失败回退
          set({ 
            currentNetwork: get().previousNetwork, 
            isLoading: false,
            error: error as Error 
          });
          throw error;
        }
      },

      reset: () => set({ 
        currentNetwork: null, 
        isLoading: false, 
        error: null 
      }),
    }),
    {
      name: 'wallet-storage', // LocalStorage key
      // 选择性持久化（敏感数据不持久化）
      partialize: (state) => ({ 
        currentNetwork: state.currentNetwork 
      }),
    }
  )
);
```

**关键点**：
- ✅ 实现架构方案中的"状态管理策略"（乐观更新）
- ✅ 失败回退机制
- ✅ 选择性持久化（敏感数据不持久化）
- ✅ 错误状态管理

---

## Hook 层实现

### 职责

封装业务逻辑、副作用管理。

### 实现规范

**文件路径**：`src/hooks/useXxx.ts`

**步骤**：

#### 1. 定义 Hook 返回类型

```typescript
interface UseNetworkSwitchReturn {
  switchNetwork: (networkId: string) => Promise<void>;
  isLoading: boolean;
  error: Error | null;
  showConfirm: boolean;
  confirmSwitch: () => void;
  cancelSwitch: () => void;
}
```

#### 2. 实现 Hook

```typescript
import { useState, useCallback } from 'react';
import { useWalletStore } from '@/stores/walletStore';
import { toast } from 'react-hot-toast';

export function useNetworkSwitch(): UseNetworkSwitchReturn {
  const { switchNetwork: storeSwitchNetwork, isLoading, error } = useWalletStore();
  const [showConfirm, setShowConfirm] = useState(false);
  const [pendingNetworkId, setPendingNetworkId] = useState<string | null>(null);

  const switchNetwork = useCallback(async (networkId: string) => {
    // 根据架构方案的"Hook设计"
    
    // 主网→测试网：显示确认弹窗
    if (needConfirm(networkId)) {
      setPendingNetworkId(networkId);
      setShowConfirm(true);
      return;
    }

    // 直接切换
    try {
      await storeSwitchNetwork(networkId);
      toast.success('切换网络成功');
    } catch (err) {
      toast.error('切换网络失败');
    }
  }, [storeSwitchNetwork]);

  const confirmSwitch = useCallback(async () => {
    if (!pendingNetworkId) return;
    
    setShowConfirm(false);
    try {
      await storeSwitchNetwork(pendingNetworkId);
      toast.success('切换到测试网成功');
    } catch (err) {
      toast.error('切换失败');
    }
    setPendingNetworkId(null);
  }, [pendingNetworkId, storeSwitchNetwork]);

  const cancelSwitch = useCallback(() => {
    setShowConfirm(false);
    setPendingNetworkId(null);
  }, []);

  return { 
    switchNetwork, 
    isLoading, 
    error, 
    showConfirm, 
    confirmSwitch, 
    cancelSwitch 
  };
}

// 辅助函数
function needConfirm(networkId: string): boolean {
  const currentNetwork = useWalletStore.getState().currentNetwork;
  return currentNetwork?.type === 'mainnet' && networkId.includes('testnet');
}
```

**关键点**：
- ✅ 封装业务逻辑（确认流程、错误处理）
- ✅ 调用 Store 或 Service
- ✅ 用户反馈（Toast提示）
- ✅ 返回加载状态和错误状态

---

## Component 层实现

### 职责

可复用 UI 组件，只负责渲染和事件委托。

### 实现规范

**文件路径**：`src/components/xxx/XxxItem.tsx`

**步骤**：

#### 1. 定义 Props 接口

```typescript
import { Network } from '@/types/models';

interface NetworkItemProps {
  data: Network;
  isSelected: boolean;
  isLoading?: boolean;
  onClick: (network: Network) => void;
}
```

#### 2. 实现组件

```typescript
import { ListItem, ListItemAvatar, ListItemText, Avatar, CircularProgress } from '@mui/material';
import CheckIcon from '@mui/icons-material/Check';

export function NetworkItem({ data, isSelected, isLoading, onClick }: NetworkItemProps) {
  return (
    <ListItem
      button
      selected={isSelected}
      disabled={isLoading}
      onClick={() => onClick(data)}
    >
      <ListItemAvatar>
        <Avatar src={data.icon} alt={data.name} />
      </ListItemAvatar>
      
      <ListItemText 
        primary={data.name} 
        secondary={data.type === 'testnet' ? '测试网络' : '主网'} 
      />
      
      {isSelected && !isLoading && <CheckIcon color="primary" />}
      {isLoading && <CircularProgress size={20} />}
    </ListItem>
  );
}
```

**关键点**：
- ✅ Props 类型定义清晰
- ✅ 只负责 UI 渲染
- ✅ 事件委托（`onClick`）
- ✅ 加载状态显示
- ❌ 不包含业务逻辑

---

## Page 层实现

### 职责

页面入口、组合组件、路由处理。

### 实现规范

**文件路径**：`src/pages/XxxPage.tsx`

**步骤**：

```typescript
import { Container, Typography, Divider } from '@mui/material';
import { NavBar } from '@/components/common/NavBar';
import { NetworkItem } from '@/components/network/NetworkItem';
import { TestnetConfirmDialog } from '@/components/network/TestnetConfirmDialog';
import { useNetworkSwitch } from '@/hooks/useNetworkSwitch';
import { useWalletStore } from '@/stores/walletStore';

export function NetworkSwitchPage() {
  const { currentNetwork } = useWalletStore();
  const { 
    switchNetwork, 
    isLoading, 
    showConfirm, 
    confirmSwitch, 
    cancelSwitch 
  } = useNetworkSwitch();

  // 模拟网络列表（实际从API获取）
  const mainnetNetworks = [
    { id: 'mainnet-trongrid', name: 'TRON 主网 (TronGrid)', type: 'mainnet', icon: '/tron.png' },
    { id: 'mainnet-tronstack', name: 'TRON 主网 (TronStack)', type: 'mainnet', icon: '/tron.png' },
  ];

  const testnetNetworks = [
    { id: 'testnet-shasta', name: 'Shasta 测试网', type: 'testnet', icon: '/tron.png' },
    { id: 'testnet-nile', name: 'Nile 测试网', type: 'testnet', icon: '/tron.png' },
  ];

  return (
    <Container maxWidth="sm">
      <NavBar title="切换网络" />
      
      {/* 主网分组 */}
      <Typography variant="h6" sx={{ mt: 2, mb: 1 }}>主网</Typography>
      {mainnetNetworks.map((network) => (
        <NetworkItem
          key={network.id}
          data={network}
          isSelected={network.id === currentNetwork?.id}
          isLoading={isLoading && network.id === currentNetwork?.id}
          onClick={() => switchNetwork(network.id)}
        />
      ))}

      <Divider sx={{ my: 2 }} />

      {/* 测试网分组 */}
      <Typography variant="h6" sx={{ mb: 1 }}>测试网络</Typography>
      {testnetNetworks.map((network) => (
        <NetworkItem
          key={network.id}
          data={network}
          isSelected={network.id === currentNetwork?.id}
          isLoading={isLoading && network.id === currentNetwork?.id}
          onClick={() => switchNetwork(network.id)}
        />
      ))}

      {/* 确认弹窗 */}
      <TestnetConfirmDialog
        open={showConfirm}
        onConfirm={confirmSwitch}
        onCancel={cancelSwitch}
      />
    </Container>
  );
}
```

**关键点**：
- ✅ 组合 Component
- ✅ 使用 Hook 和 Store
- ✅ 处理页面级状态
- ❌ 不包含复杂业务逻辑（交给Hook）

---

## 输出检查清单

完成前端实现后，检查：

- [ ] **Service层**：API调用、类型转换
- [ ] **Store层**：全局状态、持久化策略
- [ ] **Hook层**：业务逻辑封装、错误处理
- [ ] **Component层**：Props定义清晰、只负责UI
- [ ] **Page层**：组合组件、使用Hook/Store
- [ ] **依赖方向**：Page → Component/Hook → Store → Service（无反向）
- [ ] **TypeScript**：所有接口都有类型定义
- [ ] **错误提示**：所有错误有用户友好的Toast
- [ ] **加载状态**：所有异步操作有loading状态

---

## 参考资源

- 前端代码模板：`../../architecture-design/patterns/frontend-patterns.md`
- 前端分层架构：`../../architecture-design/architecture/frontend-architecture.md`

---

*完成前端实现后，进入阶段五：测试代码*
