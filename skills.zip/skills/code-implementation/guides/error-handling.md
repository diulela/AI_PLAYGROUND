# 错误处理模式

> 统一错误处理规范

---

## 后端错误处理（Go + Kratos）

### 1. 错误分类

| 错误类型 | gRPC Code | HTTP Status | Kratos错误 | 示例 |
|---------|-----------|-------------|-----------|------|
| 参数错误 | InvalidArgument | 400 | `errors.BadRequest` | 缺少必填字段 |
| 未授权 | Unauthenticated | 401 | `errors.Unauthorized` | Token无效 |
| 无权限 | PermissionDenied | 403 | `errors.Forbidden` | 权限不足 |
| 资源不存在 | NotFound | 404 | `errors.NotFound` | 网络ID不存在 |
| 业务规则违反 | FailedPrecondition | 412 | `errors.FailedPrecondition` | 网络不健康 |
| 内部错误 | Internal | 500 | `errors.InternalServer` | 数据库错误 |

### 2. Service层错误映射

**职责**：将业务错误映射为 gRPC 错误码

```go
func (s *NodeService) SwitchNetwork(ctx context.Context, req *pb.SwitchNetworkRequest) (*pb.SwitchNetworkResponse, error) {
    network, err := s.uc.SwitchNetwork(ctx, req.NetworkId)
    if err != nil {
        // 根据错误类型映射
        switch {
        case errors.Is(err, biz.ErrNetworkNotFound):
            return nil, errors.NotFound("NETWORK_NOT_FOUND", err.Error())
        case errors.Is(err, biz.ErrNetworkUnhealthy):
            return nil, errors.FailedPrecondition("NETWORK_UNHEALTHY", err.Error())
        case errors.Is(err, biz.ErrInvalidNetworkID):
            return nil, errors.BadRequest("INVALID_NETWORK_ID", err.Error())
        default:
            return nil, errors.InternalServer("SWITCH_FAILED", err.Error())
        }
    }
    return &pb.SwitchNetworkResponse{Network: toProto(network)}, nil
}
```

### 3. Biz层错误定义

**职责**：定义业务错误常量

```go
// internal/biz/errors.go
package biz

import "errors"

var (
    ErrNetworkNotFound   = errors.New("network not found")
    ErrNetworkUnhealthy  = errors.New("network unhealthy")
    ErrInvalidNetworkID  = errors.New("invalid network ID")
    ErrSwitchFailed      = errors.New("network switch failed")
)
```

### 4. Data层错误处理

**职责**：记录日志、返回 Kratos 错误

```go
func (r *nodeRepo) GetNetwork(ctx context.Context, id string) (*biz.Network, error) {
    network, err := r.findByID(id)
    if err != nil {
        r.log.Errorf("failed to find network %s: %v", id, err)
        return nil, errors.Wrap(err, "database query failed")
    }
    
    if network == nil {
        return nil, biz.ErrNetworkNotFound
    }
    
    return network, nil
}
```

---

## 前端错误处理（TypeScript + React）

### 1. API 统一错误拦截

**文件路径**：`src/services/apiClient.ts`

```typescript
import axios from 'axios';
import { toast } from 'react-hot-toast';

const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
  timeout: 10000,
});

// 响应拦截器：统一错误处理
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      const { status, data } = error.response;
      
      // 根据HTTP状态码分类处理
      switch (status) {
        case 400:
          toast.error(data.message || '请求参数错误');
          break;
        case 401:
          toast.error('未授权，请先登录');
          // 跳转到登录页
          window.location.href = '/login';
          break;
        case 403:
          toast.error('权限不足');
          break;
        case 404:
          toast.error(data.message || '资源不存在');
          break;
        case 412:
          toast.error(data.message || '业务规则违反');
          break;
        case 500:
          toast.error('服务器错误，请稍后重试');
          break;
        default:
          toast.error('网络错误');
      }
    } else if (error.request) {
      toast.error('网络连接失败');
    } else {
      toast.error('请求失败');
    }
    
    return Promise.reject(error);
  }
);

export default apiClient;
```

### 2. Hook层错误状态

```typescript
export function useNetworkSwitch() {
  const [error, setError] = useState<Error | null>(null);
  const { switchNetwork: storeSwitchNetwork } = useWalletStore();

  const switchNetwork = async (networkId: string) => {
    try {
      await storeSwitchNetwork(networkId);
      setError(null);  // 清除之前的错误
    } catch (err) {
      setError(err as Error);
      // 错误已在拦截器处理，这里记录状态供UI使用
    }
  };

  // 清除错误
  const clearError = () => setError(null);

  return { switchNetwork, error, clearError };
}
```

### 3. 错误边界（ErrorBoundary）

**文件路径**：`src/components/ErrorBoundary.tsx`

```typescript
import React, { Component, ReactNode } from 'react';
import { Alert, Button, Container } from '@mui/material';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('ErrorBoundary caught:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <Container>
          <Alert severity="error" sx={{ mt: 2 }}>
            <strong>出错了</strong>
            <p>{this.state.error?.message}</p>
            <Button onClick={() => window.location.reload()}>
              刷新页面
            </Button>
          </Alert>
        </Container>
      );
    }

    return this.props.children;
  }
}
```

**使用**：

```typescript
// App.tsx
function App() {
  return (
    <ErrorBoundary>
      <Router>
        <Routes>...</Routes>
      </Router>
    </ErrorBoundary>
  );
}
```

---

## 错误处理最佳实践

### 后端

1. ✅ **定义错误常量**（Biz层）
2. ✅ **统一错误映射**（Service层）
3. ✅ **记录错误日志**（所有层）
4. ✅ **错误信息清晰**（用户可理解）

### 前端

1. ✅ **统一拦截器**（API层）
2. ✅ **用户友好提示**（Toast/Alert）
3. ✅ **错误状态管理**（Hook层）
4. ✅ **错误边界**（Page/App层）
5. ✅ **加载状态**（防止重复提交）

---

## 常见错误场景

| 场景 | 后端错误 | 前端处理 |
|-----|---------|---------|
| 参数缺失 | `BadRequest("MISSING_PARAM")` | Toast提示 + 表单高亮 |
| 资源不存在 | `NotFound("NOT_FOUND")` | Toast提示 + 返回列表 |
| 业务规则违反 | `FailedPrecondition("XXX")` | Toast提示 + 保持原状态 |
| 网络超时 | `DeadlineExceeded` | Toast提示 + 重试按钮 |
| 服务器错误 | `InternalServer` | Toast提示 + 联系客服 |

---

*参考架构方案的"非功能性设计"章节了解错误处理要求*
