# 阶段五：测试实现指南

> 编写单元测试，覆盖核心业务逻辑

---

## 目标

编写单元测试，确保核心业务逻辑的正确性。

---

## 测试优先级

| 模块 | 必测 | 测试类型 | 目标覆盖率 | 理由 |
|-----|------|---------|-----------|------|
| **Biz层（后端）** | ✅ | 单元测试 + Mock | >80% | 核心业务逻辑 |
| **Hook层（前端）** | ✅ | 单元测试 | >80% | 核心业务逻辑 |
| **pkg层** | ✅ | 单元测试 | 100% | 纯函数，易测试 |
| Service层 | 可选 | 集成测试 | >60% | 协议适配，逻辑简单 |
| Data层 | 可选 | Mock测试 | >60% | 数据访问，逻辑简单 |
| Component | 可选 | 快照测试 | >60% | UI渲染 |
| Infra层 | 可选 | 集成测试 | >60% | 外部依赖 |

**优先测试**：Biz层（后端）+ Hook层（前端）+ pkg层

---

## 后端测试（Go）

### Biz 层单元测试

**测试框架**：`testing` + `gomock`

**文件路径**：`internal/biz/xxx_test.go`

**步骤**：

#### 1. 生成 Mock

```bash
# 安装 mockgen
go install github.com/golang/mock/mockgen@latest

# 生成 Mock（针对 Repository 接口）
mockgen -source=internal/biz/node.go -destination=internal/biz/mock/node_mock.go -package=mock_biz
```

#### 2. 编写测试

```go
package biz

import (
    "context"
    "testing"
    "github.com/golang/mock/gomock"
    "github.com/go-kratos/kratos/v2/log"
    mock_biz "wallet/internal/biz/mock"
)

func TestNodeUsecase_SwitchNetwork(t *testing.T) {
    // 表驱动测试
    tests := []struct {
        name      string
        networkID string
        mockRepo  func(t *testing.T) NodeRepo
        want      *Network
        wantErr   bool
    }{
        {
            name:      "成功切换到主网",
            networkID: "mainnet",
            mockRepo: func(t *testing.T) NodeRepo {
                ctrl := gomock.NewController(t)
                m := mock_biz.NewMockNodeRepo(ctrl)
                m.EXPECT().GetNetwork(gomock.Any(), "mainnet").Return(&Network{
                    ID: "mainnet", 
                    Name: "TRON 主网",
                    Nodes: []*Node{{IsHealthy: true}},  // 健康节点
                }, nil)
                return m
            },
            want:    &Network{ID: "mainnet", Name: "TRON 主网"},
            wantErr: false,
        },
        {
            name:      "网络ID无效",
            networkID: "invalid",
            mockRepo: func(t *testing.T) NodeRepo {
                return nil // 不会调用repo
            },
            want:    nil,
            wantErr: true,
        },
        {
            name:      "网络不健康",
            networkID: "mainnet",
            mockRepo: func(t *testing.T) NodeRepo {
                ctrl := gomock.NewController(t)
                m := mock_biz.NewMockNodeRepo(ctrl)
                m.EXPECT().GetNetwork(gomock.Any(), "mainnet").Return(&Network{
                    ID: "mainnet",
                    Nodes: []*Node{{IsHealthy: false}},  // 不健康
                }, nil)
                return m
            },
            want:    nil,
            wantErr: true,
        },
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            uc := NewNodeUsecase(tt.mockRepo(t), log.DefaultLogger)
            got, err := uc.SwitchNetwork(context.Background(), tt.networkID)
            
            if (err != nil) != tt.wantErr {
                t.Errorf("SwitchNetwork() error = %v, wantErr %v", err, tt.wantErr)
                return
            }
            
            if !tt.wantErr && got.ID != tt.want.ID {
                t.Errorf("SwitchNetwork() = %v, want %v", got, tt.want)
            }
        })
    }
}
```

### pkg 层单元测试

**文件路径**：`pkg/xxx/util_test.go`

```go
package network

import "testing"

func TestValidateNetworkID(t *testing.T) {
    tests := []struct {
        name string
        id   string
        want bool
    }{
        {"主网", "mainnet", true},
        {"Shasta测试网", "shasta", true},
        {"无效ID", "invalid", false},
        {"空ID", "", false},
    }

    for _, tt := range tests {
        t.Run(tt.name, func(t *testing.T) {
            if got := ValidateNetworkID(tt.id); got != tt.want {
                t.Errorf("ValidateNetworkID(%s) = %v, want %v", tt.id, got, tt.want)
            }
        })
    }
}
```

---

## 前端测试（TypeScript）

### Hook 单元测试

**测试框架**：`@testing-library/react` + `jest`

**文件路径**：`src/hooks/__tests__/useNetworkSwitch.test.ts`

**步骤**：

#### 1. 配置 Mock

```typescript
// src/setupTests.ts
import '@testing-library/jest-dom';

// Mock networkService
jest.mock('@/services/networkService', () => ({
  networkService: {
    switchNetwork: jest.fn(),
  },
}));
```

#### 2. 编写测试

```typescript
import { renderHook, act, waitFor } from '@testing-library/react';
import { useNetworkSwitch } from '../useNetworkSwitch';
import { networkService } from '@/services/networkService';
import { useWalletStore } from '@/stores/walletStore';

describe('useNetworkSwitch', () => {
  beforeEach(() => {
    // 清空Store状态
    useWalletStore.getState().reset();
    jest.clearAllMocks();
  });

  it('应该成功切换网络', async () => {
    // Mock API成功
    (networkService.switchNetwork as jest.Mock).mockResolvedValue({
      id: 'mainnet',
      name: 'TRON 主网',
      type: 'mainnet',
    });

    const { result } = renderHook(() => useNetworkSwitch());

    await act(async () => {
      await result.current.switchNetwork('mainnet');
    });

    await waitFor(() => {
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toBeNull();
      expect(useWalletStore.getState().currentNetwork?.id).toBe('mainnet');
    });
  });

  it('应该处理切换失败', async () => {
    // Mock API失败
    const error = new Error('Network error');
    (networkService.switchNetwork as jest.Mock).mockRejectedValue(error);

    const { result } = renderHook(() => useNetworkSwitch());

    await act(async () => {
      try {
        await result.current.switchNetwork('invalid');
      } catch (e) {
        // 预期错误
      }
    });

    await waitFor(() => {
      expect(result.current.error).toBeTruthy();
      // 应该回退到原网络
      expect(useWalletStore.getState().currentNetwork).toBeNull();
    });
  });

  it('主网切换到测试网应该显示确认弹窗', async () => {
    // 设置当前网络为主网
    useWalletStore.getState().switchNetwork('mainnet');
    await waitFor(() => {
      expect(useWalletStore.getState().currentNetwork?.type).toBe('mainnet');
    });

    const { result } = renderHook(() => useNetworkSwitch());

    act(() => {
      result.current.switchNetwork('testnet-shasta');
    });

    // 应该显示确认弹窗，而不是直接切换
    expect(result.current.showConfirm).toBe(true);
    expect(networkService.switchNetwork).not.toHaveBeenCalled();
  });
});
```

### Component 快照测试

**文件路径**：`src/components/network/__tests__/NetworkItem.test.tsx`

```typescript
import { render, screen, fireEvent } from '@testing-library/react';
import { NetworkItem } from '../NetworkItem';

describe('NetworkItem', () => {
  const mockNetwork = {
    id: 'mainnet',
    name: 'TRON 主网',
    type: 'mainnet' as const,
    icon: '/tron.png',
  };

  it('应该正确渲染', () => {
    const { container } = render(
      <NetworkItem 
        data={mockNetwork} 
        isSelected={false} 
        onClick={() => {}} 
      />
    );
    
    expect(screen.getByText('TRON 主网')).toBeInTheDocument();
    expect(container).toMatchSnapshot();
  });

  it('选中状态应该显示对勾', () => {
    render(
      <NetworkItem 
        data={mockNetwork} 
        isSelected={true} 
        onClick={() => {}} 
      />
    );
    
    expect(screen.getByTestId('CheckIcon')).toBeInTheDocument();
  });

  it('加载状态应该显示loading', () => {
    render(
      <NetworkItem 
        data={mockNetwork} 
        isSelected={false} 
        isLoading={true}
        onClick={() => {}} 
      />
    );
    
    expect(screen.getByRole('progressbar')).toBeInTheDocument();
  });

  it('点击应该触发onClick', () => {
    const handleClick = jest.fn();
    render(
      <NetworkItem 
        data={mockNetwork} 
        isSelected={false} 
        onClick={handleClick} 
      />
    );
    
    fireEvent.click(screen.getByText('TRON 主网'));
    expect(handleClick).toHaveBeenCalledWith(mockNetwork);
  });
});
```

---

## 运行测试

### 后端测试

```bash
# 运行所有测试
go test ./...

# 运行特定包
go test ./internal/biz/...

# 查看覆盖率
go test -coverprofile=coverage.out ./...
go tool cover -html=coverage.out
```

### 前端测试

```bash
# 运行所有测试
npm test

# 查看覆盖率
npm test -- --coverage

# 更新快照
npm test -- -u
```

---

## 测试覆盖率目标

| 模块 | 目标覆盖率 | 必测内容 |
|-----|-----------|---------|
| Biz层 | >80% | 所有业务规则、状态转换 |
| Hook | >80% | 所有业务逻辑、错误处理 |
| pkg | 100% | 所有纯函数 |
| 其他层 | >60% | 核心路径 |

---

## 测试清单

完成测试后，检查：

- [ ] **Biz层**：所有业务方法有测试
- [ ] **Hook层**：所有业务Hook有测试
- [ ] **pkg层**：所有纯函数有测试
- [ ] **Mock正确**：使用Mock而非真实依赖
- [ ] **边界条件**：测试了成功、失败、边界情况
- [ ] **覆盖率达标**：核心模块 >80%
- [ ] **CI集成**：测试可在CI环境运行

---

## 参考资源

- 质量检查清单：`quality-checklist.md`
- Go测试：https://golang.org/pkg/testing/
- React测试：https://testing-library.com/react

---

*完成测试后，准备提交代码*
