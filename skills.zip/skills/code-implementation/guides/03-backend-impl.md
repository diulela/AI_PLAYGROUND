# 阶段三：后端实现指南

> 按照分层架构实现 Go 后端代码

---

## 目标

按照 Kratos 5层架构（pkg/Infra/Data/Biz/Service），实现后端各层代码。

---

## 实现顺序（从底向上）

```
1. pkg层（如果有纯函数工具）
2. Infra层（基础设施）
3. Data层（数据访问）
4. Biz层（业务逻辑）
5. Service层（API适配）
```

**为什么从底向上？**  
- 上层依赖下层
- 先实现基础设施和数据访问，Biz层才能调用
- 最后实现 Service 层进行协议适配

---

## pkg 层实现（可选）

### 判断是否需要

**从架构方案判断**：
- ✅ 架构方案中提到"纯函数"、"工具函数"
- ✅ 有跨层复用的逻辑
- ❌ 没有提到 pkg 层 → 跳过

### 实现规范

**文件路径**：`pkg/xxx/util.go`

**示例**：

```go
package network

// ValidateNetworkID 校验网络ID格式（纯函数）
func ValidateNetworkID(id string) bool {
    validIDs := []string{"mainnet", "shasta", "nile"}
    for _, v := range validIDs {
        if id == v {
            return true
        }
    }
    return false
}

// FormatAddress 格式化地址显示（纯函数）
func FormatAddress(addr string) string {
    if len(addr) <= 10 {
        return addr
    }
    return addr[:6] + "..." + addr[len(addr)-4:]
}
```

**原则**：
- ✅ 无状态、无外部依赖
- ✅ 纯函数（相同输入 → 相同输出）
- ✅ 可被任意层调用
- ❌ 不包含业务规则
- ❌ 不依赖配置文件

---

## Infra 层实现

### 判断是否需要

**从架构方案判断**：
- ✅ 需要调用外部API（TronGrid、第三方服务）
- ✅ 需要技术能力（加密、缓存、限流）
- ❌ 没有外部集成 → 跳过

### 实现规范

**文件路径**：`internal/infra/xxx/client.go`

**步骤**：

#### 1. 定义 Client 结构体

```go
package trongrid

import (
    "context"
    "net/http"
    "time"
)

type Client struct {
    baseURL    string
    httpClient *http.Client
    log        *log.Helper
}
```

#### 2. 实现 New 构造函数

```go
func NewClient(baseURL string, logger log.Logger) *Client {
    return &Client{
        baseURL: baseURL,
        httpClient: &http.Client{
            Timeout: 10 * time.Second,
        },
        log: log.NewHelper(logger),
    }
}
```

#### 3. 实现技术能力方法

```go
// HealthCheck 健康检查（技术能力，非业务逻辑）
func (c *Client) HealthCheck(ctx context.Context) (bool, error) {
    req, err := http.NewRequestWithContext(ctx, "GET", c.baseURL+"/health", nil)
    if err != nil {
        return false, err
    }

    resp, err := c.httpClient.Do(req)
    if err != nil {
        c.log.Errorf("health check failed: %v", err)
        return false, err
    }
    defer resp.Body.Close()

    return resp.StatusCode == 200, nil
}

// GetBlockNumber 获取最新区块高度
func (c *Client) GetBlockNumber(ctx context.Context) (int64, error) {
    // HTTP 请求实现...
    return blockNumber, nil
}
```

**关键点**：
- ✅ 提供技术能力（HTTP调用、加密、缓存）
- ✅ 与业务领域无关（可被多个模块复用）
- ✅ 错误处理（记录日志）
- ❌ 不包含业务规则

**参考**：`../../architecture-design/patterns/backend-patterns.md`

---

## Data 层实现

### 职责

将原始数据转换为领域对象，提供 Repository 接口实现。

### 实现规范

**文件路径**：`internal/data/xxx.go`

**步骤**：

#### 1. 定义 Repository 结构体

```go
package data

import (
    "context"
    "wallet/internal/biz"
    "github.com/go-kratos/kratos/v2/log"
)

type nodeRepo struct {
    data *Data  // Data结构体（包含DB、缓存等）
    log  *log.Helper
}

// NewNodeRepo 创建Repository实现
// 这里实现的是 biz.NodeRepo 接口
func NewNodeRepo(data *Data, logger log.Logger) biz.NodeRepo {
    return &nodeRepo{
        data: data,
        log:  log.NewHelper(logger),
    }
}
```

#### 2. 实现 Repository 方法

```go
// ListNodes 从数据源获取节点列表
func (r *nodeRepo) ListNodes(ctx context.Context, networkType string) ([]*biz.Network, error) {
    // 1. 从数据源获取数据（硬编码/数据库/Infra客户端）
    // 根据架构方案的"Data层职责"
    
    // 示例：从硬编码获取（v1.0）
    rawNodes := getOfficialNodes(networkType)
    
    // 2. 转换为领域对象
    networks := make([]*biz.Network, 0, len(rawNodes))
    for _, raw := range rawNodes {
        network := &biz.Network{
            ID:   raw.ID,
            Name: raw.Name,
            Type: biz.NetworkType(raw.Type),
        }
        networks = append(networks, network)
    }
    
    // 3. 错误处理
    if len(networks) == 0 {
        r.log.Warnf("no networks found for type: %s", networkType)
    }
    
    return networks, nil
}

// GetNetwork 获取单个网络信息
func (r *nodeRepo) GetNetwork(ctx context.Context, id string) (*biz.Network, error) {
    // 1. 校验参数
    if id == "" {
        return nil, errors.New("network id is required")
    }
    
    // 2. 查询数据
    rawNode := findNodeByID(id)
    if rawNode == nil {
        return nil, errors.New("network not found")
    }
    
    // 3. 转换为领域对象
    network := &biz.Network{
        ID:   rawNode.ID,
        Name: rawNode.Name,
    }
    
    return network, nil
}
```

**关键点**：
- ✅ 将原始数据转换为领域对象（`biz.Network`）
- ✅ 错误处理（记录日志、返回 Kratos 错误）
- ✅ 可调用 Infra 层客户端获取原始数据
- ❌ 不包含业务规则（业务规则在 Biz 层）

---

## Biz 层实现

### 职责

实现业务逻辑，定义领域对象和 Repository 接口。

### 实现规范

**文件路径**：`internal/biz/xxx.go`

**步骤**：

#### 1. 定义领域对象

```go
package biz

type NetworkType int32

const (
    NetworkTypeMainnet NetworkType = 1
    NetworkTypeTestnet NetworkType = 2
)

// Network 领域对象（聚合根）
type Network struct {
    ID    string
    Name  string
    Type  NetworkType
    Nodes []*Node
}

// IsHealthy 业务规则：网络是否健康
func (n *Network) IsHealthy() bool {
    if len(n.Nodes) == 0 {
        return false
    }
    // 至少有一个节点健康
    for _, node := range n.Nodes {
        if node.IsHealthy {
            return true
        }
    }
    return false
}

type Node struct {
    Name      string
    URL       string
    LatencyMs int32
    IsHealthy bool
}
```

#### 2. 定义 Repository 接口

```go
// NodeRepo Repository接口（由 Data 层实现）
type NodeRepo interface {
    ListNodes(ctx context.Context, networkType string) ([]*Network, error)
    GetNetwork(ctx context.Context, id string) (*Network, error)
    // SaveNetwork(ctx context.Context, network *Network) error  // v2.0 增强
}
```

#### 3. 定义 Usecase

```go
type NodeUsecase struct {
    repo NodeRepo
    log  *log.Helper
}

func NewNodeUsecase(repo NodeRepo, logger log.Logger) *NodeUsecase {
    return &NodeUsecase{
        repo: repo,
        log:  log.NewHelper(logger),
    }
}
```

#### 4. 实现业务方法

```go
// SwitchNetwork 切换网络（业务逻辑）
func (uc *NodeUsecase) SwitchNetwork(ctx context.Context, networkID string) (*Network, error) {
    // 根据架构方案的"业务流程描述"
    
    // 1. 校验参数（业务规则）
    if !pkg.ValidateNetworkID(networkID) {
        uc.log.Warnf("invalid network ID: %s", networkID)
        return nil, errors.New("invalid network ID")
    }

    // 2. 调用 repo 获取数据
    network, err := uc.repo.GetNetwork(ctx, networkID)
    if err != nil {
        uc.log.Errorf("failed to get network: %v", err)
        return nil, err
    }

    // 3. 业务规则判断（状态转换、权限检查）
    if !network.IsHealthy() {
        uc.log.Warnf("network %s is not healthy", networkID)
        return nil, errors.New("network is not healthy")
    }

    // 4. 返回领域对象
    uc.log.Infof("switched to network: %s", network.Name)
    return network, nil
}
```

**关键点**：
- ✅ 实现架构方案中的"业务规则"
- ✅ 调用 Repository 接口（不直接访问数据库）
- ✅ 领域对象方法封装业务规则（`IsHealthy()`）
- ❌ 不处理 HTTP/gRPC 协议细节（Service 层处理）

---

## Service 层实现

### 职责

协议适配、参数校验、错误码映射、DTO转换。

### 实现规范

**文件路径**：`internal/service/xxx.go`

**步骤**：

#### 1. 定义 Service

```go
package service

import (
    pb "wallet/api/wallet/v1"
    "wallet/internal/biz"
)

type NodeService struct {
    pb.UnimplementedNodeServiceServer
    uc  *biz.NodeUsecase
    log *log.Helper
}

func NewNodeService(uc *biz.NodeUsecase, logger log.Logger) *NodeService {
    return &NodeService{
        uc:  uc,
        log: log.NewHelper(logger),
    }
}
```

#### 2. 实现 RPC 方法

```go
func (s *NodeService) SwitchNetwork(ctx context.Context, req *pb.SwitchNetworkRequest) (*pb.SwitchNetworkResponse, error) {
    // 1. 参数校验（协议层）
    if req.NetworkId == "" {
        return nil, errors.BadRequest("INVALID_ARGUMENT", "network_id is required")
    }

    // 2. 调用 Biz 层
    network, err := s.uc.SwitchNetwork(ctx, req.NetworkId)
    if err != nil {
        // 3. 错误码映射
        if strings.Contains(err.Error(), "not found") {
            return nil, errors.NotFound("NETWORK_NOT_FOUND", err.Error())
        }
        if strings.Contains(err.Error(), "not healthy") {
            return nil, errors.FailedPrecondition("NETWORK_UNHEALTHY", err.Error())
        }
        return nil, errors.InternalServer("SWITCH_FAILED", err.Error())
    }

    // 4. DTO 转换（领域对象 → Protobuf）
    return &pb.SwitchNetworkResponse{
        Network: s.toProtoNetwork(network),
    }, nil
}

// toProtoNetwork 领域对象 → Protobuf
func (s *NodeService) toProtoNetwork(network *biz.Network) *pb.NetworkInfo {
    return &pb.NetworkInfo{
        Id:   network.ID,
        Name: network.Name,
        Type: pb.NetworkType(network.Type),
    }
}
```

**关键点**：
- ✅ 参数校验（格式、必填）
- ✅ 错误码映射（业务错误 → gRPC codes）
- ✅ DTO 转换（`biz.Network` → `pb.NetworkInfo`）
- ❌ 不包含业务逻辑（业务逻辑在 Biz 层）

---

## 输出检查清单

完成后端实现后，检查：

- [ ] **pkg层**：纯函数、无状态、无外部依赖
- [ ] **Infra层**：技术能力、可复用、与业务无关
- [ ] **Data层**：实现Repository接口、数据转换、错误处理
- [ ] **Biz层**：领域对象、业务规则、调用Repository
- [ ] **Service层**：参数校验、错误映射、DTO转换
- [ ] **依赖方向**：Service → Biz → Data → Infra（无反向依赖）
- [ ] **错误处理**：所有 `err != nil` 都已处理
- [ ] **日志记录**：关键操作有日志（INFO/ERROR）

---

## 参考资源

- 后端代码模板：`../../architecture-design/patterns/backend-patterns.md`
- 后端分层架构：`../../architecture-design/architecture/backend-layers.md`

---

*完成后端实现后，进入阶段四：前端实现*
