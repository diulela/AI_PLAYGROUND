# 代码实现指南导航

本目录包含代码实现的详细指南，按需查阅。

---

## 📚 指南列表

| 指南 | 内容 | 何时阅读 | 行数 |
|-----|------|---------|------|
| [01-architecture-reading.md](01-architecture-reading.md) | 架构方案阅读与分析 | 阶段一：开始实现前 | ~100行 |
| [02-protobuf-impl.md](02-protobuf-impl.md) | protobuf 实现指南 | 阶段二：API定义 | ~180行 |
| [03-backend-impl.md](03-backend-impl.md) | 后端实现指南（5层） | 阶段三：后端实现 | ~250行 |
| [04-frontend-impl.md](04-frontend-impl.md) | 前端实现指南（5层） | 阶段四：前端实现 | ~200行 |
| [05-testing.md](05-testing.md) | 测试实现指南 | 阶段五：测试 | ~150行 |
| [error-handling.md](error-handling.md) | 错误处理模式 | 需要时查阅 | ~120行 |
| [quality-checklist.md](quality-checklist.md) | 质量检查清单 | 提交前检查 | ~100行 |

**总计**：~1100 行（拆分为 7 个文件）

---

## 🎯 使用方式

### 完整实现流程

```
用户：实现 REQ-046

AI执行：
1. 读取 SKILL.md（主流程）
2. 阶段一 → 读取 01-architecture-reading.md
3. 阶段二 → 读取 02-protobuf-impl.md
4. 阶段三 → 读取 03-backend-impl.md
5. 阶段四 → 读取 04-frontend-impl.md
6. 阶段五 → 读取 05-testing.md
7. 提交前 → 读取 quality-checklist.md
```

### 部分实现流程

```
用户：编写 REQ-046 的 protobuf

AI执行：
1. 读取 SKILL.md（主流程）
2. 跳转到阶段二 → 读取 02-protobuf-impl.md
3. 产出 .proto 文件
```

---

## 💡 Token 优化

**优化前**（单文件）：
- SKILL.md：1112 行
- AI 每次加载全部内容

**优化后**（模块化）：
- SKILL.md：~250 行（主流程）
- 按需加载指南：~150-250 行/阶段

**Token 节省**：
- 完整流程：250 + 150×5 = 1000 行（vs 原 1112 行，节省 10%）
- 部分流程：250 + 180 = 430 行（vs 原 1112 行，**节省 61%**）

---

## 🔗 与其他资源的关系

```
guides/（实现指南）
  ↓ 引用
../../architecture-design/patterns/（代码模板）
  ↓ 引用
../../architecture-design/architecture/（架构思维）
```

**认知层次**：
1. **guides/**：实现步骤和规范（What & How）
2. **patterns/**：代码模板和示例（Template）
3. **architecture/**：架构思维和原则（Why）

---

## 📖 快速参考

| 需要什么 | 查阅哪里 |
|---------|---------|
| 如何读取架构方案？ | `01-architecture-reading.md` |
| protobuf 语法规范？ | `02-protobuf-impl.md` |
| 后端分层怎么实现？ | `03-backend-impl.md` |
| 前端组件怎么写？ | `04-frontend-impl.md` |
| 如何编写测试？ | `05-testing.md` |
| 错误怎么处理？ | `error-handling.md` |
| 提交前检查什么？ | `quality-checklist.md` |
| 代码模板在哪里？ | `../../architecture-design/patterns/` |

---

*按需加载，只读需要的指南，节省token*
