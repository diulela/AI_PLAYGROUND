# 代码质量检查清单

> 提交代码前必检

---

## 后端代码检查（7项）

### 1. 代码格式化

```bash
# 运行 gofmt
gofmt -w .

# 或使用 goimports（推荐）
goimports -w .
```

- [ ] 代码已格式化（无缩进、空格问题）

### 2. Lint 检查

```bash
# 运行 golangci-lint
golangci-lint run
```

- [ ] 无 lint 错误
- [ ] 无 unused import
- [ ] 无 unused variable

### 3. 错误处理

- [ ] 所有 `err != nil` 都已处理
- [ ] 不使用 `panic`（除非程序必须终止）
- [ ] 错误信息清晰（用户可理解）

### 4. 日志记录

- [ ] 关键操作有 INFO 日志（API调用、状态变更）
- [ ] 错误有 ERROR 日志（包含上下文）
- [ ] 不记录敏感信息（密码、私钥）

### 5. 单元测试

- [ ] Biz层核心逻辑有测试
- [ ] pkg层所有函数有测试
- [ ] 测试覆盖率 >80%（Biz层）

### 6. 接口实现

- [ ] 实现了架构方案定义的所有 Repository 接口
- [ ] 接口签名与 Biz 层定义一致

### 7. 分层正确

- [ ] Service 不直接调用 Data（必须通过 Biz）
- [ ] Biz 不直接访问数据库（必须通过 Repository）
- [ ] Data 不包含业务规则
- [ ] Infra 与业务领域无关

---

## 前端代码检查（7项）

### 1. 代码格式化

```bash
# 运行 ESLint
npm run lint

# 自动修复
npm run lint -- --fix
```

- [ ] 代码已格式化
- [ ] 无 ESLint 错误

### 2. 类型检查

```bash
# 运行 TypeScript 类型检查
npm run type-check
```

- [ ] 无 TypeScript 错误
- [ ] 所有函数参数有类型定义
- [ ] 所有组件 Props 有接口定义

### 3. Props 定义

- [ ] 所有组件 Props 有 TypeScript 接口
- [ ] Props 接口有 JSDoc 注释
- [ ] 可选Props有 `?` 标记

### 4. 错误边界

- [ ] 关键页面有 ErrorBoundary 包裹
- [ ] 异步操作有 try-catch
- [ ] 错误有用户友好的提示

### 5. 加载状态

- [ ] 所有异步操作有 loading 状态
- [ ] loading 时禁用交互（按钮 disabled）
- [ ] 有 loading 提示（Spinner/Skeleton）

### 6. 错误提示

- [ ] 所有错误有 Toast/Alert 提示
- [ ] 错误信息清晰（用户可理解）
- [ ] 不暴露技术细节（如堆栈信息）

### 7. Hook 测试

- [ ] 核心 Hook 有单元测试
- [ ] 测试覆盖成功、失败、边界情况

---

## 通用检查（5项）

### 1. 架构一致性

- [ ] 代码实现符合架构方案的分层职责
- [ ] 没有偏离架构师的设计意图
- [ ] 关键决策得到落实

### 2. 命名规范

**后端（Go）**：
- [ ] 函数名：大写开头（公开）、小写开头（私有）
- [ ] 变量名：驼峰命名（camelCase）
- [ ] 接口名：`er` 结尾（如 `Reader`、`Writer`）

**前端（TypeScript）**：
- [ ] 组件名：大写开头（PascalCase）
- [ ] 函数名：小写开头（camelCase）
- [ ] 接口名：大写开头（PascalCase）
- [ ] 常量：大写 + 下划线（UPPER_CASE）

### 3. 注释清晰

- [ ] 复杂逻辑有注释（解释"为什么"）
- [ ] 公开函数有注释（功能说明）
- [ ] 不写无意义注释（如 `// 定义变量`）

### 4. 性能考虑

- [ ] 遵循架构方案中的性能指标（响应时间）
- [ ] 无明显性能问题（N+1查询、无限循环）
- [ ] 合理使用缓存

### 5. 安全实践

- [ ] 敏感数据加密（密码、私钥）
- [ ] 输入校验（防止注入）
- [ ] 不在日志中记录敏感信息
- [ ] 使用 HTTPS

---

## 提交前最后检查

```bash
# 后端
cd backend
go test ./...           # 测试通过
golangci-lint run       # Lint通过
go mod tidy             # 依赖整理

# 前端
cd frontend
npm test                # 测试通过
npm run lint            # Lint通过
npm run type-check      # 类型检查通过
npm run build           # 构建成功
```

- [ ] 所有测试通过
- [ ] 所有 Lint 检查通过
- [ ] 构建成功（无编译错误）
- [ ] 本地运行正常（手动测试核心功能）

---

## 代码审查要点

在提交 PR 前，自我审查：

- [ ] **是否符合架构方案**？
  - 分层职责是否正确？
  - 是否有跨层调用？

- [ ] **代码可读性**？
  - 变量命名是否清晰？
  - 复杂逻辑是否有注释？

- [ ] **错误处理是否完整**？
  - 所有错误是否都有处理？
  - 错误信息是否清晰？

- [ ] **测试是否充分**？
  - 核心业务逻辑是否有测试？
  - 覆盖率是否达标？

- [ ] **性能是否合理**？
  - 是否有明显性能问题？
  - 是否符合架构方案的性能指标？

---

*完整的质量检查清单参见 `../../architecture-design/patterns/quality-checklist.md`*
