---
name: code-implementation
description: 开发者视角的代码实现工作流：读取架构设计方案，产出可运行的代码实现（protobuf定义、接口签名、业务逻辑、UI组件）。支持Go后端实现（Kratos框架）、React前端实现（TypeScript + MUI）、测试代码生成。当用户要求"实现 REQ-XXX"、"编写 protobuf"、"实现接口"时使用此技能。使用中文输出。
---

# 代码实现工作流（开发者视角）

---

⚠️⚠️⚠️ **AI 执行约束（必读 - 贯穿全流程）** ⚠️⚠️⚠️

**你的角色**：开发者（不是架构师！）

**工作依据**：
- 必须先读取架构设计方案文档（`prd/architecture/REQ-XXX_架构设计方案.md`）
- 根据架构方案产出可运行的代码
- 严格遵循架构方案的分层职责，不自行调整

**输出内容**：
- ✅ protobuf 定义（`.proto` 文件）
- ✅ Go 接口签名和实现（`internal/service|biz|data|infra|pkg`）
- ✅ TypeScript 组件和 Hook（`src/components|hooks|stores|services`）
- ✅ 测试代码（单元测试、集成测试）

---

## 核心理念

**代码实现 = 架构方案的落地**

开发者职责：将架构师的"语义设计"转换为"可执行代码"

**开发者关注**：
- **接口定义** — protobuf 字段类型、Go interface、TypeScript Props
- **业务逻辑** — 完整的函数实现、错误处理、边界条件
- **数据访问** — 数据库查询、缓存策略、事务管理
- **UI 组件** — React 组件实现、样式、交互
- **测试覆盖** — 单元测试、集成测试、E2E 测试
- **三方库正确使用** - 使用mcp context7查阅最新三方库文档

---

## 使用场景判断

| 用户输入 | 执行流程 | 输出内容 |
|---------|---------|---------|
| "实现 REQ-XXX" | 完整五阶段实现 | protobuf + 后端代码 + 前端代码 + 测试 |
| "编写 protobuf" | 跳转阶段二 | `.proto` 文件 |
| "实现后端接口" | 跳转阶段三 | Go 代码（Service/Biz/Data/Infra） |
| "实现前端组件" | 跳转阶段四 | TypeScript 组件 + Hook + Store |
| "编写测试" | 跳转阶段五 | 测试文件 |

**前置要求**：
- 必须存在对应的架构设计方案文档（`prd/architecture/REQ-XXX_架构设计方案.md`）
- 如果不存在，先使用 `architecture-design` 技能产出架构方案

---

## 实现流程（五阶段）

### 阶段一：读取并分析架构方案（5分钟）

**目标**：理解架构师的设计意图，提取实现要点

**步骤**：
1. 读取架构设计文档（`prd/architecture/REQ-XXX_架构设计方案.md`）
2. 提取关键信息：
   - 领域对象（聚合根、实体、值对象）→ 用于 protobuf
   - API语义契约（功能、输入、输出）→ 用于 protobuf
   - 分层职责（Service/Biz/Data/Infra/pkg）→ 用于后端代码
   - 组件职责（Component树）→ 用于前端代码
   - 状态管理策略 → 用于 Store/Hook
3. 理解设计意图（为什么选这个方案？有哪些权衡？）
4. 检查前置条件（架构文档完整？API依赖？三方库？）

**详细指南**：见 [guides/01-architecture-reading.md](guides/01-architecture-reading.md)

---

### 阶段二：API 定义（protobuf）（10分钟）

**目标**：根据架构方案的"API语义契约"和"领域建模"，编写 protobuf 定义

**步骤**：
1. 领域对象 → protobuf message（聚合根/实体/值对象/枚举）
2. API语义 → service 和 rpc 定义
3. 错误场景 → 错误码 enum
4. 添加验证规则（protoc-gen-validate）

**输出**：`api/wallet/v1/xxx.proto`

**输出检查**：
- [ ] message 字段类型正确
- [ ] rpc 命名符合 RESTful
- [ ] 错误码定义完整（至少3种）
- [ ] 有注释说明

**详细指南**：见 [guides/02-protobuf-impl.md](guides/02-protobuf-impl.md)

---

### 阶段三：后端实现（30分钟）

**目标**：按照 Kratos 5层架构（pkg/Infra/Data/Biz/Service），实现后端代码

**实现顺序**（从底向上）：
```
1. pkg层（纯函数工具）
2. Infra层（基础设施）
3. Data层（数据访问）
4. Biz层（业务逻辑）
5. Service层（API适配）
```

**输出**：
- `internal/service/xxx.go`（RPC实现、错误映射、DTO转换）
- `internal/biz/xxx.go`（领域对象、业务规则、Usecase）
- `internal/data/xxx.go`（Repository实现、数据转换）
- `internal/infra/xxx/client.go`（外部集成、技术能力）
- `pkg/xxx/util.go`（纯函数工具）

**输出检查**：
- [ ] 依赖方向正确（Service → Biz → Data → Infra）
- [ ] 错误处理完整（所有 err != nil 已处理）
- [ ] 日志记录（关键操作）
- [ ] 符合架构方案的分层职责

**详细指南**：见 [guides/03-backend-impl.md](guides/03-backend-impl.md)

---

### 阶段四：前端实现（30分钟）

**目标**：按照 React 5层架构（Service/Store/Hook/Component/Page），实现前端代码

**实现顺序**（从底向上）：
```
1. Service层（API调用）
2. Store层（全局状态，如果需要）
3. Hook层（业务逻辑）
4. Component层（可复用UI）
5. Page层（页面入口）
```

**输出**：
- `src/services/xxxService.ts`（API调用、类型转换）
- `src/stores/xxxStore.ts`（Zustand Store、持久化）
- `src/hooks/useXxx.ts`（业务逻辑、副作用）
- `src/components/xxx/XxxItem.tsx`（UI组件、Props接口）
- `src/pages/XxxPage.tsx`（页面入口、组合组件）

**输出检查**：
- [ ] TypeScript 类型定义完整
- [ ] 错误处理（Toast提示）
- [ ] 加载状态（loading）
- [ ] 符合架构方案的组件职责

**详细指南**：见 [guides/04-frontend-impl.md](guides/04-frontend-impl.md)

---

### 阶段五：测试代码（15分钟）

**目标**：编写单元测试，覆盖核心业务逻辑

**测试优先级**：
- ✅ **必测**：Biz层（后端）、Hook层（前端）、pkg层
- ⚪ **可选**：Service、Data、Component、Infra

**输出**：
- `internal/biz/xxx_test.go`（Biz层单元测试，gomock）
- `src/hooks/__tests__/useXxx.test.ts`（Hook单元测试）
- `pkg/xxx/util_test.go`（pkg层单元测试）

**输出检查**：
- [ ] Biz层测试覆盖率 >80%
- [ ] Hook层测试覆盖率 >80%
- [ ] pkg层测试覆盖率 100%
- [ ] 测试了成功、失败、边界情况

**详细指南**：见 [guides/05-testing.md](guides/05-testing.md)

---

## 按需查阅资源

**实现指南**（本技能）：
- 架构方案阅读 → [guides/01-architecture-reading.md](guides/01-architecture-reading.md)
- protobuf实现 → [guides/02-protobuf-impl.md](guides/02-protobuf-impl.md)
- 后端实现 → [guides/03-backend-impl.md](guides/03-backend-impl.md)
- 前端实现 → [guides/04-frontend-impl.md](guides/04-frontend-impl.md)
- 测试实现 → [guides/05-testing.md](guides/05-testing.md)
- 错误处理 → [guides/error-handling.md](guides/error-handling.md)
- 质量检查 → [guides/quality-checklist.md](guides/quality-checklist.md)
- 指南导航 → [guides/README.md](guides/README.md)

**代码模板**（从 architecture-design 引用）：
- API 代码模板 → `../architecture-design/patterns/api-patterns.md`
- 后端代码模板 → `../architecture-design/patterns/backend-patterns.md`
- 前端代码模板 → `../architecture-design/patterns/frontend-patterns.md`
- 质量检查清单 → `../architecture-design/patterns/quality-checklist.md`

**架构思维**（理解设计意图）：
- 领域建模（DDD） → `../architecture-design/architecture/design-thinking.md`
- 后端分层架构 → `../architecture-design/architecture/backend-layers.md`
- 前端分层架构 → `../architecture-design/architecture/frontend-architecture.md`

---

## 实现原则（开发者视角）

1. **遵循架构方案** — 严格按照架构师的分层职责实现，不自行调整
2. **代码规范** — 遵循 Go、TypeScript 代码规范（gofmt、eslint）
3. **错误处理** — 完整的错误处理，不省略 `if err != nil`
4. **注释清晰** — 复杂逻辑添加注释，解释"为什么"
5. **测试覆盖** — 核心业务逻辑必须有单元测试（Biz/Hook >80%）
6. **性能考虑** — 遵循架构方案中的性能指标（响应时间、并发）
7. **安全实践** — 遵循架构方案中的安全要求（鉴权、加密、输入校验）
8. **用户体验** — 所有异步操作有loading状态，所有错误有友好提示

---

## 与 architecture-design 技能协作

### 协作模式

```mermaid
graph LR
    A[需求文档 PRD] -->|输入| B[architecture-design]
    B -->|架构方案| C[code-implementation]
    C -->|代码实现| D[可运行项目]
    
    style B fill:#e1f5ff
    style C fill:#fff4e1
```

### 模式1：完整串联

**用户输入**：`设计并实现 REQ-046`

**执行流程**：
1. 调用 `architecture-design`：产出架构方案
2. 调用 `code-implementation`：读取方案 → 产出代码

### 模式2：独立调用

**用户输入**：`实现 REQ-046`

**前置条件**：`prd/architecture/REQ-046_架构设计方案.md` 已存在

**执行流程**：
1. 读取架构方案
2. 执行五阶段实现

### 模式3：部分实现

**用户输入**：`编写 REQ-046 的 protobuf`

**执行流程**：
1. 读取架构方案
2. 跳转到阶段二
3. 产出 `.proto` 文件

---

## 提交前检查

**在提交代码前，必须完成以下检查**：

### 快速自检（5项）

- [ ] 代码已格式化（gofmt/eslint）
- [ ] Lint 检查通过（golangci-lint/npm run lint）
- [ ] 类型检查通过（TypeScript）
- [ ] 核心测试通过（Biz/Hook/pkg >80%覆盖）
- [ ] 本地运行正常（手动测试核心功能）

**详细检查清单**：见 [guides/quality-checklist.md](guides/quality-checklist.md)

---

## 关键输出物

### 后端代码结构

```
backend/
├── api/wallet/v1/
│   └── xxx.proto              # protobuf定义
├── internal/
│   ├── service/xxx.go         # RPC实现
│   ├── biz/xxx.go             # 业务逻辑 + 领域对象
│   ├── data/xxx.go            # Repository实现
│   └── infra/xxx/client.go    # 外部集成
├── pkg/xxx/util.go            # 工具函数
└── internal/biz/xxx_test.go   # 单元测试
```

### 前端代码结构

```
frontend/src/
├── services/xxxService.ts     # API调用
├── stores/xxxStore.ts         # Zustand Store
├── hooks/useXxx.ts            # 业务逻辑
├── components/xxx/
│   └── XxxItem.tsx            # UI组件
├── pages/XxxPage.tsx          # 页面入口
└── hooks/__tests__/
    └── useXxx.test.ts         # 单元测试
```

---

## 增量实现（未来增强）

### 场景：v1.0 → v2.0 演进

**判断**：架构方案中标注"v2.0增强"？

**步骤**：
1. **对比差异**：找出 v1.0 和 v2.0 的差异
2. **读取现有代码**：理解当前实现
3. **最小化修改**：只修改变更部分
4. **测试兼容性**：确保向后兼容

**示例**：
```
v1.0：硬编码4个官方节点
v2.0：增加"自定义节点"功能

增量修改：
- Data层：新增 CustomNodeRepo
- Biz层：新增 AddCustomNode() 方法
- Service层：新增 AddCustomNode RPC
- 前端：新增 AddNodeDialog 组件

不修改：
- v1.0 的官方节点列表逻辑
- 现有的网络切换逻辑
```

---

*本技能由 `architecture-design` 技能拆分而来，专注于代码实现阶段*
