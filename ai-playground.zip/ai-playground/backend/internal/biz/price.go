package biz

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"
)

// TokenPriceInfo is the domain model for token prices.
type TokenPriceInfo struct {
	Symbol    string
	Name      string
	PriceUSD  float64
	Change24h float64
	UpdatedAt int64
}

// PriceRepo is the interface for price data access.
type PriceRepo interface {
	GetPrices(ctx context.Context, symbols []string) ([]*TokenPriceInfo, error)
}

// PriceUsecase contains business logic for token prices.
type PriceUsecase struct {
	repo PriceRepo
	log  *log.Helper
}

func NewPriceUsecase(repo PriceRepo, logger log.Logger) *PriceUsecase {
	return &PriceUsecase{
		repo: repo,
		log:  log.NewHelper(logger),
	}
}

// GetPrices returns prices for the given token symbols.
func (uc *PriceUsecase) GetPrices(ctx context.Context, symbols []string) ([]*TokenPriceInfo, error) {
	return uc.repo.GetPrices(ctx, symbols)
}
