package conf

import "time"

// Bootstrap is the root configuration.
type Bootstrap struct {
	Server ServerConfig `json:"server" yaml:"server"`
	Data   DataConfig   `json:"data" yaml:"data"`
	Price  PriceConfig  `json:"price" yaml:"price"`
}

type ServerConfig struct {
	HTTP ServerItem `json:"http" yaml:"http"`
	GRPC ServerItem `json:"grpc" yaml:"grpc"`
}

type ServerItem struct {
	Addr    string        `json:"addr" yaml:"addr"`
	Timeout time.Duration `json:"timeout" yaml:"timeout"`
}

type DataConfig struct {
	Database DatabaseConfig `json:"database" yaml:"database"`
	Redis    RedisConfig    `json:"redis" yaml:"redis"`
}

type DatabaseConfig struct {
	Driver string `json:"driver" yaml:"driver"`
	Source string `json:"source" yaml:"source"`
}

type RedisConfig struct {
	Addr         string        `json:"addr" yaml:"addr"`
	ReadTimeout  time.Duration `json:"read_timeout" yaml:"read_timeout"`
	WriteTimeout time.Duration `json:"write_timeout" yaml:"write_timeout"`
}

type PriceConfig struct {
	RefreshInterval time.Duration `json:"refresh_interval" yaml:"refresh_interval"`
	Sources         []string      `json:"sources" yaml:"sources"`
}
