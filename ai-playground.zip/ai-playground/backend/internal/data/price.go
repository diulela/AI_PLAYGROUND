package data

import (
	"context"
	"time"

	"github.com/go-kratos/kratos/v2/log"

	"tronwallet/internal/biz"
)

type priceRepo struct {
	data *Data
	log  *log.Helper
}

// NewPriceRepo creates a new PriceRepo implementation.
func NewPriceRepo(data *Data, logger log.Logger) biz.PriceRepo {
	return &priceRepo{
		data: data,
		log:  log.NewHelper(logger),
	}
}

func (r *priceRepo) GetPrices(ctx context.Context, symbols []string) ([]*biz.TokenPriceInfo, error) {
	// TODO: implement CoinGecko API call with Redis caching
	// For now, return mock data
	now := time.Now().Unix()
	return []*biz.TokenPriceInfo{
		{Symbol: "TRX", Name: "TRON", PriceUSD: 0.274, Change24h: 2.5, UpdatedAt: now},
		{Symbol: "USDT", Name: "Tether USD", PriceUSD: 1.0, Change24h: 0.01, UpdatedAt: now},
	}, nil
}
