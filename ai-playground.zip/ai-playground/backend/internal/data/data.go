package data

import (
	"context"
	"time"

	"github.com/go-kratos/kratos/v2/log"
	"github.com/redis/go-redis/v9"

	"tronwallet/internal/conf"
)

// Data holds database and cache connections.
type Data struct {
	rdb *redis.Client
	// db will be added when Ent is initialized
}

// NewData creates a new Data instance.
func NewData(c *conf.Bootstrap, logger log.Logger) (*Data, func(), error) {
	helper := log.NewHelper(logger)

	rdb := redis.NewClient(&redis.Options{
		Addr:         c.Data.Redis.Addr,
		ReadTimeout:  c.Data.Redis.ReadTimeout,
		WriteTimeout: c.Data.Redis.WriteTimeout,
	})

	// Verify Redis connection
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	if err := rdb.Ping(ctx).Err(); err != nil {
		helper.Warnf("Redis connection failed (non-fatal): %v", err)
	}

	cleanup := func() {
		helper.Info("closing data resources")
		if err := rdb.Close(); err != nil {
			helper.Errorf("failed to close redis: %v", err)
		}
	}

	return &Data{rdb: rdb}, cleanup, nil
}
