package server

import (
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/transport/grpc"

	v1 "tronwallet/api/wallet/v1"
	"tronwallet/internal/conf"
	"tronwallet/internal/service"
)

// NewGRPCServer creates a gRPC server.
func NewGRPCServer(
	c *conf.Bootstrap,
	logger log.Logger,
	priceSvc *service.PriceService,
	txSvc *service.TransactionService,
	riskSvc *service.RiskService,
	nodeSvc *service.NodeService,
	tokenSvc *service.TokenService,
) *grpc.Server {
	opts := []grpc.ServerOption{
		grpc.Middleware(
			recovery.Recovery(),
			logging.Server(logger),
		),
	}

	if c.Server.GRPC.Addr != "" {
		opts = append(opts, grpc.Address(c.Server.GRPC.Addr))
	}
	if c.Server.GRPC.Timeout > 0 {
		opts = append(opts, grpc.Timeout(c.Server.GRPC.Timeout))
	}

	srv := grpc.NewServer(opts...)

	v1.RegisterPriceServiceServer(srv, priceSvc)
	v1.RegisterTransactionServiceServer(srv, txSvc)
	v1.RegisterRiskServiceServer(srv, riskSvc)
	v1.RegisterNodeServiceServer(srv, nodeSvc)
	v1.RegisterTokenServiceServer(srv, tokenSvc)

	return srv
}
