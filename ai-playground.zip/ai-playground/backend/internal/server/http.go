package server

import (
	"github.com/go-kratos/kratos/v2/log"
	"github.com/go-kratos/kratos/v2/middleware/logging"
	"github.com/go-kratos/kratos/v2/middleware/recovery"
	"github.com/go-kratos/kratos/v2/transport/http"

	v1 "tronwallet/api/wallet/v1"
	"tronwallet/internal/conf"
	"tronwallet/internal/service"
)

// NewHTTPServer creates an HTTP server.
func NewHTTPServer(
	c *conf.Bootstrap,
	logger log.Logger,
	priceSvc *service.PriceService,
	txSvc *service.TransactionService,
	riskSvc *service.RiskService,
	nodeSvc *service.NodeService,
	tokenSvc *service.TokenService,
) *http.Server {
	opts := []http.ServerOption{
		http.Middleware(
			recovery.Recovery(),
			logging.Server(logger),
		),
	}

	if c.Server.HTTP.Addr != "" {
		opts = append(opts, http.Address(c.Server.HTTP.Addr))
	}
	if c.Server.HTTP.Timeout > 0 {
		opts = append(opts, http.Timeout(c.Server.HTTP.Timeout))
	}

	srv := http.NewServer(opts...)

	v1.RegisterPriceServiceHTTPServer(srv, priceSvc)
	v1.RegisterTransactionServiceHTTPServer(srv, txSvc)
	v1.RegisterRiskServiceHTTPServer(srv, riskSvc)
	v1.RegisterNodeServiceHTTPServer(srv, nodeSvc)
	v1.RegisterTokenServiceHTTPServer(srv, tokenSvc)

	return srv
}
