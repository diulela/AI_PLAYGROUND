package service

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"

	v1 "tronwallet/api/wallet/v1"
)

// NodeService implements the NodeService gRPC/HTTP interface.
type NodeService struct {
	v1.UnimplementedNodeServiceServer

	log *log.Helper
}

func NewNodeService(logger log.Logger) *NodeService {
	return &NodeService{
		log: log.NewHelper(logger),
	}
}

func (s *NodeService) ListNodes(ctx context.Context, req *v1.ListNodesRequest) (*v1.ListNodesResponse, error) {
	// TODO: implement node health monitoring
	nodes := []*v1.NodeInfo{
		{
			Name:      "TronGrid Mainnet",
			Url:       "https://api.trongrid.io",
			Network:   "mainnet",
			LatencyMs: -1,
			IsHealthy: true,
		},
		{
			Name:      "Shasta Testnet",
			Url:       "https://api.shasta.trongrid.io",
			Network:   "shasta",
			LatencyMs: -1,
			IsHealthy: true,
		},
		{
			Name:      "Nile Testnet",
			Url:       "https://nile.trongrid.io",
			Network:   "nile",
			LatencyMs: -1,
			IsHealthy: true,
		},
	}
	return &v1.ListNodesResponse{Nodes: nodes}, nil
}
