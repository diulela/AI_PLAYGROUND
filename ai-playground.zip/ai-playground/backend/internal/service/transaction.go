package service

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"

	v1 "tronwallet/api/wallet/v1"
)

// TransactionService implements the TransactionService gRPC/HTTP interface.
type TransactionService struct {
	v1.UnimplementedTransactionServiceServer

	log *log.Helper
}

func NewTransactionService(logger log.Logger) *TransactionService {
	return &TransactionService{
		log: log.NewHelper(logger),
	}
}

func (s *TransactionService) ListTransactions(ctx context.Context, req *v1.ListTransactionsRequest) (*v1.ListTransactionsResponse, error) {
	// TODO: implement via TronGrid API proxy
	return &v1.ListTransactionsResponse{
		Transactions: []*v1.TransactionInfo{},
		Total:        0,
	}, nil
}

func (s *TransactionService) GetTransaction(ctx context.Context, req *v1.GetTransactionRequest) (*v1.GetTransactionResponse, error) {
	// TODO: implement via TronGrid API proxy
	return &v1.GetTransactionResponse{}, nil
}
