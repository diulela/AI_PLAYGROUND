package service

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"

	v1 "tronwallet/api/wallet/v1"
)

// TokenService implements the TokenService gRPC/HTTP interface.
type TokenService struct {
	v1.UnimplementedTokenServiceServer

	log *log.Helper
}

func NewTokenService(logger log.Logger) *TokenService {
	return &TokenService{
		log: log.NewHelper(logger),
	}
}

func (s *TokenService) ListTokens(ctx context.Context, req *v1.ListTokensRequest) (*v1.ListTokensResponse, error) {
	// TODO: implement via DB registry
	tokens := []*v1.TokenInfo{
		{
			Symbol:          "TRX",
			Name:            "TRON",
			ContractAddress: "",
			Decimals:        6,
			IsVerified:      true,
			TokenType:       "native",
		},
		{
			Symbol:          "USDT",
			Name:            "Tether USD",
			ContractAddress: "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t",
			Decimals:        6,
			IsVerified:      true,
			TokenType:       "trc20",
		},
	}
	return &v1.ListTokensResponse{Tokens: tokens}, nil
}

func (s *TokenService) GetTokenInfo(ctx context.Context, req *v1.GetTokenInfoRequest) (*v1.GetTokenInfoResponse, error) {
	// TODO: implement lookup by contract address
	return &v1.GetTokenInfoResponse{}, nil
}
