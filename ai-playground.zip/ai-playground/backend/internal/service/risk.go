package service

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"

	v1 "tronwallet/api/wallet/v1"
)

// RiskService implements the RiskService gRPC/HTTP interface.
type RiskService struct {
	v1.UnimplementedRiskServiceServer

	log *log.Helper
}

func NewRiskService(logger log.Logger) *RiskService {
	return &RiskService{
		log: log.NewHelper(logger),
	}
}

func (s *RiskService) CheckAddress(ctx context.Context, req *v1.CheckAddressRequest) (*v1.CheckAddressResponse, error) {
	// TODO: implement risk check against blacklist DB
	return &v1.CheckAddressResponse{
		Address:     req.Address,
		RiskLevel:   v1.RiskLevel_RISK_LEVEL_SAFE,
		Reason:      "",
		IsContract:  false,
		IsActivated: true,
	}, nil
}
