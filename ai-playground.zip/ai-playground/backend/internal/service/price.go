package service

import (
	"context"

	"github.com/go-kratos/kratos/v2/log"

	v1 "tronwallet/api/wallet/v1"
	"tronwallet/internal/biz"
)

// PriceService implements the PriceService gRPC/HTTP interface.
type PriceService struct {
	v1.UnimplementedPriceServiceServer

	uc  *biz.PriceUsecase
	log *log.Helper
}

func NewPriceService(uc *biz.PriceUsecase, logger log.Logger) *PriceService {
	return &PriceService{
		uc:  uc,
		log: log.NewHelper(logger),
	}
}

func (s *PriceService) GetTokenPrices(ctx context.Context, req *v1.GetTokenPricesRequest) (*v1.GetTokenPricesResponse, error) {
	prices, err := s.uc.GetPrices(ctx, req.Symbols)
	if err != nil {
		return nil, err
	}

	result := make([]*v1.TokenPrice, 0, len(prices))
	for _, p := range prices {
		result = append(result, &v1.TokenPrice{
			Symbol:    p.Symbol,
			Name:      p.Name,
			PriceUsd:  p.PriceUSD,
			Change_24H: p.Change24h,
			UpdatedAt: p.UpdatedAt,
		})
	}

	return &v1.GetTokenPricesResponse{Prices: result}, nil
}
