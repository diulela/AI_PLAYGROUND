# TronWallet Backend

TRON 区块链 Web 钱包后端服务 — 基于 Go Kratos v2 微服务框架。

## 技术栈

| 类别 | 技术 |
|------|------|
| 语言 | Go 1.25 |
| 框架 | Kratos v2（同时暴露 HTTP + gRPC） |
| 数据库 | MySQL 8.0（Ent ORM，待集成） |
| 缓存 | Redis 7（go-redis v9） |
| API 契约 | Protobuf（buf 工具链生成 Go server stub） |
| 依赖注入 | Google Wire |
| 配置管理 | Kratos config + YAML |

## 目录结构

```
backend/
├── api/                          # Protobuf 生成的 Go 代码（自动生成，勿手改）
│   └── wallet/v1/
│       ├── price.pb.go           # 消息类型
│       ├── price_grpc.pb.go      # gRPC server/client 接口
│       ├── price_http.pb.go      # HTTP handler 注册
│       ├── transaction*.pb.go
│       ├── risk*.pb.go
│       ├── node*.pb.go
│       └── token*.pb.go
├── cmd/
│   └── server/
│       ├── main.go               # 应用入口（Kratos bootstrap）
│       ├── wire.go               # Wire 依赖注入声明
│       └── wire_gen.go           # Wire 自动生成（勿手改）
├── configs/
│   └── config.yaml               # 运行时配置（服务端口/数据库/Redis/价格源）
├── internal/                     # 业务核心（Kratos 四层架构）
│   ├── conf/
│   │   └── conf.go               # 配置结构体定义
│   ├── server/
│   │   ├── http.go               # HTTP 服务注册（:8000）
│   │   └── grpc.go               # gRPC 服务注册（:9000）
│   ├── service/                  # 表现层 — 实现 Protobuf service 接口
│   │   ├── price.go              # PriceService 实现
│   │   ├── transaction.go        # TransactionService 实现
│   │   ├── risk.go               # RiskService 实现
│   │   ├── node.go               # NodeService 实现
│   │   └── token.go              # TokenService 实现
│   ├── biz/                      # 业务逻辑层
│   │   └── price.go              # 价格聚合业务（示例）
│   └── data/                     # 数据访问层
│       ├── data.go               # Redis 客户端初始化
│       └── price.go              # 价格数据仓储实现
├── Dockerfile                    # 多阶段构建镜像
├── Makefile                      # 本地开发命令
└── go.mod / go.sum               # Go 模块依赖
```

### Kratos 四层架构

```
API (proto) → Service (表现层) → Biz (业务逻辑) → Data (数据访问)
```

- **Service**: 实现 protobuf 定义的 RPC 接口，负责请求/响应的 DTO 转换
- **Biz**: 纯业务逻辑 + Repository 接口定义（依赖倒置）
- **Data**: Repository 接口的具体实现（MySQL、Redis、外部 API 调用）

## 服务列表

| Service | 职责 | 端点示例 |
|---------|------|---------|
| PriceService | 聚合 TRX/TRC-20 实时价格 | `GET /v1/prices` |
| TransactionService | 交易历史查询、广播 | `GET /v1/transactions` |
| RiskService | 风险地址检测 | `POST /v1/risk/check` |
| NodeService | TRON 节点状态查询 | `GET /v1/node/info` |
| TokenService | 通证列表、余额、搜索 | `GET /v1/tokens` |

## 快速开始

### 前置条件

- Go 1.25+
- MySQL 8.0 + Redis 7（通过 Docker Compose 一键启动）
- Wire CLI：`go install github.com/google/wire/cmd/wire@latest`

### 启动基础设施

```bash
# 从项目根目录
docker compose up -d mysql redis
```

### 运行开发服务器

```bash
# 方式一：使用 Makefile
make run

# 方式二：直接运行
go run ./cmd/server/ -conf ./configs

# 方式三：从项目根目录
cd .. && make be-dev
```

服务启动后：
- HTTP: `http://localhost:8000`
- gRPC: `localhost:9000`

### 常用命令

```bash
make build      # 编译二进制到 bin/server
make test       # 运行所有测试
make lint       # golangci-lint 代码检查
make wire       # 重新生成 Wire 依赖注入
make clean      # 清理构建产物
```

## API 代码生成

后端 API 代码由 Protobuf 定义自动生成，源文件位于 `../proto/wallet/v1/*.proto`。

```bash
# 从项目根目录执行
cd .. && make proto
```

生成的文件位于 `api/wallet/v1/`，包含：
- `*.pb.go` — 消息类型
- `*_grpc.pb.go` — gRPC 服务接口
- `*_http.pb.go` — HTTP handler（Kratos 风格）

**不要手动修改生成的文件**，修改 API 请编辑 `proto/` 下的 `.proto` 文件后重新生成。

## 配置说明

`configs/config.yaml` 主要配置项：

```yaml
server:
  http:
    addr: 0.0.0.0:8000     # HTTP 监听地址
    timeout: 10s
  grpc:
    addr: 0.0.0.0:9000     # gRPC 监听地址
    timeout: 10s

data:
  database:
    driver: mysql
    source: wallet:wallet123@tcp(127.0.0.1:3306)/tronwallet?...
  redis:
    addr: 127.0.0.1:6379

price:
  refresh_interval: 30s    # 价格轮询间隔
  sources:
    - coingecko             # 价格数据源
```

生产环境应通过环境变量覆盖敏感配置（数据库密码、Redis 地址等）。

## Docker 构建

```bash
docker build -t tronwallet-backend .
docker run -p 8000:8000 -p 9000:9000 tronwallet-backend
```

## 后续开发计划

- [ ] Ent ORM Schema 定义（钱包、交易、通证等实体）
- [ ] 数据库迁移机制
- [ ] TronGrid API 集成（交易历史同步）
- [ ] CoinGecko/CMC 价格聚合实现
- [ ] 风险地址黑名单数据源接入
- [ ] 认证中间件（JWT / API Key）
- [ ] 日志链路追踪（OpenTelemetry）
- [ ] 单元测试 & 集成测试
