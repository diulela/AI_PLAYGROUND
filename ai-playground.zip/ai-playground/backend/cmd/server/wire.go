//go:build wireinject
// +build wireinject

package main

import (
	"github.com/go-kratos/kratos/v2"
	"github.com/go-kratos/kratos/v2/log"
	"github.com/google/wire"

	"tronwallet/internal/biz"
	"tronwallet/internal/conf"
	"tronwallet/internal/data"
	"tronwallet/internal/server"
	"tronwallet/internal/service"
)

func wireApp(*conf.Bootstrap, log.Logger) (*kratos.App, func(), error) {
	panic(wire.Build(
		data.NewData,
		data.NewPriceRepo,
		biz.NewPriceUsecase,
		service.NewPriceService,
		service.NewTransactionService,
		service.NewRiskService,
		service.NewNodeService,
		service.NewTokenService,
		server.NewHTTPServer,
		server.NewGRPCServer,
		newApp,
	))
}
