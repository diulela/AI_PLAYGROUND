# TronWallet Frontend

TRON 区块链 Web 钱包前端应用 — 基于 React 19 SPA 架构。

## 技术栈

| 类别 | 技术 |
|------|------|
| UI 框架 | React 19 + TypeScript 5.9 |
| 构建工具 | Vite 7 |
| 组件库 | MUI 7（Material UI）|
| 样式 | Emotion + TailwindCSS 4（辅助） |
| 路由 | React Router 7 |
| 客户端状态 | Zustand 5 |
| 服务端状态 | TanStack Query 5 |
| 动画 | Framer Motion 12 |
| API 通信 | Connect-Web（Protobuf 生成的类型安全客户端） |
| 密码学 | @scure/bip39、@scure/bip32、Web Crypto API |
| 本地存储 | Dexie.js（IndexedDB） |
| 测试 | Vitest + Testing Library |

## 目录结构

```
src/
├── api/                      # Protobuf 生成的 TypeScript 客户端（自动生成，勿手改）
│   └── gen/
│       ├── wallet/v1/        # 5 个 service 的类型定义（price/transaction/risk/node/token）
│       └── google/api/       # googleapis shim
├── components/               # 共享 UI 组件
│   └── EntryCard.tsx         # 首页入口卡片
├── lib/
│   └── wallet-core/          # 钱包核心库（纯 TS，无 React 依赖）
│       ├── mnemonic.ts       # BIP39 助记词生成/验证
│       ├── hd.ts             # BIP44 HD 钱包派生（TRON 路径 m/44'/195'/...）
│       ├── crypto.ts         # AES-GCM 加密/解密（Web Crypto API）
│       ├── address.ts        # TRON 地址校验、格式化
│       ├── index.ts          # 统一导出
│       └── __tests__/        # 单元测试
├── pages/                    # 页面组件（对应 PRD 页面）
│   ├── HomePage.tsx          # 欢迎页（创建/导入钱包入口）
│   ├── AgreementPage.tsx     # 用户协议页
│   └── ImportWalletPage.tsx  # 导入钱包页
├── services/
│   └── api-client.ts         # Connect-Web transport 配置
├── stores/
│   └── wallet.ts             # Zustand 全局状态（钱包/网络/锁定）
├── theme.ts                  # MUI 主题（设计令牌：颜色/字体/间距/圆角）
├── App.tsx                   # 路由定义
├── main.tsx                  # 应用入口
└── index.css                 # 全局样式
```

## 快速开始

```bash
# 安装依赖
pnpm install

# 启动开发服务器（http://localhost:5173）
pnpm dev

# 类型检查
npx tsc --noEmit

# 运行测试
pnpm test

# 代码规范检查
pnpm lint

# 生产构建
pnpm build
```

## API 代码生成

前端通过 Protobuf 与后端通信，TypeScript 客户端代码由 `buf generate` 自动生成。

```bash
# 从项目根目录执行
cd .. && make proto
```

生成的文件位于 `src/api/gen/`，**不要手动修改**。修改 API 时应编辑 `proto/wallet/v1/*.proto`，然后重新生成。

## 设计规范

主题配置（`src/theme.ts`）严格对齐 PRD 设计规格：

| 令牌 | 值 | 用途 |
|------|-----|------|
| Primary | `#1A1A2E` | 主按钮背景、标题文字 |
| Accent | `#3B82F6` | 链接、选中态 |
| Success | `#22C55E` | 成功状态、对勾 |
| Text Primary | `#1A1A2E` | 主要文字 |
| Text Secondary | `#888888` | 次要文字、占位符 |
| Border | `#E5E5E5` | 分割线、输入框边框 |
| Background Gray | `#F5F5F5` | 卡片背景、输入框背景 |
| Disabled | `#CCCCCC` | 禁用按钮 |

## 安全原则

- **私钥永远不离开浏览器** — 所有密钥操作在 `lib/wallet-core/` 中客户端完成
- **AES-GCM 加密存储** — 私钥/助记词写入 IndexedDB 前经 PBKDF2(密码) 派生密钥加密
- **Web Crypto API** — 使用浏览器原生硬件加速加密，密钥不可被 JS 层直接访问
- **剪贴板自动清除** — 复制敏感内容后 60 秒自动清空

## PRD 页面对应关系

| 路由 | 页面组件 | PRD 设计规格 | 状态 |
|------|---------|-------------|------|
| `/` | HomePage | 02-欢迎页.md | 已实现 |
| `/agreement` | AgreementPage | 03-用户协议.md | 已实现 |
| `/import` | ImportWalletPage | — | 已实现 |
| `/create-wallet` | — | 04-创建HD钱包.md | 待开发 |
| `/backup/*` | — | 06~09-备份流程.md | 待开发 |
| `/wallet` | — | 10-钱包主页.md | 待开发 |
| `/transfer/*` | — | 12-转账流程/ | 待开发 |
| `/network` | — | 11-切换网络.md | 待开发 |
