/**
 * Shim for google.api.annotations.
 * These annotations are only used server-side for HTTP routing.
 * The TypeScript client does not need them.
 */
import { fileDesc } from "@bufbuild/protobuf/codegenv2";

export const file_google_api_annotations = /*@__PURE__*/
  fileDesc("Chxnb29nbGUvYXBpL2Fubm90YXRpb25zLnByb3RvEgpnb29nbGUuYXBpYgZwcm90bzM");
