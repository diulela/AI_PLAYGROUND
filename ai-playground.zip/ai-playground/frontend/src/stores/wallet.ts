import { create } from "zustand";
import { persist } from "zustand/middleware";
import db, { type WalletRecord } from "@/db";

// ── Types ───────────────────────────────────────────────────────

export interface WalletAccount {
  id: number;
  name: string;
  address: string;
  isBackedUp: boolean;
}

interface WalletState {
  /** Whether the wallet is unlocked */
  isUnlocked: boolean;
  /** Currently active wallet account */
  currentAccount: WalletAccount | null;
  /** All wallet accounts (loaded from Dexie on startup) */
  accounts: WalletAccount[];
  /** Current network: "mainnet" | "shasta" | "nile" */
  network: string;
  /** Version of the agreement accepted by the user, null = not accepted (REQ-006) */
  agreementAcceptedVersion: string | null;
  /** Whether Dexie data has been loaded into memory */
  isDbLoaded: boolean;
  /** Temporarily holds the decrypted mnemonic during backup flow (memory only, never persisted) */
  decryptedMnemonic: string | null;

  // ── Actions ─────────────────────────────────────────────────

  unlock: () => void;
  lock: () => void;
  setCurrentAccount: (account: WalletAccount) => void;
  setNetwork: (network: string) => void;
  /** Record agreement acceptance with version (REQ-006) */
  acceptAgreement: (version: string) => void;
  /** Reset agreement state (e.g. when agreement version changes) */
  resetAgreement: () => void;

  /** Load accounts from Dexie into memory. Call once on app start. */
  loadAccounts: () => Promise<void>;

  /**
   * Create a new wallet (REQ-007~011).
   * Writes the full record to Dexie and updates in-memory state.
   */
  createWallet: (params: {
    name: string;
    address: string;
    encryptedMnemonic: string;
    hasGasFree: boolean;
  }) => Promise<void>;

  /** Set or clear the decrypted mnemonic for backup flow (REQ-013~017) */
  setDecryptedMnemonic: (mnemonic: string | null) => void;

  /** Mark the current account as backed up in Dexie + refresh memory (REQ-020) */
  markBackedUp: () => Promise<void>;
}

// ── Helpers ─────────────────────────────────────────────────────

/** Map a Dexie WalletRecord to an in-memory WalletAccount. */
function toAccount(record: WalletRecord): WalletAccount {
  return {
    id: record.id!,
    name: record.name,
    address: record.address,
    isBackedUp: record.isBackedUp,
  };
}

// ── Store ───────────────────────────────────────────────────────

export const useWalletStore = create<WalletState>()(
  persist(
    (set, get) => ({
      isUnlocked: false,
      currentAccount: null,
      accounts: [],
      network: "mainnet",
      agreementAcceptedVersion: null,
      isDbLoaded: false,
      decryptedMnemonic: null,

      unlock: () => set({ isUnlocked: true }),
      lock: () => set({ isUnlocked: false }),
      setCurrentAccount: (account) => set({ currentAccount: account }),
      setNetwork: (network) => set({ network }),
      acceptAgreement: (version) =>
        set({ agreementAcceptedVersion: version }),
      resetAgreement: () => set({ agreementAcceptedVersion: null }),

      loadAccounts: async () => {
        const records = await db.wallets.toArray();
        const accounts = records.map(toAccount);
        set({
          accounts,
          currentAccount: accounts[0] ?? null,
          isDbLoaded: true,
        });
      },

      createWallet: async ({ name, address, encryptedMnemonic, hasGasFree }) => {
        const record: WalletRecord = {
          name,
          address,
          encryptedMnemonic,
          hasGasFree,
          isBackedUp: false,
          createdAt: Date.now(),
        };

        const id = await db.wallets.add(record);
        const account: WalletAccount = {
          id: id as number,
          name,
          address,
          isBackedUp: false,
        };

        set((state) => ({
          accounts: [...state.accounts, account],
          currentAccount: account,
          isUnlocked: true,
        }));
      },

      setDecryptedMnemonic: (mnemonic) =>
        set({ decryptedMnemonic: mnemonic }),

      markBackedUp: async () => {
        const { currentAccount } = get();
        if (!currentAccount) return;

        await db.wallets.update(currentAccount.id, { isBackedUp: true });

        const updated = { ...currentAccount, isBackedUp: true };
        set((state) => ({
          currentAccount: updated,
          accounts: state.accounts.map((a) =>
            a.id === updated.id ? updated : a,
          ),
        }));
      },
    }),
    {
      name: "tronwallet-store",
      // Only persist lightweight preferences to localStorage.
      // Sensitive data lives in Dexie (IndexedDB).
      partialize: (state) => ({
        network: state.network,
        agreementAcceptedVersion: state.agreementAcceptedVersion,
      }),
    },
  ),
);
