/**
 * Mnemonic generation and validation using BIP39.
 * Uses @scure/bip39 — audited, used by ethers.js v6 and MetaMask.
 */
import { generateMnemonic, validateMnemonic, mnemonicToSeedSync } from "@scure/bip39";
import { wordlist } from "@scure/bip39/wordlists/english.js";

/**
 * Generate a new BIP39 mnemonic phrase.
 * @param strength 128 for 12 words (default), 256 for 24 words
 */
export function createMnemonic(strength: 128 | 256 = 128): string {
  return generateMnemonic(wordlist, strength);
}

/**
 * Validate a mnemonic phrase.
 */
export function isValidMnemonic(mnemonic: string): boolean {
  return validateMnemonic(mnemonic, wordlist);
}

/**
 * Derive seed from mnemonic (synchronous).
 * The seed is used for HD key derivation.
 */
export function mnemonicToSeed(mnemonic: string, passphrase = ""): Uint8Array {
  return mnemonicToSeedSync(mnemonic, passphrase);
}

/**
 * Split mnemonic into word array (for display in grid).
 */
export function mnemonicToWords(mnemonic: string): string[] {
  return mnemonic.trim().split(/\s+/);
}

/**
 * Shuffle words for verification quiz.
 * Returns a new shuffled array (Fisher-Yates algorithm with crypto.getRandomValues).
 */
export function shuffleWords(words: string[]): string[] {
  const shuffled = [...words];
  const randomValues = new Uint32Array(shuffled.length);
  crypto.getRandomValues(randomValues);

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = randomValues[i]! % (i + 1);
    [shuffled[i], shuffled[j]] = [shuffled[j]!, shuffled[i]!];
  }
  return shuffled;
}
