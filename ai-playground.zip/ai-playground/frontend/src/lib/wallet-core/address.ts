/**
 * TRON address utilities.
 *
 * TRON addresses are Base58Check-encoded, starting with 'T', 34 characters long.
 * Format: 0x41 + keccak256(pubkey)[12:32] → Base58Check
 */
import { secp256k1 } from "@noble/curves/secp256k1.js";
import { keccak_256 } from "@noble/hashes/sha3.js";
import { sha256 } from "@noble/hashes/sha2.js";
import { base58 } from "@scure/base";
import { derivePublicKey } from "./hd";

// ── Address derivation ──────────────────────────────────────────

/**
 * Derive a TRON address from a 33-byte compressed public key.
 *
 * Steps:
 *   1. Decompress to 65-byte uncompressed key (04 || x || y)
 *   2. keccak256(uncompressed[1:])  — hash the 64-byte x||y
 *   3. Take last 20 bytes of hash
 *   4. Prepend TRON address prefix 0x41
 *   5. Base58Check encode (double SHA-256 checksum)
 */
export function publicKeyToTronAddress(
  compressedPubKey: Uint8Array,
): string {
  // 1. Decompress: 33 bytes → 65 bytes (with 0x04 prefix)
  const hex = Array.from(compressedPubKey)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  const uncompressed = secp256k1.Point.fromHex(hex)
    .toBytes(false); // false = uncompressed

  // 2. Keccak-256 of the 64-byte body (skip the 0x04 prefix)
  const hash = keccak_256(uncompressed.slice(1));

  // 3. Take last 20 bytes → raw address
  const rawAddress = hash.slice(12);

  // 4. Prepend TRON mainnet prefix 0x41
  const addressBytes = new Uint8Array(21);
  addressBytes[0] = 0x41;
  addressBytes.set(rawAddress, 1);

  // 5. Base58Check: double SHA-256 checksum (first 4 bytes)
  const checksum1 = sha256(addressBytes);
  const checksum2 = sha256(checksum1);
  const checkBytes = checksum2.slice(0, 4);

  const fullAddress = new Uint8Array(25);
  fullAddress.set(addressBytes, 0);
  fullAddress.set(checkBytes, 21);

  return base58.encode(fullAddress);
}

/**
 * Derive a TRON address directly from a mnemonic phrase.
 *
 * Combines HD key derivation + address encoding in one call.
 * Uses default derivation path: m/44'/195'/0'/0/0
 */
export function deriveAddress(
  mnemonic: string,
  account = 0,
  addressIndex = 0,
): string {
  const publicKey = derivePublicKey(mnemonic, account, addressIndex);
  return publicKeyToTronAddress(publicKey);
}

// ── Validation & formatting ─────────────────────────────────────

/**
 * Validate a TRON address format.
 * Checks: starts with T, length 34, valid Base58 characters.
 */
export function isValidTronAddress(address: string): boolean {
  if (!address || address.length !== 34) return false;
  if (!address.startsWith("T")) return false;

  // Base58 character set (no 0, O, I, l)
  const base58Regex = /^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$/;
  return base58Regex.test(address);
}

/**
 * Truncate a TRON address for display.
 * Example: "TMNY8sBLj6FDKmKT4GNi2sss5AtjrJrGsA" → "TMNY8s...JrGsA"
 */
export function truncateAddress(
  address: string,
  prefixLen = 6,
  suffixLen = 5,
): string {
  if (address.length <= prefixLen + suffixLen + 3) return address;
  return `${address.slice(0, prefixLen)}...${address.slice(-suffixLen)}`;
}

/**
 * Format a token amount with specified decimals.
 * Example: formatAmount("1987000000", 6) → "1,987"
 */
export function formatAmount(
  rawAmount: string,
  decimals: number,
  displayDecimals = 2,
): string {
  const num = Number(rawAmount) / Math.pow(10, decimals);
  return num.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: displayDecimals,
  });
}
