import { describe, it, expect } from "vitest";
import { isValidTronAddress, truncateAddress, formatAmount } from "../address";

describe("address", () => {
  it("should validate a correct TRON address", () => {
    expect(isValidTronAddress("TMNY8sBLj6FDKmKT4GNi2sss5AtjrJrGsA")).toBe(true);
    expect(isValidTronAddress("TVF2Mp9QY7FEGTnr3DBpFLobA6jguHyMvi")).toBe(true);
  });

  it("should reject invalid addresses", () => {
    expect(isValidTronAddress("")).toBe(false);
    expect(isValidTronAddress("not-an-address")).toBe(false);
    expect(isValidTronAddress("0x1234567890abcdef1234567890abcdef12345678")).toBe(false);
    // Wrong prefix
    expect(isValidTronAddress("AMNY8sBLj6FDKmKT4GNi2sss5AtjrJrGsA")).toBe(false);
  });

  it("should truncate address correctly", () => {
    const addr = "TMNY8sBLj6FDKmKT4GNi2sss5AtjrJrGsA";
    expect(truncateAddress(addr)).toBe("TMNY8s...JrGsA");
  });

  it("should format token amounts", () => {
    expect(formatAmount("1987000000", 6)).toBe("1,987");
    expect(formatAmount("12000000", 6)).toBe("12");
    expect(formatAmount("274000", 6, 3)).toBe("0.274");
  });
});
