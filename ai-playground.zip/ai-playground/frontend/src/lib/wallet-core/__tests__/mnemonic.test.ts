import { describe, it, expect } from "vitest";
import {
  createMnemonic,
  isValidMnemonic,
  mnemonicToWords,
  shuffleWords,
} from "../mnemonic";

describe("mnemonic", () => {
  it("should generate a 12-word mnemonic by default", () => {
    const mnemonic = createMnemonic();
    const words = mnemonicToWords(mnemonic);
    expect(words).toHaveLength(12);
  });

  it("should generate a 24-word mnemonic with strength 256", () => {
    const mnemonic = createMnemonic(256);
    const words = mnemonicToWords(mnemonic);
    expect(words).toHaveLength(24);
  });

  it("should validate a correct mnemonic", () => {
    const mnemonic = createMnemonic();
    expect(isValidMnemonic(mnemonic)).toBe(true);
  });

  it("should reject an invalid mnemonic", () => {
    expect(isValidMnemonic("invalid mnemonic phrase")).toBe(false);
  });

  it("should shuffle words without losing any", () => {
    const words = ["apple", "banana", "cherry", "date", "elderberry"];
    const shuffled = shuffleWords(words);
    expect(shuffled).toHaveLength(words.length);
    expect(shuffled.sort()).toEqual([...words].sort());
  });
});
