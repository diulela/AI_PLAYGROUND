/**
 * Encryption/decryption utilities using Web Crypto API.
 *
 * Uses AES-GCM for authenticated encryption and PBKDF2 for password-based
 * key derivation. The Web Crypto API provides hardware-accelerated crypto
 * and keeps keys in a secure memory area not accessible to JS.
 */

const PBKDF2_ITERATIONS = 600_000; // OWASP 2023 recommendation
const SALT_LENGTH = 16; // 128 bits
const IV_LENGTH = 12; // 96 bits for AES-GCM
const KEY_LENGTH = 256; // AES-256

/**
 * Derive an AES key from a user password using PBKDF2.
 */
async function deriveKey(
  password: string,
  salt: Uint8Array,
): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"],
  );

  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt as unknown as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: "SHA-256",
    },
    keyMaterial,
    { name: "AES-GCM", length: KEY_LENGTH },
    false,
    ["encrypt", "decrypt"],
  );
}

/**
 * Encrypt data with a password.
 * Returns: salt (16) + iv (12) + ciphertext (variable)
 */
export async function encrypt(
  data: Uint8Array,
  password: string,
): Promise<Uint8Array> {
  const salt = crypto.getRandomValues(new Uint8Array(SALT_LENGTH));
  const iv = crypto.getRandomValues(new Uint8Array(IV_LENGTH));
  const key = await deriveKey(password, salt);

  const ciphertext = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as unknown as ArrayBuffer },
    key,
    data as unknown as ArrayBuffer,
  );

  // Concatenate: salt + iv + ciphertext
  const result = new Uint8Array(
    SALT_LENGTH + IV_LENGTH + ciphertext.byteLength,
  );
  result.set(salt, 0);
  result.set(iv, SALT_LENGTH);
  result.set(new Uint8Array(ciphertext), SALT_LENGTH + IV_LENGTH);

  return result;
}

/**
 * Decrypt data with a password.
 * Input format: salt (16) + iv (12) + ciphertext
 */
export async function decrypt(
  encrypted: Uint8Array,
  password: string,
): Promise<Uint8Array> {
  const salt = encrypted.slice(0, SALT_LENGTH);
  const iv = encrypted.slice(SALT_LENGTH, SALT_LENGTH + IV_LENGTH);
  const ciphertext = encrypted.slice(SALT_LENGTH + IV_LENGTH);

  const key = await deriveKey(password, salt);

  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    key,
    ciphertext,
  );

  return new Uint8Array(decrypted);
}

/**
 * Encrypt a string (e.g., mnemonic) with a password.
 * Returns base64-encoded encrypted data.
 */
export async function encryptString(
  plaintext: string,
  password: string,
): Promise<string> {
  const encoder = new TextEncoder();
  const encrypted = await encrypt(encoder.encode(plaintext), password);
  return btoa(String.fromCharCode(...encrypted));
}

/**
 * Decrypt a base64-encoded encrypted string.
 */
export async function decryptString(
  encryptedBase64: string,
  password: string,
): Promise<string> {
  const encrypted = Uint8Array.from(atob(encryptedBase64), (c) =>
    c.charCodeAt(0),
  );
  const decrypted = await decrypt(encrypted, password);
  return new TextDecoder().decode(decrypted);
}
