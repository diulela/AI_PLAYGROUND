/**
 * wallet-core — TRON wallet cryptographic operations.
 *
 * This module handles all sensitive operations client-side:
 * - HD wallet derivation (BIP39/BIP44)
 * - AES-GCM encryption for secure storage
 * - TRON address utilities
 *
 * IMPORTANT: Private keys and mnemonics NEVER leave the browser.
 */

export {
  createMnemonic,
  isValidMnemonic,
  mnemonicToSeed,
  mnemonicToWords,
  shuffleWords,
} from "./mnemonic";

export {
  getTronDerivationPath,
  derivePrivateKey,
  derivePublicKey,
} from "./hd";

export {
  encrypt,
  decrypt,
  encryptString,
  decryptString,
} from "./crypto";

export {
  isValidTronAddress,
  truncateAddress,
  formatAmount,
} from "./address";
