/**
 * HD wallet derivation using BIP32/BIP44.
 *
 * TRON derivation path: m/44'/195'/0'/0/0
 * - 44'  = BIP44 purpose
 * - 195' = TRON coin type (registered in SLIP-0044)
 * - 0'   = account index
 * - 0    = external chain
 * - 0    = address index
 */
import { HDKey } from "@scure/bip32";
import { mnemonicToSeed } from "./mnemonic";

/** TRON coin type per SLIP-0044 */
const TRON_COIN_TYPE = 195;

/**
 * Derive the TRON BIP44 path for a given account and address index.
 */
export function getTronDerivationPath(
  account = 0,
  addressIndex = 0,
): string {
  return `m/44'/${TRON_COIN_TYPE}'/${account}'/0/${addressIndex}`;
}

/**
 * Derive a TRON private key from mnemonic.
 * Returns the raw 32-byte private key.
 */
export function derivePrivateKey(
  mnemonic: string,
  account = 0,
  addressIndex = 0,
): Uint8Array {
  const seed = mnemonicToSeed(mnemonic);
  const master = HDKey.fromMasterSeed(seed);
  const path = getTronDerivationPath(account, addressIndex);
  const child = master.derive(path);

  if (!child.privateKey) {
    throw new Error("Failed to derive private key");
  }

  return child.privateKey;
}

/**
 * Derive the public key from mnemonic.
 * Returns the raw 33-byte compressed public key.
 */
export function derivePublicKey(
  mnemonic: string,
  account = 0,
  addressIndex = 0,
): Uint8Array {
  const seed = mnemonicToSeed(mnemonic);
  const master = HDKey.fromMasterSeed(seed);
  const path = getTronDerivationPath(account, addressIndex);
  const child = master.derive(path);

  if (!child.publicKey) {
    throw new Error("Failed to derive public key");
  }

  return child.publicKey;
}
