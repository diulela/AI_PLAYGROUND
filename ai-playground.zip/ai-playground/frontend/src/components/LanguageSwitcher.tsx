import { useState } from "react";
import { useTranslation } from "react-i18next";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";

const LANGUAGES = [
  { code: "zh", label: "中文" },
  { code: "en", label: "English" },
] as const;

/**
 * Language switcher dropdown — design spec 3.1.
 *
 * Displays current language name + "▼" arrow.
 * Click opens a menu with available languages.
 * Selection persists to localStorage via i18next-browser-languagedetector.
 */
export default function LanguageSwitcher() {
  const { i18n } = useTranslation();
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const currentLang =
    LANGUAGES.find((l) => l.code === i18n.language) ?? LANGUAGES[0];

  const handleClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleSelect = (code: string) => {
    i18n.changeLanguage(code);
    handleClose();
  };

  return (
    <>
      <Button
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon sx={{ fontSize: "16px !important" }} />}
        sx={{
          color: "text.primary",
          fontSize: 14,
          fontWeight: 400,
          textTransform: "none",
          minHeight: 36,
          px: 1.5,
          borderRadius: 2,
          border: 1,
          borderColor: "divider",
          "&:active": {
            transform: "scale(0.97)",
          },
        }}
      >
        {currentLang.label}
      </Button>
      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        transformOrigin={{ vertical: "top", horizontal: "right" }}
        slotProps={{
          paper: {
            sx: {
              mt: 0.5,
              minWidth: 120,
              borderRadius: 2,
              boxShadow: "0 4px 16px rgba(0,0,0,0.08)",
            },
          },
        }}
      >
        {LANGUAGES.map((lang) => (
          <MenuItem
            key={lang.code}
            selected={lang.code === i18n.language}
            onClick={() => handleSelect(lang.code)}
            sx={{ fontSize: 14 }}
          >
            {lang.label}
          </MenuItem>
        ))}
      </Menu>
    </>
  );
}
