import { useState, useRef, useEffect } from "react";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputAdornment from "@mui/material/InputAdornment";
import Button from "@mui/material/Button";
import FormHelperText from "@mui/material/FormHelperText";
import CloseIcon from "@mui/icons-material/Close";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import CircularProgress from "@mui/material/CircularProgress";
import db from "@/db";
import { decryptString } from "@/lib/wallet-core";
import { useWalletStore } from "@/stores/wallet";

interface PasswordVerifySheetProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

/**
 * Identity Verification Bottom Sheet (REQ-013).
 *
 * Prompts for the wallet password, decrypts the mnemonic, and stores
 * it in Zustand memory (never persisted) for the backup flow.
 */
export default function PasswordVerifySheet({
  open,
  onClose,
  onSuccess,
}: PasswordVerifySheetProps) {
  const { t } = useTranslation();
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const currentAccount = useWalletStore((s) => s.currentAccount);
  const setDecryptedMnemonic = useWalletStore((s) => s.setDecryptedMnemonic);

  // Reset state when sheet opens
  useEffect(() => {
    if (open) {
      setPassword("");
      setShowPassword(false);
      setError("");
      setLoading(false);
      // Auto-focus the input after drawer animation
      setTimeout(() => inputRef.current?.focus(), 350);
    }
  }, [open]);

  const handleVerify = async () => {
    if (!password || !currentAccount) return;

    setLoading(true);
    setError("");

    try {
      const record = await db.wallets.get(currentAccount.id);
      if (!record) throw new Error("Wallet not found");

      const mnemonic = await decryptString(
        record.encryptedMnemonic,
        password,
      );

      // Store decrypted mnemonic in memory only
      setDecryptedMnemonic(mnemonic);
      onSuccess();
    } catch {
      setError(t("backup.verifyError"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Drawer
      anchor="bottom"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          maxWidth: 430,
          mx: "auto",
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
        },
      }}
      slotProps={{
        backdrop: { sx: { bgcolor: "rgba(0,0,0,0.5)" } },
      }}
    >
      {/* ── Title row ── */}
      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "relative",
          pt: 2.5,
          px: 2.5,
          pb: 2,
        }}
      >
        <Typography variant="h3" sx={{ fontWeight: 600, fontSize: "1rem" }}>
          {t("backup.verifyTitle")}
        </Typography>
        <IconButton
          onClick={onClose}
          sx={{
            position: "absolute",
            right: 12,
            color: "#999999",
          }}
          aria-label="close"
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </Box>

      {/* ── Divider ── */}
      <Box sx={{ borderBottom: "1px solid #EEEEEE" }} />

      {/* ── Content ── */}
      <Box sx={{ px: 2.5, pt: 3, pb: 2 }}>
        <OutlinedInput
          inputRef={inputRef}
          fullWidth
          type={showPassword ? "text" : "password"}
          placeholder={t("backup.verifyPlaceholder")}
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
            if (error) setError("");
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && password) handleVerify();
          }}
          error={!!error}
          endAdornment={
            <InputAdornment position="end">
              <IconButton
                onClick={() => setShowPassword((v) => !v)}
                edge="end"
                size="small"
              >
                {showPassword ? (
                  <VisibilityIcon fontSize="small" />
                ) : (
                  <VisibilityOffIcon fontSize="small" />
                )}
              </IconButton>
            </InputAdornment>
          }
          sx={{ borderRadius: 1 }}
        />
        {error && (
          <FormHelperText error sx={{ mt: 0.5 }}>
            {error}
          </FormHelperText>
        )}
      </Box>

      {/* ── Verify button ── */}
      <Box sx={{ px: 2.5, pb: 4.25 }}>
        <Button
          variant="contained"
          fullWidth
          disabled={!password || loading}
          onClick={handleVerify}
          sx={{ minHeight: 48 }}
        >
          {loading ? (
            <CircularProgress size={22} color="inherit" />
          ) : (
            t("backup.verifyButton")
          )}
        </Button>
      </Box>
    </Drawer>
  );
}
