import type { ReactNode } from "react";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import Avatar from "@mui/material/Avatar";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";

interface EntryCardProps {
  /** Icon element rendered inside a colored circle */
  icon: ReactNode;
  /** Primary text label */
  label: string;
  /** Click handler */
  onClick?: () => void;
}

/**
 * Entry Card — reusable list entry per design spec 4.5.
 *
 * Uses MUI ListItemButton with theme-managed tokens:
 * - Height: 56px (theme component override)
 * - Border-radius: 12px (theme component override)
 * - Spacing: 12px gap (theme component override)
 * - Tap target: 56px > 44px minimum (Apple HIG)
 */
export default function EntryCard({ icon, label, onClick }: EntryCardProps) {
  return (
    <ListItemButton
      onClick={onClick}
      sx={{
        border: 1,
        borderColor: "divider",
        bgcolor: "background.paper",
      }}
    >
      <ListItemIcon sx={{ minWidth: "auto" }}>
        <Avatar sx={{ bgcolor: "secondary.main", width: 36, height: 36 }}>
          {icon}
        </Avatar>
      </ListItemIcon>

      <ListItemText
        primary={label}
        primaryTypographyProps={{
          variant: "body1",
          fontWeight: 500,
          color: "text.primary",
        }}
      />

      <ChevronRightIcon sx={{ color: "text.disabled", fontSize: 22 }} />
    </ListItemButton>
  );
}
