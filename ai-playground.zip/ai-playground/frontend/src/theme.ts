import { createTheme } from "@mui/material/styles";

/**
 * TronWallet Design Token System
 *
 * Built on MUI's theme architecture, aligned with:
 * - PRD global design spec (00-全局设计规范.md)
 * - 8pt grid spacing system
 * - Apple HIG minimum tap target (44px)
 * - Material Design typography scale
 *
 * Spacing: MUI default factor = 8px
 *   theme.spacing(0.5) = 4px
 *   theme.spacing(1)   = 8px
 *   theme.spacing(1.5) = 12px
 *   theme.spacing(2)   = 16px
 *   theme.spacing(2.5) = 20px
 *   theme.spacing(3)   = 24px
 *   theme.spacing(4)   = 32px
 *   theme.spacing(5)   = 40px
 *   theme.spacing(6)   = 48px
 *   theme.spacing(8)   = 64px
 */

// ── Color Palette ──────────────────────────────────────────────
const palette = {
  primary: {
    main: "#1A1A2E", // 主色-深色: 主按钮背景、标题
    light: "#2D2D3F",
    dark: "#0F0F1A",
    contrastText: "#FFFFFF",
  },
  secondary: {
    main: "#3B82F6", // 主色-蓝色: 链接、图标背景、强调色
    light: "#60A5FA",
    dark: "#2563EB",
    contrastText: "#FFFFFF",
  },
  success: {
    main: "#22C55E", // 成功色
  },
  error: {
    main: "#EF4444", // 警告/错误色
  },
  text: {
    primary: "#1A1A2E", // 主要文字
    secondary: "#666666", // 次要文字
    disabled: "#CCCCCC", // 占位符/禁用
  },
  divider: "#E5E5E5", // 分割线
  background: {
    default: "#FFFFFF", // 页面背景
    paper: "#FFFFFF", // 卡片背景
  },
  grey: {
    50: "#F8F8F8",
    100: "#F5F5F5", // 输入框背景、浅灰背景
    200: "#EEEEEE",
    300: "#E5E5E5",
    400: "#CCCCCC",
    500: "#888888",
    600: "#666666",
    700: "#444444",
    800: "#2D2D3F",
    900: "#1A1A2E",
  },
  action: {
    hover: "rgba(0, 0, 0, 0.04)",
    selected: "rgba(0, 0, 0, 0.06)",
    active: "rgba(0, 0, 0, 0.08)",
  },
};

// ── Typography ─────────────────────────────────────────────────
const fontFamily = [
  "-apple-system",
  "BlinkMacSystemFont",
  '"SF Pro Display"',
  '"Segoe UI"',
  "Roboto",
  '"Helvetica Neue"',
  "Arial",
  "sans-serif",
].join(",");

// ── Theme ──────────────────────────────────────────────────────
const theme = createTheme({
  // spacing: 8px base (MUI default) => theme.spacing(1) = 8px
  spacing: 8,

  palette,

  typography: {
    fontFamily,
    // H1: 欢迎页主标题 — 26px Bold
    h1: {
      fontSize: "1.625rem", // 26px
      fontWeight: 700,
      lineHeight: 1.3,
      letterSpacing: "-0.01em",
    },
    // H2: 页面标题 — 20px Bold
    h2: {
      fontSize: "1.25rem", // 20px
      fontWeight: 700,
      lineHeight: 1.4,
    },
    // H3: 弹窗标题 — 17px SemiBold
    h3: {
      fontSize: "1.0625rem", // 17px
      fontWeight: 600,
      lineHeight: 1.4,
    },
    // Body1: 正文、卡片标签 — 15px Regular
    body1: {
      fontSize: "0.9375rem", // 15px
      fontWeight: 400,
      lineHeight: 1.6,
    },
    // Body2: 辅助说明 — 14px Regular
    body2: {
      fontSize: "0.875rem", // 14px
      fontWeight: 400,
      lineHeight: 1.5,
    },
    // Caption: 小字注释 — 12px Regular
    caption: {
      fontSize: "0.75rem", // 12px
      fontWeight: 400,
      lineHeight: 1.5,
    },
    // Button: 按钮文字 — 16px SemiBold
    button: {
      fontSize: "1rem", // 16px
      fontWeight: 600,
      lineHeight: 1.5,
      textTransform: "none", // 不自动大写
    },
  },

  shape: {
    borderRadius: 12, // 默认圆角 12px（列表卡片）
  },

  components: {
    // ── Global ──
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          WebkitFontSmoothing: "antialiased",
          MozOsxFontSmoothing: "grayscale",
        },
        "#root": {
          maxWidth: 430,
          margin: "0 auto",
          minHeight: "100dvh",
          position: "relative",
          overflowX: "hidden",
          backgroundColor: "#FFFFFF",
        },
      },
    },

    // ── Button ──
    MuiButton: {
      defaultProps: {
        disableElevation: true,
      },
      styleOverrides: {
        root: {
          borderRadius: 24, // 胶囊形按钮
          minHeight: 48, // 按钮高度 48px
          padding: "12px 24px",
        },
        containedPrimary: {
          "&:active": {
            transform: "scale(0.98)",
          },
        },
      },
    },

    // ── ListItemButton (Entry Card) ──
    MuiListItemButton: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          minHeight: 56, // Entry Card 高度
          padding: "8px 16px", // spacing(1) spacing(2)
          gap: 12, // spacing(1.5) — 图标与文字间距
          "&:active": {
            transform: "scale(0.98)",
            transition: "transform 0.1s ease",
          },
        },
      },
    },

    // ── Avatar (图标容器) ──
    MuiAvatar: {
      styleOverrides: {
        root: {
          width: 36,
          height: 36,
        },
      },
    },

    // ── AppBar (导航栏) ──
    MuiAppBar: {
      defaultProps: {
        elevation: 0,
        color: "transparent",
      },
      styleOverrides: {
        root: {
          backgroundColor: "#FFFFFF",
          minHeight: 48,
        },
      },
    },

    // ── Toolbar ──
    MuiToolbar: {
      styleOverrides: {
        root: {
          minHeight: "48px !important",
          padding: "0 4px !important", // 紧凑内边距，按钮自带 touch target
        },
      },
    },

    // ── IconButton ──
    MuiIconButton: {
      styleOverrides: {
        root: {
          // Apple HIG: 最小可点击区域 44px
          minWidth: 44,
          minHeight: 44,
        },
      },
    },

    // ── Paper ──
    MuiPaper: {
      defaultProps: {
        elevation: 0,
      },
    },

    // ── List ──
    MuiList: {
      styleOverrides: {
        root: {
          padding: 0,
        },
      },
    },
  },
});

export default theme;
