import { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Link from "@mui/material/Link";
import CircularProgress from "@mui/material/CircularProgress";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import VisibilityIcon from "@mui/icons-material/Visibility";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import ClearIcon from "@mui/icons-material/Clear";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import FiberManualRecordIcon from "@mui/icons-material/FiberManualRecord";
import { useWalletStore } from "@/stores/wallet";
import { createMnemonic } from "@/lib/wallet-core/mnemonic";
import { encryptString } from "@/lib/wallet-core/crypto";
import { deriveAddress } from "@/lib/wallet-core/address";

// ── Password validation rules ───────────────────────────────────

interface PasswordRules {
  hasUppercase: boolean;
  hasLowercase: boolean;
  hasNumber: boolean;
  hasMinLength: boolean;
}

function validatePassword(password: string): PasswordRules {
  return {
    hasUppercase: /[A-Z]/.test(password),
    hasLowercase: /[a-z]/.test(password),
    hasNumber: /\d/.test(password),
    hasMinLength: password.length >= 8,
  };
}

function allRulesPassed(rules: PasswordRules): boolean {
  return (
    rules.hasUppercase &&
    rules.hasLowercase &&
    rules.hasNumber &&
    rules.hasMinLength
  );
}

// ── Rule indicator component ────────────────────────────────────

function RuleIndicator({
  label,
  passed,
}: {
  label: string;
  passed: boolean;
}) {
  return (
    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
      {passed ? (
        <CheckCircleIcon sx={{ fontSize: 14, color: "secondary.main" }} />
      ) : (
        <FiberManualRecordIcon sx={{ fontSize: 8, color: "text.disabled" }} />
      )}
      <Typography
        variant="caption"
        sx={{
          color: passed ? "text.primary" : "text.disabled",
          fontWeight: passed ? 500 : 400,
        }}
      >
        {label}
      </Typography>
    </Box>
  );
}

// ── Shared input styles ─────────────────────────────────────────

const inputSx = {
  "& .MuiOutlinedInput-root": {
    borderRadius: 2,
    bgcolor: "grey.100",
    "& fieldset": { border: "none" },
    "&.Mui-focused fieldset": {
      border: "1.5px solid",
      borderColor: "secondary.main",
    },
    "&.Mui-error fieldset": {
      border: "1.5px solid",
      borderColor: "error.main",
    },
  },
};

// ── GasFree external URL ────────────────────────────────────────
const GASFREE_URL = "https://www.tronlink.org/gasfree";

// ── Page component ──────────────────────────────────────────────

/**
 * Create HD Wallet page — REQ-007, REQ-009, REQ-011.
 *
 * Layout (per design spec 04-创建HD钱包.md):
 *   [NavBar]           — back arrow | "创建 HD 钱包"
 *   [HintArea]         — two bullet-point hints
 *   [AccountNameField] — label + input with clear button
 *   [PasswordArea]     — hint text + password input + 4-rule indicators + confirm input
 *   [GasFreeCheckbox]  — checkbox + link
 *   [CreateButton]     — fixed bottom, conditional enable
 */
export default function CreateWalletPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const createWallet = useWalletStore((s) => s.createWallet);

  // ── Form state ──────────────────────────────────────────────
  const [accountName, setAccountName] = useState(
    t("createWallet.accountDefault"),
  );
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [gasFree, setGasFree] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const [confirmTouched, setConfirmTouched] = useState(false);

  // ── Derived validation ──────────────────────────────────────
  const rules = useMemo(() => validatePassword(password), [password]);
  const passwordsMatch = password === confirmPassword;
  const showMismatchError = confirmTouched && confirmPassword.length > 0 && !passwordsMatch;

  const canCreate =
    accountName.trim().length > 0 &&
    allRulesPassed(rules) &&
    passwordsMatch &&
    confirmPassword.length > 0;

  // ── Create handler ──────────────────────────────────────────
  const handleCreate = async () => {
    if (!canCreate || isCreating) return;

    setIsCreating(true);
    try {
      // 1. Generate mnemonic (12 words)
      const mnemonic = createMnemonic();

      // 2. Encrypt mnemonic with user password (AES-256-GCM + PBKDF2)
      const encryptedMnemonic = await encryptString(mnemonic, password);

      // 3. Derive TRON address from mnemonic
      const address = deriveAddress(mnemonic);

      // 4. Save to Dexie + Zustand
      await createWallet({
        name: accountName.trim(),
        address,
        encryptedMnemonic,
        hasGasFree: gasFree,
      });

      // 5. Navigate to success page (replace — no going back)
      navigate("/creation-success", { replace: true });
    } catch (error) {
      console.error("Wallet creation failed:", error);
      toast.error(t("createWallet.createFailed"));
      setIsCreating(false);
    }
  };

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.25 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* ── NavBar ── */}
        <AppBar position="static">
          <Toolbar>
            <IconButton
              edge="start"
              aria-label={t("common.back")}
              onClick={() => navigate(-1)}
            >
              <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography variant="h2" component="h1" sx={{ ml: 0.5 }}>
              {t("createWallet.navTitle")}
            </Typography>
          </Toolbar>
        </AppBar>

        {/* ── Scrollable content ── */}
        <Box
          sx={{
            flex: 1,
            overflowY: "auto",
            px: 2.5,
            pt: 2,
            pb: "120px", // space for fixed bottom button
          }}
        >
          {/* ── Hints (design spec 3.2) ── */}
          <Box sx={{ mb: 3 }}>
            <Typography
              variant="body2"
              color="text.primary"
              sx={{ lineHeight: 1.6, mb: 0.5 }}
            >
              {"• "}
              {t("createWallet.hint1")}
            </Typography>
            <Typography
              variant="body2"
              color="text.primary"
              sx={{ lineHeight: 1.6 }}
            >
              {"• "}
              {t("createWallet.hint2")}
            </Typography>
          </Box>

          {/* ── Account Name (REQ-009, design spec 3.3~3.4) ── */}
          <Typography
            variant="body1"
            sx={{ fontWeight: 600, mb: 1 }}
          >
            {t("createWallet.accountLabel")}
          </Typography>
          <TextField
            fullWidth
            value={accountName}
            onChange={(e) => setAccountName(e.target.value.slice(0, 24))}
            slotProps={{
              input: {
                endAdornment: accountName ? (
                  <InputAdornment position="end">
                    <IconButton
                      size="small"
                      onClick={() => setAccountName("")}
                      edge="end"
                    >
                      <ClearIcon sx={{ fontSize: 18, color: "text.disabled" }} />
                    </IconButton>
                  </InputAdornment>
                ) : undefined,
              },
            }}
            sx={{ ...inputSx, mb: 3 }}
          />

          {/* ── Password Section (REQ-007, design spec 3.5~3.9) ── */}
          <Typography
            variant="body1"
            sx={{ fontWeight: 600, mb: 0.5 }}
          >
            {t("createWallet.passwordLabel")}
          </Typography>
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ display: "block", lineHeight: 1.6, mb: 1.5 }}
          >
            {t("createWallet.passwordHint")}
          </Typography>

          {/* Password input */}
          <TextField
            fullWidth
            type={showPassword ? "text" : "password"}
            placeholder={t("createWallet.passwordPlaceholder")}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      size="small"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                    >
                      {showPassword ? (
                        <VisibilityIcon sx={{ fontSize: 20, color: "text.secondary" }} />
                      ) : (
                        <VisibilityOffIcon sx={{ fontSize: 20, color: "text.disabled" }} />
                      )}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
            sx={{ ...inputSx, mb: 1 }}
          />

          {/* 4-rule indicators (design spec 3.8) */}
          <Box
            sx={{
              display: "flex",
              gap: 1.5,
              flexWrap: "wrap",
              mb: 2,
            }}
          >
            <RuleIndicator
              label={t("createWallet.ruleUppercase")}
              passed={rules.hasUppercase}
            />
            <RuleIndicator
              label={t("createWallet.ruleLowercase")}
              passed={rules.hasLowercase}
            />
            <RuleIndicator
              label={t("createWallet.ruleNumber")}
              passed={rules.hasNumber}
            />
            <RuleIndicator
              label={t("createWallet.ruleMinLength")}
              passed={rules.hasMinLength}
            />
          </Box>

          {/* Confirm password input (design spec 3.9) */}
          <TextField
            fullWidth
            type={showConfirmPassword ? "text" : "password"}
            placeholder={t("createWallet.confirmPlaceholder")}
            value={confirmPassword}
            onChange={(e) => {
              setConfirmPassword(e.target.value);
              if (!confirmTouched) setConfirmTouched(true);
            }}
            error={showMismatchError}
            helperText={
              showMismatchError ? t("createWallet.passwordMismatch") : " "
            }
            autoComplete="new-password"
            slotProps={{
              input: {
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      size="small"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                      edge="end"
                    >
                      {showConfirmPassword ? (
                        <VisibilityIcon sx={{ fontSize: 20, color: "text.secondary" }} />
                      ) : (
                        <VisibilityOffIcon sx={{ fontSize: 20, color: "text.disabled" }} />
                      )}
                    </IconButton>
                  </InputAdornment>
                ),
              },
            }}
            sx={{ ...inputSx, mb: 1 }}
          />

          {/* ── GasFree checkbox (REQ-011, design spec 3.10) ── */}
          <FormControlLabel
            control={
              <Checkbox
                checked={gasFree}
                onChange={(e) => setGasFree(e.target.checked)}
                sx={{
                  color: "text.disabled",
                  "&.Mui-checked": { color: "secondary.main" },
                }}
              />
            }
            label={
              <Typography variant="body2" color="text.primary">
                {t("createWallet.gasFreeLabel")}{" "}
                <Link
                  href={GASFREE_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  underline="always"
                  sx={{ color: "secondary.main" }}
                  onClick={(e) => e.stopPropagation()}
                >
                  {t("createWallet.gasFreeLink")}
                </Link>
              </Typography>
            }
            sx={{ alignItems: "flex-start", mx: 0 }}
          />
        </Box>

        {/* ── Fixed bottom — Create button (design spec 3.11) ── */}
        <Box
          sx={{
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            maxWidth: 430,
            mx: "auto",
            px: 2.5,
            pt: 1.5,
            pb: 4.25, // 34px safe area
            bgcolor: "background.default",
            borderTop: 1,
            borderColor: "divider",
          }}
        >
          <Button
            variant="contained"
            color="primary"
            fullWidth
            disabled={!canCreate || isCreating}
            onClick={handleCreate}
            sx={{ minHeight: 48 }}
          >
            {isCreating ? (
              <CircularProgress size={22} color="inherit" sx={{ mr: 1 }} />
            ) : null}
            {isCreating
              ? t("createWallet.creating")
              : t("createWallet.createButton")}
          </Button>
        </Box>
      </Box>
    </motion.div>
  );
}
