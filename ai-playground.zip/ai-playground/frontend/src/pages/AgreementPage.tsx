import { useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import { useWalletStore } from "@/stores/wallet";

/** Current agreement version — bump when terms change to re-prompt users (REQ-006) */
const CURRENT_AGREEMENT_VERSION = "1.0";

/** External URL for full agreement in browser */
const AGREEMENT_EXTERNAL_URL = "https://www.tronlink.org/terms";

/** Ordered section keys matching the i18n agreement.sections structure */
const SECTION_KEYS = [
  "s1",
  "s2",
  "s3",
  "s4",
  "s5",
  "s6",
  "s7",
  "s8",
  "s9",
  "s10",
] as const;

/**
 * User Agreement Page — REQ-005 + REQ-006.
 *
 * Layout (per design spec 03-用户协议.md):
 *   [NavBar]       — back arrow | "用户协议" | external link icon
 *   [ScrollArea]   — flex:1, scrollable agreement text
 *   [BottomBar]    — fixed bottom, "同意本条款，下次不再提示" button
 *
 * Skip logic (REQ-006):
 *   If agreementAcceptedVersion matches CURRENT_AGREEMENT_VERSION,
 *   auto-navigate to /create-wallet.
 */
export default function AgreementPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const agreementAcceptedVersion = useWalletStore(
    (s) => s.agreementAcceptedVersion,
  );
  const acceptAgreement = useWalletStore((s) => s.acceptAgreement);

  // REQ-006: skip if already accepted current version
  useEffect(() => {
    if (agreementAcceptedVersion === CURRENT_AGREEMENT_VERSION) {
      navigate("/create-wallet", { replace: true });
    }
  }, [agreementAcceptedVersion, navigate]);

  const handleAgree = () => {
    acceptAgreement(CURRENT_AGREEMENT_VERSION);
    navigate("/create-wallet");
  };

  const handleOpenExternal = () => {
    window.open(AGREEMENT_EXTERNAL_URL, "_blank", "noopener,noreferrer");
  };

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.25 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* ── NavBar — design spec 4.1 ── */}
        <AppBar position="static">
          <Toolbar>
            <IconButton
              edge="start"
              aria-label={t("common.back")}
              onClick={() => navigate(-1)}
            >
              <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography variant="h2" component="h1" sx={{ ml: 0.5, flex: 1 }}>
              {t("agreement.navTitle")}
            </Typography>
            {/* External link icon — open full agreement in new tab */}
            <IconButton
              edge="end"
              aria-label="open in browser"
              onClick={handleOpenExternal}
            >
              <OpenInNewIcon sx={{ fontSize: 20, color: "text.secondary" }} />
            </IconButton>
          </Toolbar>
        </AppBar>

        {/* ── Scrollable agreement content ── */}
        <Box
          sx={{
            flex: 1,
            overflowY: "auto",
            px: 2.5,
            pt: 2,
            pb: 2,
            /* Leave space for the fixed bottom button area */
            mb: "88px",
          }}
        >
          {/* Agreement title */}
          <Typography
            variant="h3"
            sx={{ mb: 0.5, textAlign: "center" }}
          >
            {t("agreement.title")}
          </Typography>
          <Typography
            variant="caption"
            color="text.secondary"
            sx={{ display: "block", textAlign: "center", mb: 3 }}
          >
            {t("agreement.lastUpdated")}
          </Typography>

          {/* Agreement sections */}
          {SECTION_KEYS.map((key) => (
            <Box key={key} sx={{ mb: 2.5 }}>
              <Typography
                variant="body1"
                sx={{ fontWeight: 600, mb: 1 }}
              >
                {t(`agreement.sections.${key}_title`)}
              </Typography>
              <Typography
                variant="body2"
                color="text.primary"
                sx={{
                  lineHeight: 1.75,
                  whiteSpace: "pre-line",
                }}
              >
                {t(`agreement.sections.${key}_body`)}
              </Typography>
            </Box>
          ))}
        </Box>

        {/* ── Fixed bottom bar — agree button ── */}
        <Box
          sx={{
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            maxWidth: 430,
            mx: "auto",
            px: 2.5,
            pt: 1.5,
            pb: 4.25, // 34px safe area
            bgcolor: "background.default",
            borderTop: 1,
            borderColor: "divider",
          }}
        >
          <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={handleAgree}
            sx={{ minHeight: 48 }}
          >
            {t("agreement.agreeButton")}
          </Button>
        </Box>
      </Box>
    </motion.div>
  );
}
