import { useTranslation } from "react-i18next";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";

/**
 * Wallet Home page — placeholder for REQ-025+.
 * Will be fully implemented with asset dashboard, token list, etc.
 */
export default function WalletHomePage() {
  const { t } = useTranslation();

  return (
    <Box
      sx={{
        minHeight: "100dvh",
        bgcolor: "background.default",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h2" component="h1">
            {t("walletHome.navTitle")}
          </Typography>
        </Toolbar>
      </AppBar>

      <Box
        sx={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          px: 2.5,
          gap: 2,
        }}
      >
        <AccountBalanceWalletIcon
          sx={{ fontSize: 48, color: "text.disabled" }}
        />
        <Typography variant="body2" color="text.secondary">
          {t("walletHome.placeholder")}
        </Typography>
      </Box>
    </Box>
  );
}
