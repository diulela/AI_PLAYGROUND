import { motion } from "framer-motion";
import { Navigate, useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import DownloadIcon from "@mui/icons-material/Download";
import AddIcon from "@mui/icons-material/Add";
import UsbIcon from "@mui/icons-material/Usb";
import ViewInArIcon from "@mui/icons-material/ViewInAr";
import EntryCard from "@/components/EntryCard";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useWalletStore } from "@/stores/wallet";

/**
 * Brand illustration placeholder.
 * A gradient + icon composition representing "Web3 multi-chain ecosystem".
 * Will be replaced with the actual 3D illustration asset when available.
 */
function BrandIllustration() {
  return (
    <Box
      sx={{
        position: "relative",
        width: 200,
        height: 200,
        mx: "auto",
      }}
    >
      {/* Outer glow */}
      <Box
        sx={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(59,130,246,0.08) 0%, rgba(139,92,246,0.06) 50%, transparent 70%)",
        }}
      />

      {/* Orbit ring 1 */}
      <Box
        sx={{
          position: "absolute",
          inset: 2,
          borderRadius: "50%",
          border: "1px dashed",
          borderColor: "rgba(59,130,246,0.15)",
        }}
      />

      {/* Orbit ring 2 */}
      <Box
        sx={{
          position: "absolute",
          inset: 5,
          borderRadius: "50%",
          border: "1px dashed",
          borderColor: "rgba(139,92,246,0.10)",
        }}
      />

      {/* Decorative nodes */}
      {[
        { top: 16, right: 48, size: 10, color: "rgba(59,130,246,0.35)" },
        { bottom: 32, left: 24, size: 8, color: "rgba(139,92,246,0.35)" },
        { top: 48, left: 16, size: 6, color: "rgba(6,182,212,0.35)" },
        { bottom: 48, right: 24, size: 6, color: "rgba(245,158,11,0.35)" },
      ].map((dot, i) => (
        <Box
          key={i}
          sx={{
            position: "absolute",
            width: dot.size,
            height: dot.size,
            borderRadius: "50%",
            bgcolor: dot.color,
            ...dot,
          }}
        />
      ))}

      {/* Center icon */}
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 72,
          height: 72,
          borderRadius: 2,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "linear-gradient(135deg, #1A1A2E 0%, #2D2D3F 100%)",
          boxShadow: "0 8px 24px rgba(26,26,46,0.2)",
        }}
      >
        <ViewInArIcon sx={{ fontSize: 36, color: "#FFFFFF" }} />
      </Box>
    </Box>
  );
}

export default function HomePage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const accounts = useWalletStore((s) => s.accounts);
  const isDbLoaded = useWalletStore((s) => s.isDbLoaded);

  // Wait for Dexie to load before deciding route
  if (!isDbLoaded) return null;

  // REQ-002: 已有钱包时直接进入主页
  if (accounts.length > 0) {
    return <Navigate to="/wallet" replace />;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35 }}
    >
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          minHeight: "100dvh",
          bgcolor: "background.default",
          px: 2.5,
          pt: 6,
          pb: 5,
        }}
      >
        {/* ── Language switcher — top right (REQ-003) ── */}
        <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 1 }}>
          <LanguageSwitcher />
        </Box>

        {/* ── Brand area — upper half, vertically centered ── */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
          }}
        >
          {/* Illustration */}
          <BrandIllustration />

          {/* Title — H1, spacing(3)=24px below illustration */}
          <Typography variant="h1" sx={{ mt: 3 }}>
            {t("welcome.title")}
          </Typography>

          {/* Subtitle — Body2, spacing(1)=8px below title */}
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            {t("welcome.subtitle")}
          </Typography>
        </Box>

        {/* ── Entry list — lower portion ── */}
        <List component={Stack} spacing={1.5} sx={{ mt: 4 }}>
          <ListItem disablePadding>
            <EntryCard
              icon={<DownloadIcon sx={{ fontSize: 18, color: "#fff" }} />}
              label={t("welcome.importWallet")}
              onClick={() => navigate("/import")}
            />
          </ListItem>
          <ListItem disablePadding>
            <EntryCard
              icon={<AddIcon sx={{ fontSize: 18, color: "#fff" }} />}
              label={t("welcome.createWallet")}
              onClick={() => navigate("/agreement")}
            />
          </ListItem>
          {/* REQ-004: Ledger 入口 */}
          <ListItem disablePadding>
            <EntryCard
              icon={<UsbIcon sx={{ fontSize: 18, color: "#fff" }} />}
              label={t("welcome.ledger")}
              onClick={() => navigate("/ledger")}
            />
          </ListItem>
        </List>
      </Box>
    </motion.div>
  );
}
