import { motion } from "framer-motion";
import { useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import UsbIcon from "@mui/icons-material/Usb";

/**
 * Ledger connection page — REQ-004 placeholder.
 * Will be fully implemented when Ledger WebUSB/WebBluetooth integration is ready.
 */
export default function LedgerPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "tween", duration: 0.25 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <AppBar position="static">
          <Toolbar>
            <IconButton
              edge="start"
              aria-label={t("common.back")}
              onClick={() => navigate(-1)}
            >
              <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
            </IconButton>
            <Typography variant="h2" component="h1" sx={{ ml: 0.5 }}>
              {t("ledger.navTitle")}
            </Typography>
          </Toolbar>
        </AppBar>

        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            px: 2.5,
            gap: 2,
          }}
        >
          <UsbIcon sx={{ fontSize: 48, color: "text.disabled" }} />
          <Typography variant="body2" color="text.secondary">
            {t("ledger.placeholder")}
          </Typography>
        </Box>
      </Box>
    </motion.div>
  );
}
