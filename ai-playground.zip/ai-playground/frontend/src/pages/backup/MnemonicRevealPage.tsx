import { useState, useCallback, useRef } from "react";
import { Navigate, useNavigate } from "react-router";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import QrCode2Icon from "@mui/icons-material/QrCode2";
import { QRCodeSVG } from "qrcode.react";
import { toast } from "sonner";
import { mnemonicToWords } from "@/lib/wallet-core";
import { useWalletStore } from "@/stores/wallet";
import { usePrivacyGuard } from "@/hooks/usePrivacyGuard";

/**
 * Mnemonic Reveal page (REQ-015 + REQ-016 + REQ-018 + REQ-021).
 *
 * Displays the 12-word mnemonic in a 3x4 grid with numbered cards,
 * provides copy-to-clipboard and QR code export, and includes
 * privacy guard overlay.
 *
 * Layout (per design spec 09-助记词展示.md):
 *   [NavBar]         — "备份助记词" + back arrow
 *   [SafetyHint]     — suggestion text
 *   [MnemonicGrid]   — 3x4 numbered word cards
 *   [QuickActions]   — copy + QR code buttons
 *   [SecurityNotes]  — two security statements
 *   [ConfirmButton]  — "我已安全备份" at bottom
 */
export default function MnemonicRevealPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const decryptedMnemonic = useWalletStore((s) => s.decryptedMnemonic);
  const { hidden } = usePrivacyGuard();
  const [qrOpen, setQrOpen] = useState(false);
  const clipboardTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Guard: redirect if mnemonic not available
  if (!decryptedMnemonic) {
    return <Navigate to="/backup/guide" replace />;
  }

  const words = mnemonicToWords(decryptedMnemonic);

  const handleCopy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(decryptedMnemonic);
      toast.success(t("backup.copiedToast"));

      // Clear clipboard after 60s (REQ-018 security)
      if (clipboardTimer.current) clearTimeout(clipboardTimer.current);
      clipboardTimer.current = setTimeout(() => {
        navigator.clipboard.writeText("").catch(() => {});
      }, 60_000);
    } catch {
      // Clipboard API may be blocked in some contexts
    }
  }, [decryptedMnemonic, t]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
          pb: "100px",
          position: "relative",
        }}
      >
        {/* ── Privacy overlay (REQ-019) ── */}
        {hidden && (
          <Box
            sx={{
              position: "fixed",
              inset: 0,
              bgcolor: "background.default",
              zIndex: 9999,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography variant="body1" color="text.secondary">
              🔒
            </Typography>
          </Box>
        )}

        {/* ── NavBar ── */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            height: 56,
            px: 0.5,
          }}
        >
          <IconButton onClick={() => navigate(-1)}>
            <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
          </IconButton>
          <Typography
            variant="h2"
            sx={{ flex: 1, textAlign: "center", mr: 5 }}
          >
            {t("backup.navTitle")}
          </Typography>
        </Box>

        {/* ── Safety hint ── */}
        <Box sx={{ px: 2.5, pt: 2, pb: 2 }}>
          <Typography variant="body1" sx={{ fontSize: "0.9375rem" }}>
            {t("backup.safetyHint")}
          </Typography>
        </Box>

        {/* ── Mnemonic grid (REQ-015 + REQ-016) ── */}
        <Box sx={{ px: 2.5 }}>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: 1,
            }}
          >
            {words.map((word, i) => (
              <Box
                key={i}
                sx={{
                  position: "relative",
                  bgcolor: "#F5F5F5",
                  borderRadius: 1,
                  height: 44,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  overflow: "hidden",
                }}
              >
                {/* Decorative number */}
                <Typography
                  sx={{
                    position: "absolute",
                    left: 6,
                    top: "50%",
                    transform: "translateY(-50%)",
                    fontSize: "1.25rem",
                    fontWeight: 700,
                    color: "#DDDDDD",
                    lineHeight: 1,
                    userSelect: "none",
                  }}
                >
                  {i + 1}
                </Typography>
                {/* Word */}
                <Typography
                  sx={{
                    fontSize: "0.875rem",
                    fontWeight: 600,
                    color: "#1A1A2E",
                    zIndex: 1,
                  }}
                >
                  {word}
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>

        {/* ── Quick actions (REQ-018 + REQ-021) ── */}
        <Box
          sx={{
            display: "flex",
            gap: 1,
            px: 2.5,
            mt: 2,
          }}
        >
          <Button
            variant="text"
            startIcon={<ContentCopyIcon sx={{ fontSize: 16 }} />}
            onClick={handleCopy}
            sx={{
              flex: 1,
              bgcolor: "#F5F5F5",
              borderRadius: 1,
              textTransform: "none",
              color: "text.primary",
              fontSize: "0.875rem",
            }}
          >
            {t("backup.copyButton")}
          </Button>
          <Button
            variant="text"
            startIcon={<QrCode2Icon sx={{ fontSize: 16 }} />}
            onClick={() => setQrOpen(true)}
            sx={{
              flex: 1,
              bgcolor: "#F5F5F5",
              borderRadius: 1,
              textTransform: "none",
              color: "text.primary",
              fontSize: "0.875rem",
            }}
          >
            {t("backup.qrcodeButton")}
          </Button>
        </Box>

        {/* ── Security notes ── */}
        <Box sx={{ px: 2.5, mt: 3, display: "flex", flexDirection: "column", gap: 1.5 }}>
          <Typography
            variant="body2"
            sx={{ color: "text.secondary", fontSize: "0.8125rem", lineHeight: 1.6 }}
          >
            {t("backup.securityNote1")}
          </Typography>
          <Typography
            variant="body2"
            sx={{ color: "text.secondary", fontSize: "0.8125rem", lineHeight: 1.6 }}
          >
            {t("backup.securityNote2")}
          </Typography>
        </Box>

        {/* ── Fixed bottom — "I have safely backed up" button ── */}
        <Box
          sx={{
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            maxWidth: 430,
            mx: "auto",
            px: 2.5,
            pt: 1.5,
            pb: 4.25,
            bgcolor: "background.default",
            borderTop: 1,
            borderColor: "divider",
          }}
        >
          <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={() => navigate("/backup/verify")}
            sx={{ minHeight: 48 }}
          >
            {t("backup.confirmedButton")}
          </Button>
        </Box>
      </Box>

      {/* ── QR Code Dialog (REQ-021) ── */}
      <Dialog
        open={qrOpen}
        onClose={() => setQrOpen(false)}
        PaperProps={{
          sx: {
            borderRadius: 3,
            p: 3,
            maxWidth: 320,
            display: "flex",
            alignItems: "center",
          },
        }}
      >
        <DialogContent
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 2,
            p: 0,
          }}
        >
          <QRCodeSVG
            value={decryptedMnemonic}
            size={200}
            level="M"
            includeMargin
          />
          <Typography variant="body2" color="text.secondary" textAlign="center">
            {t("backup.safetyHint")}
          </Typography>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
