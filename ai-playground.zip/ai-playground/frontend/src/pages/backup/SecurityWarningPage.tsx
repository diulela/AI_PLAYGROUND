import { Navigate, useNavigate } from "react-router";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import VideocamOffIcon from "@mui/icons-material/VideocamOff";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import { useWalletStore } from "@/stores/wallet";

/**
 * Security Warning page (REQ-014).
 *
 * Displays blurred mnemonic preview with anti-surveillance overlay,
 * warns the user about screenshot risks, and offers a "View Mnemonic"
 * button to proceed to the actual reveal page.
 *
 * Layout (per design spec 08-安全警告.md):
 *   [NavBar]           — "备份助记词" + back arrow
 *   [SafetyHint]       — suggestion text
 *   [BlurPreview]      — blurred 3x4 grid + camera-off icon + warning
 *   [ViewButton]       — capsule-shaped secondary button inside blur area
 *   [RedWarning]       — red inline warning about screenshots
 *   [AlreadyBackedUp]  — outline button at bottom for skip
 */
export default function SecurityWarningPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const decryptedMnemonic = useWalletStore((s) => s.decryptedMnemonic);

  // Guard: redirect if mnemonic hasn't been decrypted yet
  if (!decryptedMnemonic) {
    return <Navigate to="/backup/guide" replace />;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
          pb: "120px",
        }}
      >
        {/* ── NavBar ── */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            height: 56,
            px: 0.5,
          }}
        >
          <IconButton onClick={() => navigate(-1)}>
            <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
          </IconButton>
          <Typography
            variant="h2"
            sx={{ flex: 1, textAlign: "center", mr: 5 }}
          >
            {t("backup.navTitle")}
          </Typography>
        </Box>

        {/* ── Safety hint ── */}
        <Box sx={{ px: 2.5, pt: 2, pb: 3 }}>
          <Typography variant="body1" sx={{ fontSize: "0.9375rem" }}>
            {t("backup.safetyHint")}
          </Typography>
        </Box>

        {/* ── Blurred mnemonic preview ── */}
        <Box sx={{ px: 2.5 }}>
          <Box
            sx={{
              position: "relative",
              borderRadius: 2,
              overflow: "hidden",
              bgcolor: "#F5F5F5",
              py: 3,
              px: 2,
            }}
          >
            {/* Fake blurred 3x4 grid */}
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: "repeat(3, 1fr)",
                gap: 1,
                filter: "blur(10px)",
                userSelect: "none",
                pointerEvents: "none",
              }}
            >
              {Array.from({ length: 12 }).map((_, i) => (
                <Box
                  key={i}
                  sx={{
                    height: 40,
                    bgcolor: "#E0E0E0",
                    borderRadius: 1,
                  }}
                />
              ))}
            </Box>

            {/* Overlay: icon + warning + view button */}
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 1.5,
              }}
            >
              <VideocamOffIcon
                sx={{ fontSize: 56, color: "#78909C", opacity: 0.9 }}
              />
              <Typography
                variant="body2"
                sx={{
                  color: "text.secondary",
                  textAlign: "center",
                  px: 3,
                  fontSize: "0.8125rem",
                  lineHeight: 1.6,
                }}
              >
                {t("backup.warningText")}
              </Typography>
              <Button
                variant="outlined"
                onClick={() => navigate("/backup/reveal")}
                sx={{
                  borderRadius: 20,
                  px: 3,
                  height: 36,
                  textTransform: "none",
                  mt: 0.5,
                }}
              >
                {t("backup.viewButton")}
              </Button>
            </Box>
          </Box>

          {/* ── Red warning ── */}
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-start",
              gap: 0.75,
              mt: 2,
            }}
          >
            <ErrorOutlineIcon
              sx={{ fontSize: 16, color: "#EF4444", mt: "2px", flexShrink: 0 }}
            />
            <Typography
              variant="body2"
              sx={{ color: "#EF4444", fontSize: "0.8125rem", lineHeight: 1.5 }}
            >
              {t("backup.warningRedText")}
            </Typography>
          </Box>
        </Box>

        {/* ── Fixed bottom — "Already backed up" outline button ── */}
        <Box
          sx={{
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            maxWidth: 430,
            mx: "auto",
            px: 2.5,
            pt: 1.5,
            pb: 4.25,
            bgcolor: "background.default",
            borderTop: 1,
            borderColor: "divider",
          }}
        >
          <Button
            variant="outlined"
            fullWidth
            onClick={() => navigate("/backup/reveal")}
            sx={{ minHeight: 48 }}
          >
            {t("backup.alreadyBackedUp")}
          </Button>
        </Box>
      </Box>
    </motion.div>
  );
}
