import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import EditNoteIcon from "@mui/icons-material/EditNote";
import PasswordVerifySheet from "@/components/PasswordVerifySheet";

/**
 * Backup Guide page (REQ-012).
 *
 * Educates the user about mnemonic importance and proper backup methods
 * before initiating the identity verification flow.
 *
 * Layout (per design spec 06-备份引导.md):
 *   [NavBar]         — "备份助记词" + back arrow
 *   [SafetyHint]     — suggestion text
 *   [Illustration]   — pencil icon (MUI EditNoteIcon) with decorative background
 *   [Description]    — mnemonic explanation
 *   [StartButton]    — opens PasswordVerifySheet
 */
export default function BackupGuidePage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [sheetOpen, setSheetOpen] = useState(false);

  const handleVerifySuccess = () => {
    setSheetOpen(false);
    navigate("/backup/warning");
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* ── NavBar ── */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            height: 56,
            px: 0.5,
          }}
        >
          <IconButton onClick={() => navigate(-1)}>
            <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
          </IconButton>
          <Typography
            variant="h2"
            sx={{
              flex: 1,
              textAlign: "center",
              mr: 5, // balance for back button
            }}
          >
            {t("backup.navTitle")}
          </Typography>
        </Box>

        {/* ── Safety hint ── */}
        <Box sx={{ px: 2.5, pt: 2 }}>
          <Typography variant="body1" sx={{ fontSize: "0.9375rem" }}>
            {t("backup.safetyHint")}
          </Typography>
        </Box>

        {/* ── Illustration area ── */}
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            px: 2.5,
          }}
        >
          <Box
            sx={{
              position: "relative",
              width: 140,
              height: 140,
              mb: 4,
            }}
          >
            {/* Decorative circle */}
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                background:
                  "radial-gradient(circle, rgba(255,193,7,0.12) 0%, rgba(255,193,7,0.04) 60%, transparent 80%)",
              }}
            />
            <Box
              sx={{
                width: "100%",
                height: "100%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <EditNoteIcon
                sx={{ fontSize: 72, color: "#FFA726", opacity: 0.85 }}
              />
            </Box>
          </Box>

          {/* ── Description ── */}
          <Typography
            variant="body2"
            sx={{
              color: "text.secondary",
              lineHeight: 1.6,
              textAlign: "left",
            }}
          >
            {t("backup.guideDesc")}
          </Typography>
        </Box>

        {/* ── Fixed bottom — Start backup button ── */}
        <Box
          sx={{
            position: "fixed",
            bottom: 0,
            left: 0,
            right: 0,
            maxWidth: 430,
            mx: "auto",
            px: 2.5,
            pt: 1.5,
            pb: 4.25,
            bgcolor: "background.default",
            borderTop: 1,
            borderColor: "divider",
          }}
        >
          <Button
            variant="contained"
            color="primary"
            fullWidth
            onClick={() => setSheetOpen(true)}
            sx={{ minHeight: 48 }}
          >
            {t("backup.startButton")}
          </Button>
        </Box>
      </Box>

      {/* ── Password verify sheet (REQ-013) ── */}
      <PasswordVerifySheet
        open={sheetOpen}
        onClose={() => setSheetOpen(false)}
        onSuccess={handleVerifySuccess}
      />
    </motion.div>
  );
}
