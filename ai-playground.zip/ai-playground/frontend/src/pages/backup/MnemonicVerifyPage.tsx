import { useState, useMemo, useCallback } from "react";
import { Navigate, useNavigate } from "react-router";
import { motion, AnimatePresence } from "framer-motion";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import Chip from "@mui/material/Chip";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import { toast } from "sonner";
import { mnemonicToWords, shuffleWords } from "@/lib/wallet-core";
import { useWalletStore } from "@/stores/wallet";

/**
 * Mnemonic Verify page (REQ-017 + REQ-020).
 *
 * Requires the user to tap words in the correct order to prove
 * they have safely backed up their mnemonic phrase.
 *
 * Layout:
 *   [NavBar]           — "验证助记词" + back arrow
 *   [Hint]             — instruction text
 *   [SelectedGrid]     — 3x4 grid showing selected words (or empty slots)
 *   [CandidateArea]    — shuffled words for user to pick from
 */
export default function MnemonicVerifyPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const decryptedMnemonic = useWalletStore((s) => s.decryptedMnemonic);
  const setDecryptedMnemonic = useWalletStore((s) => s.setDecryptedMnemonic);
  const markBackedUp = useWalletStore((s) => s.markBackedUp);

  // Guard
  if (!decryptedMnemonic) {
    return <Navigate to="/backup/guide" replace />;
  }

  return (
    <VerifyContent
      mnemonic={decryptedMnemonic}
      onComplete={async () => {
        await markBackedUp();
        setDecryptedMnemonic(null);
        toast.success(t("backup.backupComplete"));
        navigate("/wallet", { replace: true });
      }}
      t={t}
      navigate={navigate}
    />
  );
}

// ── Inner content component (avoids hooks after conditional return) ──

function VerifyContent({
  mnemonic,
  onComplete,
  t,
  navigate,
}: {
  mnemonic: string;
  onComplete: () => Promise<void>;
  t: (key: string) => string;
  navigate: ReturnType<typeof useNavigate>;
}) {
  const correctWords = useMemo(() => mnemonicToWords(mnemonic), [mnemonic]);
  const shuffled = useMemo(() => shuffleWords(correctWords), [correctWords]);

  const [selected, setSelected] = useState<string[]>([]);
  const [errorIndex, setErrorIndex] = useState<number | null>(null);

  const usedIndices = useMemo(() => {
    // Track which candidate indices have been used
    const used = new Set<number>();
    for (const word of selected) {
      // Find the first unused index in shuffled that matches
      for (let i = 0; i < shuffled.length; i++) {
        if (shuffled[i] === word && !used.has(i)) {
          used.add(i);
          break;
        }
      }
    }
    return used;
  }, [selected, shuffled]);

  const handleSelectCandidate = useCallback(
    (word: string, _candidateIdx: number) => {
      const nextPosition = selected.length;

      if (word === correctWords[nextPosition]) {
        // Correct
        const newSelected = [...selected, word];
        setSelected(newSelected);

        // Check if complete
        if (newSelected.length === correctWords.length) {
          onComplete();
        }
      } else {
        // Wrong — show error, then auto-remove after shake animation
        setSelected((prev) => [...prev, word]);
        setErrorIndex(nextPosition);
        setTimeout(() => {
          setSelected((prev) => prev.slice(0, -1));
          setErrorIndex(null);
        }, 600);
      }
    },
    [selected, correctWords, onComplete],
  );

  const handleRemoveSelected = useCallback(
    (index: number) => {
      // Only allow removing from the end (sequential)
      if (index === selected.length - 1 && errorIndex === null) {
        setSelected((prev) => prev.slice(0, -1));
      }
    },
    [selected, errorIndex],
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* ── NavBar ── */}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            height: 56,
            px: 0.5,
          }}
        >
          <IconButton onClick={() => navigate(-1)}>
            <ArrowBackIosNewIcon sx={{ fontSize: 18 }} />
          </IconButton>
          <Typography
            variant="h2"
            sx={{ flex: 1, textAlign: "center", mr: 5 }}
          >
            {t("backup.quizTitle")}
          </Typography>
        </Box>

        {/* ── Hint ── */}
        <Box sx={{ px: 2.5, pt: 2, pb: 2 }}>
          <Typography variant="body1" sx={{ fontSize: "0.9375rem" }}>
            {t("backup.quizHint")}
          </Typography>
        </Box>

        {/* ── Selected area (3x4 grid) ── */}
        <Box sx={{ px: 2.5, pb: 3 }}>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(3, 1fr)",
              gap: 1,
            }}
          >
            {Array.from({ length: correctWords.length }).map((_, i) => {
              const word = selected[i];
              const isError = errorIndex === i;

              return (
                <AnimatePresence key={i} mode="wait">
                  <motion.div
                    key={word ?? `empty-${i}`}
                    initial={word ? { scale: 0.8, opacity: 0 } : false}
                    animate={
                      isError
                        ? {
                            scale: 1,
                            opacity: 1,
                            x: [0, -4, 4, -4, 4, 0],
                          }
                        : { scale: 1, opacity: 1, x: 0 }
                    }
                    transition={{ duration: isError ? 0.4 : 0.15 }}
                  >
                    <Box
                      onClick={() => word && handleRemoveSelected(i)}
                      sx={{
                        height: 44,
                        borderRadius: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        position: "relative",
                        overflow: "hidden",
                        cursor: word && !isError ? "pointer" : "default",
                        bgcolor: isError
                          ? "rgba(239,68,68,0.1)"
                          : word
                            ? "#F5F5F5"
                            : "transparent",
                        border: isError
                          ? "1.5px solid #EF4444"
                          : word
                            ? "1.5px solid transparent"
                            : "1.5px dashed #E0E0E0",
                        transition: "all 0.15s",
                      }}
                    >
                      {word && (
                        <>
                          <Typography
                            sx={{
                              position: "absolute",
                              left: 6,
                              fontSize: "1.25rem",
                              fontWeight: 700,
                              color: isError ? "#EF444444" : "#DDDDDD",
                              lineHeight: 1,
                              userSelect: "none",
                            }}
                          >
                            {i + 1}
                          </Typography>
                          <Typography
                            sx={{
                              fontSize: "0.875rem",
                              fontWeight: 600,
                              color: isError ? "#EF4444" : "#1A1A2E",
                              zIndex: 1,
                            }}
                          >
                            {word}
                          </Typography>
                        </>
                      )}
                      {!word && (
                        <Typography
                          sx={{
                            fontSize: "0.75rem",
                            color: "#CCCCCC",
                            userSelect: "none",
                          }}
                        >
                          {i + 1}
                        </Typography>
                      )}
                    </Box>
                  </motion.div>
                </AnimatePresence>
              );
            })}
          </Box>
        </Box>

        {/* ── Candidate area ── */}
        <Box sx={{ px: 2.5 }}>
          <Box
            sx={{
              display: "flex",
              flexWrap: "wrap",
              gap: 1,
              justifyContent: "center",
            }}
          >
            {shuffled.map((word, i) => {
              const isUsed = usedIndices.has(i);
              return (
                <Chip
                  key={i}
                  label={word}
                  onClick={
                    isUsed ? undefined : () => handleSelectCandidate(word, i)
                  }
                  disabled={isUsed}
                  variant={isUsed ? "filled" : "outlined"}
                  sx={{
                    fontWeight: 500,
                    fontSize: "0.875rem",
                    height: 36,
                    borderRadius: 1,
                    opacity: isUsed ? 0.35 : 1,
                    transition: "opacity 0.15s",
                  }}
                />
              );
            })}
          </Box>
        </Box>
      </Box>
    </motion.div>
  );
}
