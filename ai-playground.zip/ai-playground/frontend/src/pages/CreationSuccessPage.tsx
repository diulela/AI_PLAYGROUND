import { motion } from "framer-motion";
import { Navigate, useNavigate } from "react-router";
import { useTranslation } from "react-i18next";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Avatar from "@mui/material/Avatar";
import CheckIcon from "@mui/icons-material/Check";
import { useWalletStore } from "@/stores/wallet";

// ── Chain definitions for multi-chain display (REQ-010) ─────────

const CHAINS = [
  { name: "TRON", color: "#EB0029" },
  { name: "ETH", color: "#627EEA" },
  { name: "BSC", color: "#F0B90B" },
  { name: "BTTC", color: "#000000" },
] as const;

// ── Page component ──────────────────────────────────────────────

/**
 * Creation Success page — REQ-008, REQ-010.
 *
 * Layout (per design spec 05-创建成功.md):
 *   [No NavBar — no back allowed]
 *   [SuccessIcon]    — green checkmark with scale-in animation
 *   [Title]          — "HD 钱包创建成功"
 *   [Subtitle]       — "已为您在以下网络同时创建账户"
 *   [ChainLogos]     — 4 chain logos in a row
 *   [BackupButton]   — fixed bottom, always enabled
 */
export default function CreationSuccessPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const accounts = useWalletStore((s) => s.accounts);

  // Guard: if no accounts exist, redirect to home
  if (accounts.length === 0) {
    return <Navigate to="/" replace />;
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Box
        sx={{
          minHeight: "100dvh",
          bgcolor: "background.default",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          px: 2.5,
          pb: "120px", // space for fixed bottom button
        }}
      >
        {/* ── Success icon with scale animation (design spec 3.1) ── */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{
            type: "spring",
            stiffness: 260,
            damping: 20,
            delay: 0.1,
          }}
        >
          <Box
            sx={{
              position: "relative",
              width: 80,
              height: 80,
              mb: 2.5,
            }}
          >
            {/* Outer glow */}
            <Box
              sx={{
                position: "absolute",
                inset: -8,
                borderRadius: "50%",
                background:
                  "radial-gradient(circle, rgba(34,197,94,0.15) 0%, rgba(34,197,94,0.05) 60%, transparent 80%)",
              }}
            />
            {/* Green circle + checkmark */}
            <Box
              sx={{
                width: 80,
                height: 80,
                borderRadius: "50%",
                bgcolor: "success.main",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <CheckIcon sx={{ fontSize: 40, color: "#FFFFFF" }} />
            </Box>
          </Box>
        </motion.div>

        {/* ── Title (design spec 3.2) ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.4 }}
        >
          <Typography
            variant="h2"
            sx={{ textAlign: "center", mb: 1 }}
          >
            {t("creationSuccess.title")}
          </Typography>
        </motion.div>

        {/* ── Subtitle (design spec 3.3) ── */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.4 }}
        >
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ textAlign: "center", mb: 2 }}
          >
            {t("creationSuccess.subtitle")}
          </Typography>
        </motion.div>

        {/* ── Chain logos (REQ-010, design spec 3.4) ── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.4 }}
        >
          <Box
            sx={{
              display: "flex",
              gap: 1.5,
              justifyContent: "center",
            }}
          >
            {CHAINS.map((chain) => (
              <Avatar
                key={chain.name}
                sx={{
                  width: 32,
                  height: 32,
                  bgcolor: chain.color,
                  fontSize: "0.625rem",
                  fontWeight: 700,
                  color: chain.color === "#F0B90B" ? "#1A1A2E" : "#FFFFFF",
                }}
              >
                {chain.name.slice(0, 2)}
              </Avatar>
            ))}
          </Box>
        </motion.div>
      </Box>

      {/* ── Fixed bottom — Backup button (design spec 3.5) ── */}
      <Box
        sx={{
          position: "fixed",
          bottom: 0,
          left: 0,
          right: 0,
          maxWidth: 430,
          mx: "auto",
          px: 2.5,
          pt: 1.5,
          pb: 4.25, // 34px safe area
          bgcolor: "background.default",
          borderTop: 1,
          borderColor: "divider",
        }}
      >
        <Button
          variant="contained"
          color="primary"
          fullWidth
          onClick={() => navigate("/backup/guide")}
          sx={{ minHeight: 48 }}
        >
          {t("creationSuccess.backupButton")}
        </Button>
      </Box>
    </motion.div>
  );
}
