/**
 * Dexie (IndexedDB) database layer.
 *
 * Stores sensitive wallet data (encrypted mnemonic, accounts) in IndexedDB
 * rather than localStorage for better security, capacity, and binary support.
 *
 * Data split strategy:
 *   - Dexie (IndexedDB): encrypted mnemonic, account records
 *   - Zustand (memory): isUnlocked, currentAccount, UI state
 *   - Zustand persist (localStorage): agreementAcceptedVersion, network preferences
 */
import Dexie from "dexie";

// ── Types ───────────────────────────────────────────────────────

export interface WalletRecord {
  /** Auto-increment primary key */
  id?: number;
  /** User-defined account name (REQ-009) */
  name: string;
  /** TRON address (Base58Check, starts with T) */
  address: string;
  /** Base64-encoded AES-GCM encrypted mnemonic */
  encryptedMnemonic: string;
  /** Whether a GasFree wallet was also created (REQ-011) */
  hasGasFree: boolean;
  /** Whether the mnemonic has been backed up */
  isBackedUp: boolean;
  /** Creation timestamp (Date.now()) */
  createdAt: number;
}

// ── Database ────────────────────────────────────────────────────

class TronWalletDB extends Dexie {
  wallets!: Dexie.Table<WalletRecord, number>;

  constructor() {
    super("tronwallet");

    this.version(1).stores({
      // ++id = auto-increment primary key; address = indexed for lookups
      wallets: "++id, address",
    });
  }
}

const db = new TronWalletDB();

export default db;
