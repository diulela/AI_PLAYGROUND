import { useState, useEffect } from "react";

/**
 * Privacy guard hook (REQ-019 — Web adaptation).
 *
 * Monitors the `visibilitychange` and `blur` events to detect when
 * the page loses focus (e.g. user switches tabs, app goes to background,
 * or — on mobile — the multitask view is shown).
 *
 * Returns `hidden: true` when the page is not visible, which allows
 * components to overlay a privacy mask over sensitive content.
 *
 * **Web platform limitation**: Unlike native apps, browsers cannot
 * intercept screenshots or set `FLAG_SECURE`. This hook provides
 * best-effort privacy protection.
 */
export function usePrivacyGuard(): { hidden: boolean } {
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const handleVisibility = () => {
      setHidden(document.visibilityState === "hidden");
    };

    const handleBlur = () => setHidden(true);
    const handleFocus = () => setHidden(false);

    document.addEventListener("visibilitychange", handleVisibility);
    window.addEventListener("blur", handleBlur);
    window.addEventListener("focus", handleFocus);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibility);
      window.removeEventListener("blur", handleBlur);
      window.removeEventListener("focus", handleFocus);
    };
  }, []);

  return { hidden };
}
