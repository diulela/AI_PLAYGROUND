const zh = {
  lang: {
    zh: "中文",
    en: "English",
  },
  welcome: {
    title: "开始进入 Web3.0",
    subtitle:
      "TronLink 是一款安全的去中心化钱包，为用户的交易保驾护航，保证用户可安心畅游 Web3 世界",
    importWallet: "导入钱包",
    createWallet: "创建钱包",
    ledger: "Ledger",
  },
  agreement: {
    navTitle: "用户协议",
    agreeButton: "同意本条款，下次不再提示",
    title: "TronLink 服务协议与隐私政策",
    lastUpdated: "最后更新：2023年3月8日",
    sections: {
      s1_title: "1. 服务条款概述",
      s1_body:
        "欢迎使用 TronLink（以下简称\u201c我们\u201d或\u201c本服务\u201d）。在使用本服务之前，请您仔细阅读并充分理解本协议的全部内容。您使用本服务即表示您已阅读并同意接受本协议的所有条款和条件。",
      s2_title: "2. 服务内容",
      s2_body:
        "TronLink 是一款去中心化数字资产钱包工具，为用户提供以下服务：\n\n2.1 创建和管理 TRON 区块链钱包地址；\n2.2 发送和接收 TRX 及 TRC-20 标准代币；\n2.3 查看链上交易记录和资产余额；\n2.4 与 TRON 区块链上的去中心化应用（DApp）进行交互。",
      s3_title: "3. 用户责任",
      s3_body:
        "3.1 您应妥善保管您的钱包密码、助记词和私钥。因您个人原因导致的密码、助记词或私钥泄露，由此产生的一切损失由您自行承担。\n\n3.2 您理解并同意，本服务不存储您的密码、助记词或私钥，因此我们无法帮助您恢复上述信息。如果您丢失了助记词或私钥，您将永久失去对相关数字资产的访问权限。\n\n3.3 您应确保在使用本服务时遵守所在司法管辖区的法律法规。",
      s4_title: "4. 风险提示",
      s4_body:
        "4.1 数字资产交易具有高风险性，价格波动剧烈。您应根据自身财务状况和风险承受能力谨慎操作。\n\n4.2 区块链交易具有不可逆性。一旦交易被区块链确认，将无法撤销或修改。请在发起交易前仔细核对所有交易信息。\n\n4.3 智能合约可能存在漏洞或安全风险。与 DApp 交互前，请充分了解相关风险。",
      s5_title: "5. 隐私保护",
      s5_body:
        "5.1 我们尊重并保护用户的个人隐私。本服务不会收集、存储或传输您的私钥、助记词等敏感信息。\n\n5.2 为改善服务质量，我们可能收集匿名使用数据，包括但不限于设备信息、操作系统版本、使用频率等。\n\n5.3 我们不会将您的个人信息出售或分享给第三方，除非获得您的明确同意或法律法规要求。",
      s6_title: "6. 知识产权",
      s6_body:
        "6.1 本服务的所有内容，包括但不限于文字、图片、代码、界面设计、商标等，均受知识产权法律保护。\n\n6.2 未经我们书面许可，您不得复制、修改、分发或以其他方式使用本服务的任何内容。",
      s7_title: "7. 免责声明",
      s7_body:
        "7.1 我们不对因不可抗力（包括但不限于自然灾害、政府行为、网络攻击等）导致的服务中断或数据损失承担责任。\n\n7.2 我们不对区块链网络本身的问题（如网络拥堵、分叉等）导致的交易失败或延迟承担责任。\n\n7.3 我们不对您因使用第三方 DApp 或服务而遭受的任何损失承担责任。",
      s8_title: "8. 服务变更与终止",
      s8_body:
        "8.1 我们保留随时修改、暂停或终止本服务的权利。对于重大变更，我们将通过适当方式提前通知用户。\n\n8.2 服务终止后，您仍可通过助记词或私钥在其他兼容钱包中访问您的数字资产。",
      s9_title: "9. 适用法律与争议解决",
      s9_body:
        "9.1 本协议的订立、效力、解释、执行及争议解决均适用相关法律法规。\n\n9.2 因本协议引起的或与本协议相关的任何争议，双方应首先通过友好协商解决。",
      s10_title: "10. 其他",
      s10_body:
        "10.1 本协议构成您与我们之间关于本服务的完整协议，取代双方之前就本服务达成的任何口头或书面协议。\n\n10.2 如本协议的任何条款被认定为无效或不可执行，其余条款仍具有完全效力。\n\n10.3 本政策未尽事宜，您需遵守我们不时更新的公告及相关规则。\n\n10.4 本政策自2023年3月8日起适用。",
    },
  },
  import: {
    navTitle: "导入钱包",
    placeholder: "导入钱包页面（待实现）",
  },
  ledger: {
    navTitle: "Ledger",
    placeholder: "Ledger 连接（待实现）",
  },
  createWallet: {
    navTitle: "创建 HD 钱包",
    hint1: "首次将为您同时在 TRON、EVM 网络 创建 HD 钱包账户。",
    hint2: "助记词加密并安全的存储在您的设备上，您完全控制加密货币。",
    accountLabel: "账户名称",
    accountDefault: "钱包",
    passwordLabel: "密码",
    passwordHint:
      "设置的密码用于解锁、查看助记词 / 私钥 / keystore；TronLink 不存储密码，也无法帮您找回，请务必牢记。",
    passwordPlaceholder: "请设置密码",
    confirmPlaceholder: "请再次输入密码",
    ruleUppercase: "大写字母",
    ruleLowercase: "小写字母",
    ruleNumber: "数字",
    ruleMinLength: "至少8位",
    passwordMismatch: "两次密码不一致",
    gasFreeLabel: "同时创建 GasFree 钱包，体验无需 Gas 的授权转账！",
    gasFreeLink: "了解 GasFree",
    createButton: "创建钱包",
    creating: "创建中...",
    createFailed: "创建失败，请重试",
  },
  creationSuccess: {
    title: "HD 钱包创建成功",
    subtitle: "已为您在以下网络同时创建账户",
    backupButton: "备份钱包",
  },
  backup: {
    navTitle: "备份助记词",
    safetyHint: "建议用纸和笔抄写助记词然后安全保存",
    guideDesc:
      "助记词由 12 或 24 个单词组成，掌握助记词等于掌握账户资产的所有权，请务必保管在安全的地方",
    startButton: "开始备份",
    verifyTitle: "身份验证",
    verifyPlaceholder: "请输入密码",
    verifyButton: "验证",
    verifyError: "密码错误，请重新输入",
    warningText:
      "任何人获取了助记词意味着获取了资产的所有权，请保证周边环境安全",
    warningRedText: "请勿截图，图片可能被黑客截取，建议以安全方式保存",
    viewButton: "查看助记词",
    alreadyBackedUp: "我已安全备份",
    copyButton: "复制",
    qrcodeButton: "二维码",
    copiedToast: "已复制到剪贴板",
    securityNote1:
      "获得助记词等于拥有钱包资产所有权，请您在收款或卸载前，务必完成助记词备份",
    securityNote2:
      "TronLink 不会在服务器上保存您的助记词，故一旦丢失，TronLink 也无法帮您找回钱包",
    confirmedButton: "我已安全备份",
    quizTitle: "验证助记词",
    quizHint: "请按正确顺序依次点击助记词",
    quizError: "顺序错误，请重新选择",
    backupComplete: "备份成功",
  },
  walletHome: {
    navTitle: "钱包",
    placeholder: "钱包主页（待实现）",
  },
  common: {
    back: "返回",
  },
} as const;

export default zh;
