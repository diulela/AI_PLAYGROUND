const en = {
  lang: {
    zh: "中文",
    en: "English",
  },
  welcome: {
    title: "Enter Web3.0",
    subtitle:
      "TronLink is a secure decentralized wallet that safeguards your transactions and lets you explore the Web3 world with confidence.",
    importWallet: "Import Wallet",
    createWallet: "Create Wallet",
    ledger: "Ledger",
  },
  agreement: {
    navTitle: "User Agreement",
    agreeButton: "Agree and don't show again",
    title: "TronLink Terms of Service & Privacy Policy",
    lastUpdated: "Last updated: March 8, 2023",
    sections: {
      s1_title: "1. Overview",
      s1_body:
        'Welcome to TronLink (hereinafter referred to as "we" or "the Service"). Before using the Service, please carefully read and fully understand all the contents of this agreement. By using the Service, you acknowledge that you have read and agree to all terms and conditions of this agreement.',
      s2_title: "2. Service Description",
      s2_body:
        "TronLink is a decentralized digital asset wallet tool that provides the following services:\n\n2.1 Create and manage TRON blockchain wallet addresses;\n2.2 Send and receive TRX and TRC-20 standard tokens;\n2.3 View on-chain transaction records and asset balances;\n2.4 Interact with decentralized applications (DApps) on the TRON blockchain.",
      s3_title: "3. User Responsibilities",
      s3_body:
        "3.1 You shall properly safeguard your wallet password, mnemonic phrase, and private key. Any losses resulting from the disclosure of your password, mnemonic phrase, or private key due to personal reasons shall be borne by you.\n\n3.2 You understand and agree that the Service does not store your password, mnemonic phrase, or private key. Therefore, we cannot help you recover such information. If you lose your mnemonic phrase or private key, you will permanently lose access to the associated digital assets.\n\n3.3 You shall ensure compliance with the laws and regulations of your jurisdiction when using the Service.",
      s4_title: "4. Risk Disclosure",
      s4_body:
        "4.1 Digital asset trading carries high risks with significant price volatility. You should operate cautiously according to your financial situation and risk tolerance.\n\n4.2 Blockchain transactions are irreversible. Once a transaction is confirmed by the blockchain, it cannot be revoked or modified. Please carefully verify all transaction details before initiating a transaction.\n\n4.3 Smart contracts may contain vulnerabilities or security risks. Please fully understand the associated risks before interacting with DApps.",
      s5_title: "5. Privacy Protection",
      s5_body:
        "5.1 We respect and protect user privacy. The Service does not collect, store, or transmit sensitive information such as your private key or mnemonic phrase.\n\n5.2 To improve service quality, we may collect anonymous usage data, including but not limited to device information, operating system version, and usage frequency.\n\n5.3 We will not sell or share your personal information with third parties unless with your explicit consent or as required by law.",
      s6_title: "6. Intellectual Property",
      s6_body:
        "6.1 All content of the Service, including but not limited to text, images, code, interface design, and trademarks, is protected by intellectual property laws.\n\n6.2 Without our written permission, you may not copy, modify, distribute, or otherwise use any content of the Service.",
      s7_title: "7. Disclaimer",
      s7_body:
        "7.1 We shall not be liable for service interruptions or data losses caused by force majeure events, including but not limited to natural disasters, government actions, and cyberattacks.\n\n7.2 We shall not be liable for transaction failures or delays caused by issues with the blockchain network itself, such as network congestion or forks.\n\n7.3 We shall not be liable for any losses you incur from using third-party DApps or services.",
      s8_title: "8. Service Changes and Termination",
      s8_body:
        "8.1 We reserve the right to modify, suspend, or terminate the Service at any time. For significant changes, we will notify users in advance through appropriate channels.\n\n8.2 After the Service is terminated, you may still access your digital assets through your mnemonic phrase or private key in other compatible wallets.",
      s9_title: "9. Governing Law and Dispute Resolution",
      s9_body:
        "9.1 The formation, validity, interpretation, performance, and dispute resolution of this agreement shall be governed by applicable laws and regulations.\n\n9.2 Any disputes arising from or related to this agreement shall first be resolved through amicable negotiation.",
      s10_title: "10. Miscellaneous",
      s10_body:
        "10.1 This agreement constitutes the entire agreement between you and us regarding the Service, superseding any prior oral or written agreements.\n\n10.2 If any provision of this agreement is found to be invalid or unenforceable, the remaining provisions shall remain in full force and effect.\n\n10.3 For matters not covered by this policy, you shall comply with our announcements and related rules as updated from time to time.\n\n10.4 This policy is effective from March 8, 2023.",
    },
  },
  import: {
    navTitle: "Import Wallet",
    placeholder: "Import Wallet page (coming soon)",
  },
  ledger: {
    navTitle: "Ledger",
    placeholder: "Ledger connection (coming soon)",
  },
  createWallet: {
    navTitle: "Create HD Wallet",
    hint1: "A HD wallet account will be created simultaneously on TRON and EVM networks.",
    hint2: "Your mnemonic is encrypted and stored securely on your device. You have full control of your crypto.",
    accountLabel: "Account Name",
    accountDefault: "Wallet",
    passwordLabel: "Password",
    passwordHint:
      "The password is used to unlock, view mnemonic / private key / keystore. TronLink does not store your password and cannot recover it. Please remember it.",
    passwordPlaceholder: "Set password",
    confirmPlaceholder: "Confirm password",
    ruleUppercase: "Uppercase",
    ruleLowercase: "Lowercase",
    ruleNumber: "Number",
    ruleMinLength: "8+ chars",
    passwordMismatch: "Passwords do not match",
    gasFreeLabel: "Also create a GasFree wallet for gas-free authorized transfers!",
    gasFreeLink: "Learn about GasFree",
    createButton: "Create Wallet",
    creating: "Creating...",
    createFailed: "Creation failed, please try again",
  },
  creationSuccess: {
    title: "HD Wallet Created",
    subtitle: "Accounts created on the following networks",
    backupButton: "Backup Wallet",
  },
  backup: {
    navTitle: "Backup Mnemonic",
    safetyHint: "We recommend writing down the mnemonic with pen and paper and keeping it safe",
    guideDesc:
      "A mnemonic consists of 12 or 24 words. Possessing the mnemonic means owning the assets. Please store it in a safe place.",
    startButton: "Start Backup",
    verifyTitle: "Identity Verification",
    verifyPlaceholder: "Enter password",
    verifyButton: "Verify",
    verifyError: "Incorrect password, please try again",
    warningText:
      "Anyone who obtains the mnemonic owns the assets. Please ensure your surroundings are safe.",
    warningRedText:
      "Do not take screenshots. Images may be intercepted by hackers. Please save securely.",
    viewButton: "View Mnemonic",
    alreadyBackedUp: "I Have Safely Backed Up",
    copyButton: "Copy",
    qrcodeButton: "QR Code",
    copiedToast: "Copied to clipboard",
    securityNote1:
      "Possessing the mnemonic equals owning the wallet assets. Please complete the backup before receiving funds or uninstalling.",
    securityNote2:
      "TronLink does not store your mnemonic on any server. Once lost, TronLink cannot help you recover your wallet.",
    confirmedButton: "I Have Safely Backed Up",
    quizTitle: "Verify Mnemonic",
    quizHint: "Tap the words in the correct order",
    quizError: "Wrong order, please try again",
    backupComplete: "Backup successful",
  },
  walletHome: {
    navTitle: "Wallet",
    placeholder: "Wallet home page (coming soon)",
  },
  common: {
    back: "Back",
  },
} as const;

export default en;
