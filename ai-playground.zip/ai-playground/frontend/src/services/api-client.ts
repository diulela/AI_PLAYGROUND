import { createConnectTransport } from "@connectrpc/connect-web";

/**
 * Connect transport for calling backend APIs.
 * Uses HTTP/JSON (not gRPC-web) for browser compatibility.
 * In dev, Vite proxy forwards /api to backend:8000.
 */
export const transport = createConnectTransport({
  baseUrl: "/",
});
