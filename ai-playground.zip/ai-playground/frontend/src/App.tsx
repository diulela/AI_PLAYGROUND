import { useEffect } from "react";
import { Routes, Route } from "react-router";
import { AnimatePresence } from "framer-motion";
import HomePage from "./pages/HomePage";
import AgreementPage from "./pages/AgreementPage";
import ImportWalletPage from "./pages/ImportWalletPage";
import LedgerPage from "./pages/LedgerPage";
import CreateWalletPage from "./pages/CreateWalletPage";
import CreationSuccessPage from "./pages/CreationSuccessPage";
import WalletHomePage from "./pages/WalletHomePage";
import BackupGuidePage from "./pages/backup/BackupGuidePage";
import SecurityWarningPage from "./pages/backup/SecurityWarningPage";
import MnemonicRevealPage from "./pages/backup/MnemonicRevealPage";
import MnemonicVerifyPage from "./pages/backup/MnemonicVerifyPage";
import { useWalletStore } from "./stores/wallet";

export default function App() {
  const loadAccounts = useWalletStore((s) => s.loadAccounts);

  // Load wallet accounts from Dexie (IndexedDB) on app start
  useEffect(() => {
    loadAccounts();
  }, [loadAccounts]);

  return (
    <AnimatePresence mode="wait">
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/agreement" element={<AgreementPage />} />
        <Route path="/import" element={<ImportWalletPage />} />
        <Route path="/ledger" element={<LedgerPage />} />
        <Route path="/create-wallet" element={<CreateWalletPage />} />
        <Route path="/creation-success" element={<CreationSuccessPage />} />
        <Route path="/wallet" element={<WalletHomePage />} />
        {/* 备份流程 (REQ-012~021) */}
        <Route path="/backup/guide" element={<BackupGuidePage />} />
        <Route path="/backup/warning" element={<SecurityWarningPage />} />
        <Route path="/backup/reveal" element={<MnemonicRevealPage />} />
        <Route path="/backup/verify" element={<MnemonicVerifyPage />} />
        {/* Future routes:
         * /transfer/*     — 转账流程
         * /network        — 切换网络
         */}
      </Routes>
    </AnimatePresence>
  );
}
